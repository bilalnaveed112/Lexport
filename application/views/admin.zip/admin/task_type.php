<?php
include('header.php');

?>

    <style>
        .m-form.m-form--group-seperator-dashed .m-form__group {
            border-bottom: 0px dashed #ebedf2;
        }
        .thh h3{
            background: #1F3958;
            color: #fff;
            font-weight: bold;
            font-size: 15px;
            text-transform: uppercase;
            padding: 10px 10px 10px 29px;
            -webkit-border-top-left-radius: 20px !important;
            -webkit-border-top-right-radius: 20px !important;
            -moz-border-radius-topleft: 20px !important;
            -moz-border-radius-topright: 20px !important;
            border-top-left-radius: 20px !important;
            border-top-right-radius: 20px !important;
            margin: 15px 15px 0 15px;
        }
        .in_fo{
            box-shadow: 0px 5px 10px 0px #cccccc !important;
            margin: 0 15px;
            padding-bottom: 20px;
            -webkit-border-bottom-right-radius: 20px;
            -webkit-border-bottom-left-radius: 20px;
            -moz-border-radius-bottomright: 20px;
            -moz-border-radius-bottomleft: 20px;
            border-bottom-right-radius: 20px;
            border-bottom-left-radius: 20px;
        }
        .m-form.m-form--group-seperator-dashed .m-form__group {
            border-bottom: 0px dashed #ebedf2;
            padding-bottom: 0;
            padding-top: 10px;
        }
        .m-portlet .m-form.m-form--fit > .m-portlet__body {
            padding-bottom: 40px !important;
        }
        .nav {
            display: -webkit-box;
        }
        .m-portlet {
            margin-bottom: 0;
        }
        .m-widget4 .m-widget4__item .m-widget4__info {
            width: 97.2%;
        }
		.m-body .m-content {
    padding: 29px 45px;
}
    </style>

    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Task_Type');?>
                            </h3>
                        </div>
                    </div>
                </div>


             

                <!--begin::Form-->
	<div class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
                    <div class="m-portlet__body"> <div class="form-group m-form__group row">
     <div class="col-lg-7">
	 <div class="row thh">
	<div class="col-lg-12"><H3><?php echo $this->lang->line('TASK_TYPE_LIST');?></h3>
         </div>
	</div>
	<div class="in_fo">
	<div class="form-group m-form__group row">
	  <table id="m_datatable" class="table table-striped table-bordered tablecase">
			<thead>
			  <tr class="netTr">
				<th><?php echo $this->lang->line('SR_NO');?></th>
				<th><?php echo $this->lang->line('Name');?></th>
				<th><?php echo $this->lang->line('ACTION');?></th>
			  </tr>
			</thead>
			<tbody>
			 <?php $ct = 0; foreach ($task_type as $ser) { $ct++;?>
			 	<tr class="hide<?= $ser->id ?>" style="text-align:center">
			 		<td><?= $ct; ?></td>
			 		<td><?= $ser->name; ?></td>
			 		<td class="">
			 			<a href=<?= base_url("admin/admin/find_task_type/{$ser->id}") ?> class="fa fa-edit" title="<?php echo $this->lang->line('Edit_Task');?>"></a>&nbsp;
			 			<a href="javascript:;" class="fa fa-trash deleteservices" id='<?= $ser->id; ?>' title="<?php echo $this->lang->line('Delete_Task');?>"></td>
			 		</tr>
			<?php } ?>   
			</tbody>
		  </table>
	 </div>
	 </div>
	 </div>
     <div class="col-lg-5">
<div class="row thh">	<div class="col-lg-12">
<?php echo form_open('admin/admin/add_task_type',['id'=>'branch']); 
			if($data)
			{
				 echo form_hidden('id',$data->id); 
			}
			else
			{
				 echo form_hidden('id',''); 
			}
		?>
		<h3>
	<?php  if($data){ ?>
				<?php echo $this->lang->line('Edit_Task_Type');?>
	<?php	} else { ?>
				<?php echo $this->lang->line('ADD_TASK_TYPE');?>
	<?php } ?>
		</h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
                                <div class="form-group col-sm-12">
				<label for="name" class=" form-control-label"><?php echo $this->lang->line('Task_Type_Name');?></label>
	<?php if($data)
			{
				$value=$data->name;
			}
			else
			{
				$value=set_value('name');
			}
			echo form_input(['name'=>'name','class'=>'form-control','id'=>'name','value'=>$value,'required'=>'required']); ?>	
			<?= form_error('name'); ?>		
		</div>
		
	<br>
		 <?php 	if($services)
		{
			$edit=$this->lang->line('Edit');
			echo form_submit(['name'=>'submit','value'=>$edit,'class'=>'btn btn-primary btn-lg addservices']);
		}
		else
		{
			$submit=$this->lang->line('Submit');
			 echo form_submit(['name'=>'submit','value'=>$submit,'class'=>'btn btn-primary btn-lg addservices']);
		}
			?> 
			
 		</div>	
                            </div>
                        </div>

 
 

                
                        </div>
                        </div>

                    </div>
            

                <!--end::Form-->
            </div>

            <!--end::Portlet-->
        </div>
    </div>
    </div>
    </div>


<?php

include('footer.php');
?>


<script type="text/javascript">

$(document).ready(function()
{
  $('#msg').hide();

$("#m_datatable").on("click", ".deleteservices", function() {
  var id=$(this).attr("id");
  var url="<?= base_url('admin/admin/delete_task_type'); ?>"; 
bootbox.confirm("Are you sure?", function(result){
if(result){
  $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    dataTyppe: 'json',
  
    success:function(data){
       $('#msg').show();
          $('#msg').html(data);

      },
  });
$('.hide'+id).hide(200);location.reload();
return true;
}
else
{
$('#msg').show();
	$('#msg').html('Delete Failed');
}
})
 });
});
    
</script>