<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Reject_E_Service_List');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">


                    <div class="row align-items-center dataTables_wrapper dt-bootstrap4 no-footer" style="margin-bottom: 20px">

<style>
.nedbtn .btn {
    margin-right: 10px !important;
}
</style>
                        <div class="col-xl-12 order-2 order-xl-1 nedbtn">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">
									<a class="btn btn-info"href="<?=base_url('admin/admin/all_users');?>"><?php echo $this->lang->line('Registered_List');?> <span class="badge badge-danger noticount admin"><?php echo userNotification(); ?></span></a>
									<a class="btn btn-success"href="<?=base_url('admin/c_case/padding_case');?>"><?php echo $this->lang->line('Pending_E_Service');?> <span class="badge badge-danger noticount admin"><?php echo casePendingNotification(); ?></span></a>
									 <a href="<?=base_url('admin/c_case/reject_case_list');?>" class="btn btn-danger"><?php echo $this->lang->line('Reject_E_Service_List');?></a>
									 <a href="<?=base_url('admin/c_case/opponent_list');?>" class="btn btn-info"><?php echo $this->lang->line('Opponent_List');?></a> 

                            </div>

                        </div>

               

                    </div>




                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">
                         <th><?php echo $this->lang->line('No');?></th>
                        <th><?php echo $this->lang->line('Name');?></th>
                        <th><?php echo $this->lang->line('E_service');?></th>
						            <th><?php echo $this->lang->line('Contact_No');?></th>  
									<th><?php echo $this->lang->line('Reject_Reason');?></th>
                        <th><?php echo $this->lang->line('Request_Type');?></th>
                        <th><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </thead>
                            <tbody>
     <?php $count = 1;  foreach ($padding_case as $padding_case) {	?>
                      <tr>
                        <td><?=$count++?></td>
                        <td><?=$padding_case['client_name'];?></td>
                        <td><?=getServiceType($padding_case['service_types']);?></td>
                        <td><?=getCustomerMobile($padding_case['customers_id']);?></td>   <td><?=$padding_case['reject_note'];?></td>
                       <td><?php if ($padding_case['add_edit'] == 1) {?>
                          <span class="badge badge-pill badge-warning"><?php echo $this->lang->line('Request_for_Edit');?></span>
                      <?php } else {?>
                          <span class="badge badge-pill badge-primary"><?php echo $this->lang->line('Request_for_add');?></span>
                     <?php }?>
                    </td>
						<td class="action">


              <?php echo anchor(base_url("admin/c_case/view_case/{$padding_case['case_id']}"), ' ', ['class' => 'fa fa-eye','title'=>$this->lang->line('View')]);
			if($padding_case['is_reject'] == '0'){
				?>
				<a href="javascript:;" id="<?= $padding_case['case_id'] ?>" class="fa fa-close reject_case" title="<?php echo $this->lang->line('Reject_E_Service');?>"><?php echo $this->lang->line('Reject');?></a>
				<?php
			} else {
				?>
					<a href="javascript:;" class="btn btn-danger" title="<?php echo $this->lang->line('Reject_E_Service');?>"><?php echo $this->lang->line('Rejected');?></a>
				<?php 
			}
			  ?>
			  

                      </tr>
            <?php }?>
                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>


        </div>




    </div>

<?php

include('footer.php');

?>    <script type="text/javascript">

$("#m_datatable").on("click", ".reject_case", function() {
var id=$(this).attr("id");


var msg= $('#note_dialog').html();
var url="<?= base_url('admin/c_case/reject_case'); ?>"; 
bootbox.confirm('<div class="assignpopup"><b>Reason For Reject Case</b><textarea placeholder="Notes" name="note" id="notes" class="form-control col-md-12"></textarea></div>', function(result){
if(result){
var  notes = $('#notes').val();

    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id": id,'notes':notes},
    success:function(data){
       $('#msg').show();
	  
         $('#msg').html(data);
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Assign Failed');
}
})
});
        $(document).ready(function() {
          $('#customers-table').DataTable();
        } );
    </script>