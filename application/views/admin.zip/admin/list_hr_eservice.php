<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('HR_E_services');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">

                    <div class="row" style="margin-bottom: 20px">

                        <div class="col-xl-12 order-2 order-xl-1">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">
	<?php   if($this->session->userdata('role_id') == 2){ ?>
                                <div class="col-md-4">

                                    <a href="<?=base_url('admin/hr/add_hr_eservice');?>" class="btn btn-primary m-btn btn-cst  m-btn--custom m-btn--icon m-btn--air" style="border-radius: 20px;">
                                        <span>
                                            <i class="fa fa-plus"></i>
                                        <span><?php echo $this->lang->line('Add_HR_E_Service');?></span>
                                        </span>
                                    </a>

                                </div>
  <?php } ?>
                            </div>

                        </div>

                    </div>
 



                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">
                                 <th><?php echo $this->lang->line('SR_NO');?></th>
                        <th><?php echo $this->lang->line('Service_Type');?></th>
						<?php if($this->session->userdata('role_id') == 1){ ?>   <th><?php echo $this->lang->line('Employee_Name');?></th> <?php } ?>
						<th><?php echo $this->lang->line('Start_Date');?></th>
						<th><?php echo $this->lang->line('End_Date');?></th>
						<th><?php echo $this->lang->line('Reason');?></th>
                        <th><?php echo $this->lang->line('Status');?></th>
						<?php   if($this->session->userdata('role_id') == 1){ ?>   <th><?php echo $this->lang->line('ACTION');?></th> <?php } ?>
                            </tr>
                            </thead>
                            <tbody>
 <?php $count=1;
                       foreach($data as $Padding_cus) { ?>
                        <tr class="" style="text-align: center;">
                        <td><?= $count++ ?></td>
                        <td><?= getHrEserviceName($Padding_cus['service_type']) ?></td>
						<?php if($this->session->userdata('role_id') == 1){ ?>  <td><?= getEmployeeName($Padding_cus['user_id']) ?></td><?php } ?>
                        <td><?php echo getTheDayAndDateFromDatePan($Padding_cus['start_date']); ?></td>
                        <td><?php echo getTheDayAndDateFromDatePan($Padding_cus['end_date']);?></td>
                        <td><?= $Padding_cus['reason'] ?></td>
                        <td><?php 
						if($Padding_cus['status']=="pending" ) { ?> 
						 <span class="m-badge  m-badge--info m-badge--wide"><?php echo $this->lang->line('Pending');?></span>
						<?php }
						if($Padding_cus['status']=="approve") {?> 
						<span class="m-badge  m-badge--success m-badge--wide"><?php echo $this->lang->line('Approved');?></span>
						<?php }
						if($Padding_cus['status']=="reject") {?> 
						<span class="m-badge  m-badge--danger m-badge--wide"><?php echo $this->lang->line('Reject');?></span>
						<?php }?>
						
						</td>
						<?php
						if($this->session->userdata('role_id') == 1){ ?>   
						<td>
						<?php 
						if($Padding_cus['status']=="pending" ) { ?> 
						<a class="btn btn-success" href="<?php echo base_url(); ?>admin/hr/hr_service_status_change/<?php echo $Padding_cus['id'] ; ?>/approve"><?php echo $this->lang->line('Approve');?></a> 
						<a class="btn btn-danger" href="<?php echo base_url(); ?>admin/hr/hr_service_status_change/<?php echo $Padding_cus['id'] ; ?>/reject"><?php echo $this->lang->line('Reject');?></a> 
						<?php } ?>
						<a class="btn btn-info" href="<?php echo base_url(); ?>admin/hr/find_hr_eservice/<?php echo $Padding_cus['id'] ; ?>"><?php echo $this->lang->line('Edit');?></a> 
						</td> 
						<?php } ?>
                      </tr>
				<?php } ?>
                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>


        </div>

    </div>

<?php

include('footer.php');