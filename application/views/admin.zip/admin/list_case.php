<?php
include('header.php');

?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader --> 
    <div class="m-content">

        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('Customer_case_list');?>
                        </h3>
                    </div>
                </div>
            </div>


            <div class="m-portlet__body">
    <div id="msg" class="sufee-alert alert with-close alert-success alert-dismissible fade show success"></div>

                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                    <table class="table table-hover table-striped" id="m_datatable">
                        <thead>
                        <tr class="netTr">
                            <th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th><?php echo $this->lang->line('Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th><?php echo $this->lang->line('E_Service_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th><?php echo $this->lang->line('Contract_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th><?php echo $this->lang->line('E_Service_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th><?php echo $this->lang->line('client_File_number');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th><?php echo $this->lang->line('ACTION');?></th>
                        </tr>
                        </thead>
                        <tbody>
     <?php $i=0; foreach ($list as $case){ $i++; ?>
     <?php if($case['is_reject'] == 0) { ?>
                      <tr style="text-align: center;" class="hide<?php echo $case['id'] ?>">
                        <td><?= $i; ?></td>
                        <td><?= getEmployeeName($case['customers_id']); ?></td>
                        <td><?= getServiceType($case['service_types']); ?></td>
                        <td><?= $case['contract_number'] ?></td>
						<td><?= $case['case_number'] ?></td>
                        <td><?=  $case['client_file_number'] ?> </td>
<td class="text-center">

<?php $t_case=$this->db->select('case_id')->where('case_id',$case['id'])->get('case_temp')->row(); 
 if(isset($t_case->case_id)){ ?>
<span style="overflow: visible; position: relative;">
	<a href="javascript:;" class="btn btn-danger" title="Pending">
		<?php echo $this->lang->line('Pending');?>
	</a>
</span>
 
<span style="overflow: visible; position: relative;">
	<a href="<?= base_url("admin/c_case/pending_case_view/{$case['id']}") ?>" class="btn btn-info" title="View">
		<?php echo $this->lang->line('View');?>
	</a>
</span>
 <?php } else { ?>
 <?php if(isset($datas[1][3]) && $datas[1][3] == 1){ ?>
 <span style="overflow: visible; position: relative;">
	<a href="<?= base_url("admin/c_case/view_case/{$case['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="View">
		<i class="fa fa-eye"></i>
	</a>
</span>
 <?php } ?>
  <?php if(isset($datas[1][2]) && $datas[1][2] == 1){ ?>
<span style="overflow: visible; position: relative;">
	<a href="<?= base_url("admin/c_case/edit_case/{$case['id']}"); ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Edit On File">
		<i class="fa fa-edit"></i>
	</a>
</span>
  <?php } ?>
   <?php if(isset($datas[1][4]) && $datas[1][4] == 1){ ?>
<span style="overflow: visible; position: relative;">
	<a href="javascript:;" data-toggle="modal" data-target="#myModal" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill assign_type dropdown" id="<?= $case['id'] ?>" title="Add Mission">
		<i class="fa fa-plus"></i>
	</a>
</span>
   <?php } ?>
    <?php if(isset($datas[1][1]) && $datas[1][1] == 1){ ?>
<?php //if($case['follow_up_employee'] == 0 OR $case['responsible_employee'] == 0) {?>
<span style="overflow: visible; position: relative;">
	<a href="javascript:;"  data-user="<?= $case['customers_id'] ?>" id="<?= $case['id'] ?>"  class="hideass<?php // $case['id'] ?> m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill assign_type dropdown assign_case" id="<?= $case['id'] ?>" title="Assign E-Service">
		<i class="fa fa-user-plus"></i>
	</a>
</span>
<?php // } 
} ?> 
<?php if($this->session->userdata('role_id') == 1 || (isset($datas[1][5]) && $datas[1][5] == 1)){ ?> 
<span style="overflow: visible; position: relative;">
	<a href="javascript:;" id="<?= $case['id'] ?>" class="delete_case m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Delete E-Service">
		<i class="fa fa-trash"></i>
	</a>
</span> 
<?php } ?>
<?php if($this->session->userdata('admin_id') == 463 OR $this->session->userdata('admin_id') == 470 OR (isset($datas[1][6]) && $datas[1][6] == 1)){ ?>
<span style="overflow: visible; position: relative;">
	<a href="<?php echo base_url();?>admin/finance/create_invoice/<?= $case['id'] ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Create Invoice">
		<i class="fa fa-file-text-o"></i>
	</a>
</span>
<?php } ?>
<?php if(isset($datas[1][6]) && $datas[1][6] == 1){ ?>
<span style="overflow: visible; position: relative;">
	<a href="<?php echo base_url();?>admin/finance/add_expenses/<?php echo $case['id'] ?>/<?php echo $case['customers_id'] ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Add Expenses">
		<i class="fa fa-file-o"></i>
	</a>
</span> 
 <?php } ?>
 <?php } ?>
</td>

                </tr> 
                <?php } } ?>

                        </tbody>
                    </table>
 
                </div>


            </div>
        </div>


    </div>

</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <select class="form-control" id="type" name="type">
           <option value=""><?php echo $this->lang->line('Select_Mission');?></option> 
           <option value="1"><?php echo $this->lang->line('Session');?></option> 
           <option value="2"><?php echo $this->lang->line('Visiting');?></option> 
           <option value="3"><?php echo $this->lang->line('Writings');?></option> 
           <option value="4"><?php echo $this->lang->line('Consultation');?></option> 
		   <option value="5"><?php echo $this->lang->line('GENERAL');?></option> 
        </select>
        <input type="hidden" value="" id="case_id" name="case_id">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('Close');?></button>
      </div>
    </div>

  </div>
</div>

<div id="note_dialog"></div>
<style>
.assignpopup .form-control {
    float: left;
    margin: 5px 0px;
}.calendars-popup {
    z-index: 99999 !important;
}
</style>
<?php include "footer.php";?>
 <script type="text/javascript">
$(document).ready(function() {
	$('#msg').hide();

});
</script>
<script type="text/javascript">

 
$("#m_datatable").on("click", ".assign_type", function() {
    var id=$(this).attr("id");
    $('#case_id').val(id);
})

$('#type').on('change',function(){

  var type_val = $('#type').val();
  var case_id = $('#case_id').val();
  
  if(type_val == 1)
  {
    window.location.href = "<?php echo base_url('admin/mission_session/add_mission'); ?>/"+case_id;
  }else if(type_val == 2)
  {
    window.location.href = "<?php echo base_url('admin/mission_visiting/add_mission'); ?>/"+case_id;
  }
  else if(type_val == 3)
  {
    window.location.href = "<?php echo base_url('admin/mission_writings/add_mission'); ?>/"+case_id;
  } else if(type_val == 5)
  {
    window.location.href = "<?php echo base_url('admin/mission_general/add_mission'); ?>/"+case_id;
  }else
  {
    window.location.href = "<?php echo base_url('admin/mission_consultation/add_mission'); ?>/"+case_id;
  }
})

<?php if(isset($datas[2][3]) && $datas[2][3] == 1){?>
  $('.dataTables_filter').show();
<?php }else{?>
  $('.dataTables_filter').hide();
<?php } ?>
$("#m_datatable").on("click", ".delete_case", function() {
var id=$(this).attr("id");
var url="<?= base_url('admin/c_case/delete_case'); ?>"; 
bootbox.confirm("Are you sure?", function(result){
if(result){
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    success:function(data){
       $('#msg').show();
         if(data == "true"){ $('.hide'+id).hide(200); $('#msg').html('E-service delete successfully');  } else { $('#msg').addClass('alert-warning'); $('#msg').html(data); }
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('delete failed');
}
})
});


$("#m_datatable").on("click", ".assign_case", function() {
var id=$(this).attr("id");
var customers_id=$(this).data("user");
<?php 
date_default_timezone_set('Asia/Riyadh');
if($this->session->userdata('admin_site_lang')=="arabic" OR $this->session->userdata('admin_site_lang')==""){
$start_date = explode('-',date('Y-d-m'));
$start_date = Greg2Hijri($start_date[1],$start_date[2],$start_date[0],true); 

} else {
	$start_date = date('d/m/Y');
}
?>
var msg= $('#note_dialog').html();
var url="<?= base_url('admin/c_case/assign_case'); ?>"; 
/*bootbox.confirm('<div class="assignpopup"><select class="form-control" id="employee_id" name="employee_id"><option value="0">Select employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><input type="text" placeholder="Start date" class="form-control col-md-6" name="start_date" id="start_date" value="<?php echo $start_date; ?>" readonly><input type="text" placeholder="End date" name="end_date" class="form-control col-md-6 appdate" id="end_date" autocomplete="off" required><label class="nterrend_date" style="color:red"></label><input type="text" name="start_time" value="<?php echo date('h:i') ?>" placeholder="Start time" id="start_time" class="form-control  col-md-6" readonly><input type="text" class="form-control col-md-6" placeholder="End time" name="end_time" id="end_time" autocomplete="off" required><label class="nterrend_time" style="color:red"></label><select class="form-control" id="following_employee_id" name="following_employee_id" ><option value="0">Select Following Employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><textarea placeholder="Notes*" name="note" id="notes" class="form-control col-md-12" required></textarea><label class="nterr" style="color:red"></label></div>', function(result){*/
bootbox.confirm('<div class="assignpopup"><select class="form-control" id="employee_id" name="employee_id"><option value="0">Select employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><input type="text" placeholder="Start date" class="form-control col-md-6" name="start_date" id="start_date" value="<?php echo $start_date; ?>" readonly><input type="text" name="start_time" value="<?php echo date('h:i') ?>" placeholder="Start time" id="start_time" class="form-control  col-md-6" readonly><select class="form-control" id="following_employee_id" name="following_employee_id" ><option value="0">Select Following Employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><textarea placeholder="Notes*" name="note" id="notes" class="form-control col-md-12" required></textarea><label class="nterr" style="color:red"></label></div>', function(result){
if(result){
	var  empid = $('#employee_id :selected').val();
	var  following_employee_id = $('#following_employee_id :selected').val();
	var  start_date = $('#start_date').val();
	var  end_date = $('#end_date').val();
	var  start_time = $('#start_time').val();
	var  case_title= $('#case_title').val();
	var  case_type= $('#case_type').val();
	var  end_time = $('#end_time').val();
	var  notes = $('#notes').val();

/*if(end_date==''){
	$('.nterrend_date').html('Start date is required');
	return false;
}
$('.nterrend_date').html('');
if(end_time==''){
	$('.nterrend_time').html('End date is required');
	return false;
}
$('.nterrend_time').html('');*/
if(notes==''){
	$('.nterr').html('Note is required');
	return false;
}
$('.nterr').html('');
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id,"customers_id" : customers_id,'empid':empid,'following_employee_id':following_employee_id,'start_date':start_date,'end_date':end_date,'start_time':start_time,'end_time':end_time,'notes':notes,'case_title':case_title,'case_type':case_type},
    success:function(data){
       $('#msg').show();
	   //alert(data);
         $('#msg').html(data);
          $('.hideass'+id).hide();
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Assign Failed');
}
})
});
$( ".appdate" ).trigger( "click" );
$(document).on("click", ".modal-body", function () {
$('.appdate').calendarsPicker({
  calendar: $.calendars.instance('<?php if($this->session->userdata('admin_site_lang')=="arabic" OR $this->session->userdata('admin_site_lang')=="") echo "ummalqura"; else echo ""; ?>','<?php if($this->session->userdata('admin_site_lang')=="arabic" OR $this->session->userdata('admin_site_lang')=="") echo "ar"; else echo "en"; ?>'),
  showOtherMonths: true,dateFormat: 'dd/mm/yyyy',  minDate:0, selectDefaultDate:true, 
  onSelect: function (date) {
	
  }
});
  $("#end_time").datetimepicker({
    pickDate: false,
    minuteStep: 15,
    pickerPosition: 'bottom-right',
    format: 'HH:ii p',
    autoclose: true,
    showMeridian: true,
    startView: 1,
    maxView: 1,
  });
});
</script> 

<style>
    .modal .modal-content .modal-header .close:before {
        content: "X";
        font-family: arial;
    }
    .modal .modal-content {
        background: #ffffff;
    }
    .col-md-12, .col-md-6{
        margin-bottom: 10px;
    }
</style>
 