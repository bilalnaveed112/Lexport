<?php
include('header.php');
?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('List_Customers');?>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="m-portlet__body">
                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <div class="table-responsive">
                        <table class="table table-hover table-striped" id="m_datatable">
						<thead>
						<tr class="netTr">
						<th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
						<th><?php echo $this->lang->line('Case_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
						<th><?php echo $this->lang->line('File_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
						<th><?php echo $this->lang->line('Client_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                        <th><?php echo $this->lang->line('Invoice_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th> 
						<th><?php echo $this->lang->line('Created_By');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                        <th><?php echo $this->lang->line('Total_Cost');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                        <th><?php echo $this->lang->line('Total_Amount');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                        <th><?php echo $this->lang->line('Payment_Method');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                        <th><?php echo $this->lang->line('Create_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
						<th><?php echo $this->lang->line('Status');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                        <th><?php echo $this->lang->line('ACTION');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
						</tr>
						</thead>
						<tbody>

						<?php $i=0; foreach ($invoice as $invoice){ $i++; ?>
                      <tr class="hide<?php echo $invoice['id'] ?>">
                        <td><?= $i; ?></td>
                        <td><?= $invoice['case_number'] ?></td>
                        <td><?= $invoice['client_file_number'] ?></td>
						<td><?php echo getEmployeeName($invoice['customer_id']); ?></td>
						<td><?= $invoice['invoice_no'] ?></td>
						<td><?php echo getEmployeeName($invoice['created_by']); ?></td>
						<td><?php  $vat = $invoice['main_total']/$invoice['financial_payments']; echo number_format((float)$vat, 2, '.', '');?></td>
						<td><?= $invoice['total'] ?></td>
						<td><?= $invoice['payment_method'] ?></td>
						<td><?php  $date= date("d/m/Y", strtotime($invoice['create_date'])); echo getTheDayAndDateFromDatePan($date); ?> </td>
						<td id="stus<?= $invoice['sub_invoice_id'] ?>"><?= $invoice['payment_status'] ?></td>
						<td class="action">
							<?php if($invoice['payment_method']=="Paypal"){ ?>
							<a href="javascript:;" data-toggle="modal" id="<?= $invoice['tid'] ?>" data-target="#myModal2" class="btn btn-info pp_dd btn-sm" title="<?php echo $this->lang->line('Mission');?>">Paypal Detail</a>
							<?php } ?>
							<?php if($invoice['receipt']){ ?>
							<a  href='<?= base_url("uploads/payment/{$invoice['receipt']}"); ?>' target="_blank" class="fa fa-receipt btn btn-success btn-sm" title="<?php echo $this->lang->line('View_Receipt');?>"><?php echo $this->lang->line('View_Receipt');?></a><br> 
							<?php } ?>
							<a href="javascript:;" data-toggle="modal" id="<?= $invoice['sub_invoice_id'] ?>" data-target="#myModal" class="btn btn-info assign_type btn-sm" title="<?php echo $this->lang->line('Mission');?>"><?php echo $this->lang->line('Change_Status');?></a>
							<?php if($invoice['payment_method']=="cheque"){ ?>
							<a href="javascript:;" data-toggle="modal" id="<?= $invoice['tid'] ?>" data-target="#myModal1" class="btn btn-warning getchecque btn-sm" title="<?php echo $this->lang->line('Mission');?>"><?php echo $this->lang->line('View_Cheque_Detail');?></a>
							<?php } ?>
		 
					</td>

                </tr> 
                <?php } ?>

                            </tbody>
                        </table>
                        </div>
 
                    </div>


                </div>
            </div>


        </div>

    </div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <select class="form-control" id="type" name="type">
			<option value=""><?php echo $this->lang->line('Select_Status');?></option>
			<option value="paid"><?php echo $this->lang->line('Paid');?></option> 
			<option value="unpaid"><?php echo $this->lang->line('UnPaid');?></option> 
			<option value="hold"><?php echo $this->lang->line('Hold');?></option> 
			<option value="process"><?php echo $this->lang->line('In_Process');?></option> 
        </select>
        <input type="hidden" value="" id="inv_id" name="inv_id">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" id="invclick" data-dismiss="modal"><?php echo $this->lang->line('Submit');?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('Close');?></button>
      </div>
    </div>

  </div>
</div>
<div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <?php echo $this->lang->line('Cheque_Detail');?>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
		<div id="getchqdetail"></div> 
      </div>
      <div class="modal-footer"> 
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('Close');?></button>
      </div>
    </div>

  </div>
</div>
<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
		<h4>Paypal Payment Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
		<div id="getpaypaldetail"></div> 
      </div>
      <div class="modal-footer"> 
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('Close');?></button>
      </div>
    </div>

  </div>
</div>
<?php include "footer.php";?>
 <script type="text/javascript">
$(document).ready(function() {
	$('#msg').hide();
});

$('.getchecque').click(function(){
	var id=$(this).attr("id");
	var url="<?= base_url('admin/finance/get_cheque_detail'); ?>"; 
		 $.ajax({
				type:'ajax',
				method:'post',
				url:url,
				data:{"id" : id},
				success:function(data){
				    $('#getchqdetail').html(data);
				},
			});
	});

$('.pp_dd').click(function(){
	var id=$(this).attr("id");  
	var url="<?= base_url('admin/finance/get_paypal_detail'); ?>"; 
		 $.ajax({
				type:'ajax',
				method:'post',
				url:url,
				data:{"id" : id},
				success:function(data){
				    $('#getpaypaldetail').html(data);
				},
			});
	});

</script>
<script type="text/javascript">
$("#invclick").on("click", function() {
	var type = $('#type').val();
	var id = $('#inv_id').val();
	var url="<?= base_url('admin/finance/update_status'); ?>"; 
	$.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id":id,"type":type},
    success:function(data){
         $('#msg').show();
         $('#stus'+id).html(type);
         $('#msg').html("Status Change Succesfully");
      },
  });
});
$(".assign_type").on("click", function() {
    var id=$(this).attr("id");
    $('#inv_id').val(id);
});

<?php if(isset($datas[2][3]) && $datas[2][3] == 1){?>
  $('.dataTables_filter').show();
<?php }else{?>
  $('.dataTables_filter').hide();
<?php } ?>
$("#m_datatable").on("click", ".delete_case", function() {
var id=$(this).attr("id");
var url="<?= base_url('admin/finance/delete_invoice'); ?>"; 
bootbox.confirm("Are you sure?", function(result){
if(result){
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);
      },
  });
$('.hide'+id).hide(200);
return true;
}
else
{
$('#msg').show();
	$('#msg').html('delete failed');
}
})
});
$('#clientsel').on('change', function() {
var url="<?= base_url('admin/archive/select_case'); ?>"; 
var id = this.value;
$.ajax({
  type:'ajax',
  method:'post',
  url:url,
  data:{"id" : id},
  success:function(data){
 
	$('#casesel').html(data);
  },
});
});
</script> 