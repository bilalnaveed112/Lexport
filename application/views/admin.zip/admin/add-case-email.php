<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Albarakati Law</title>
<link href="https://fonts.googleapis.com/css?family=Dosis:300,400,500,700&display=swap" rel="stylesheet">
</head>
<body>
<table cellpadding="0" cellspacing="0" border="0" width="700" align="center" style="border:solid 1px #cccccc; font-family: 'Dosis', sans-serif, Arial;">
<tr><td height="20"></td></tr>
<tr>
<td align="center"><img src="https://albarakatilaw.com/assets/images/logo.png" alt="albarakatilaw" width="300" border="0" /></td>
</tr>
<tr><td height="20"></td></tr>


<?php if($this->session->userdata('admin_site_lang')=="arabic" OR $this->session->userdata('admin_site_lang')=="") { ?>


<?php if ($notification_type == 'mission' && $status_type == "mission_asssign") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center"><?php echo $msg ?></td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as folowing employee in <?php echo $msg ?>. Please check your panel for more details.
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>



<?php if ($notification_type == 'case' && $status_type == "case_convert") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Converted Customer</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as converted  employee. Please check your panel for more details.
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>



<?php if ($notification_type == 'case' && $status_type == "case_res_emp") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Created</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as responsible employee on E-service No. <?php echo getCaseNumber($case); ?>
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>



<?php if ($notification_type == 'case' && $status_type == "case_follow_emp") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Assigen E-service</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as followeup employee on E-service No. <?php echo getCaseNumber($case); ?>
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->


<?php } ?>


<?php if ($notification_type == 'fine') { ?>
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Fine</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	You have new fine. reason for fine is <?php echo $status_type; ?> Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>

<?php if ($notification_type == 'hre') { ?>
<p><span [removed]="font-weight: bold;">Dear Partner:,</span></p>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">HR service</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Your HR service has been <?php echo $status_type; ?>. Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr> 
<?php } ?>

<?php if ($notification_type == 'mission_note') { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center"><?php echo $msgd; ?></td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	You have new message in <?php echo $msgd; ?><br><?php echo $status_type; ?>. Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr> 

<?php } ?>

<?php if ($notification_type == 'project') { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Project </td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	You have new message in <?php echo $msgd; ?><br><?php echo $status_type; ?>. Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr> 
<!-- Email Body -->

<?php } ?>


<?php if ($notification_type == 'invoice' && $status_type == "create") {?>
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Invoice</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	We hope that “Nassr” services have fulfilled your expectations.The invoice for service No. #<?php echo getCaseNumber($case_id) ;?> was issued. We appreciate your payment within the next few hours<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->

<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "add") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Created</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	تمت إضافة الخدمة الإلكترونية مؤخرًا #<?php echo getCaseNumber($case_id) ;?> يرجى زيارة حسابك.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->


<?php } ?>




<?php if ($status_type == "reject") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Rejected</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	لقد تَعذَّر قَبول طلب خدمة قضية رقم: <?php echo getCaseNumber($case_id) ;?>#.لِمَعْرِفَةِ التفاصيل يُرْجَى زيارة إحدى مِنصَّاتِنا الإلكترونِيَّة<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-service-rejection.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->
 

<?php } ?>


<?php if ($notification_type == 'case' && $status_type == "change-approve") {?>

<p><span [removed]="font-weight: bold;">شريكنا العزيز:,</span></p>
<p><span [removed]="font-weight: bold;">Your E-Service no (#<?php echo getCaseNumber($case_id) ;?>) changes has been approved successfully.  Please visit your account o check your changes .</span></p>


<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "approve") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Approved</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	لقد تم قبول طلب خدمة رقم: #<?php echo getCaseNumber($case_id) ;?> ويمكنك مُتابَعة إجراءات تنفيذ الخدمة من خلال الدخول على إحدى منصاتنا الإلكترونية.<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>visit-complete2.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->



<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "edit") {?>
<p><span [removed]="font-weight: bold;">شريكنا العزيز:,</span></p>
<p><span [removed]="font-weight: bold;">Your E-Service no (#<?php echo getCaseNumber($case_id) ;?>) has been edit successfully.  Please visit your account to check your changes .</span></p>

<?php }   ?>
<?php if ($notification_type == 'case' && $status_type == "assign") {?>
 
<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">E-service Assign</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		شريكنا العزيز<br />
	
        	 Your E-Service #<?php echo getCaseNumber($case_id) ;?> has been assign.  For details, please visit any of “Nassr” platforms.<br> 
		<br /> 
		</td>
    </tr>
    <tr>
            </tr>
    
    <!-- End Email Body -->   
<?php } ?>

<?php if ($notification_type == 'customer' && $status_type == "assign") {?>
<p><span [removed]="font-weight: bold;">شريكنا العزيز:,</span></p>
<p><span [removed]="font-weight: bold;">You assign as a customer under <?php echo $ename;?>. Please visit your account.</span></p>

<?php } ?>


<?php if ($notification_type == 'general_appoinment' && $status_type == "add") {?>


<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">General Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		شريكنا العزيز<br />
		لقد تلقينا رقمًا قانونيًا للخدمة العامة <?php echo getCaseNumber($case_id) ;?> سنقوم دائمًا بتحديثك من خلال زيارة أحد منصاتنا على الإنترنت.َات من خلال زيارتكم لإحدى منصاتنا الإلكترونية.<br /> 
		<br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>general-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->   
<?php } ?>

<?php if ($notification_type == 'general_appoinment' && $status_type == "close") {?>
<p><span [removed]="font-weight: bold;">شريكنا العزيز:,</span></p>
<p><span [removed]="font-weight: bold;">لقد أكملت # الخدمة العامة بنجاح: ويمكنك رؤية التفاصيل من خلال أحد الأنظمة الأ<?php echo getCaseNumber($case_id) ;?> ساسية لدينا.
"خدمتك ، وشكرًا على ثقتك"</span></p>

<?php } ?>

<?php if ($notification_type == 'session_appoinment' && $status_type == "add") {?>

<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Session Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		شريكنا العزيز<br />
		قد تَسَلَّمنا طلب خدمة استشارة قانونية رقم <?php echo getCaseNumber($case_id) ;?> وسَنُوافيكم دومًا بالمُسْتَجَدَّات من خلال زيارتكم لإحدى منصاتنا الإلكترونية.<br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>hearing-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->  
  
<?php } ?>

<?php if ($notification_type == 'session_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Hearing Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	لقد أكملت بنجاح خدمة الجلسة القانونية  <?php echo getCaseNumber($case_id) ;?>  بنجاح ، ويمكنك الاطلاع على التفاصيل من خلال أحد منصاتنا على الإنترنت.
"نحن سعداء لخدمتك ، ونحن ممتنون لثقتكم"
<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>hearing-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->
 
<?php } ?>

<?php if ($notification_type == 'writings_appoinment' && $status_type == "add") {?>
 
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Writing Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
        شريكنا العزيز<br />
    
لقد تَسَلَّمنا طلب خدمة كتابة قانونية رقم <?php echo getCaseNumber($case_id) ;?>وسَنُوافيكم دومًا بالمُسْتَجَدَّات من خلال زيارتكم لإحدى منصاتنا الإلكترونية.<br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>writing-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body --> 
<p><span [removed]="font-weight: bold;">:,</span></p>
<p><span [removed]="font-weight: bold;">
 </span></p>
<p><span [remov
ed]="font-weight: bold;">Thanks.....</span></p>
<?php } ?>

<?php if ($notification_type == 'writings_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Writing Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	لقد أُنجِزَتْ مهمةُ خدمة كتابة قانونية رقم: <?php echo getCaseNumber($case_id) ;?> بنجاح، ويمكنكم الاطِّلاع على التفاصيل عَبْر إحدى منصاتنا الإلكترونية.
"نَسْعَدُ بخدمَتكم، ومُمتنُّونَ لثقتكم"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>writing-service-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->  
<?php } ?>

<?php if ($notification_type == 'consultation_appoinment' && $status_type == "add") {?>
<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Consultation Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
             
<br>شريكنا العزيز
لقد تَسَلَّمنا طلب خدمة استشارة قانونية رقم <?php echo getCaseNumber($case_id) ;?>
 وسَنُوافيكم دومًا بالمُسْتَجَدَّات من خلال زيارتكم لإحدى منصاتنا الإلكترونية.

		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>legal-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body --> 
<?php } ?>

<?php if ($notification_type == 'consultation_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Consultation Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	لقد أُنجِزَتْ مهمةُ خدمة استشارة قانونية رقم: <?php echo getCaseNumber($case_id) ;?>بنجاح، ويمكنكم الاطِّلاع على التفاصيل عَبْر إحدى منصاتنا الإلكترونية.
"بخدمَتكم، ومُمتنُّونَ لثقتكم"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>consulting-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->   

<?php } ?>

<?php if ($notification_type == 'visiting_appoinment' && $status_type == "add") {?>

<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Visit Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		شريكنا العزيز<br />
		لقد تم قبول طلب خدمة كتابة قانونيَّة رقم <?php echo getCaseNumber($case_id) ;?>  ويمكنك مُتابَعة إجراءات تنفيذ الخدمة من خلال الدخول على إحدى منصاتنا الإلكترونية.<br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>visiting-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->  


<?php } ?>

<?php if ($notification_type == 'visiting_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Visit Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
لقد أكملت بنجاح رقم خدمة الزيارة القانونية: <?php echo getCaseNumber($case_id) ;?> بنجاح ، ويمكنك الاطلاع على التفاصيل من خلال أحد منصاتنا.<br>
"نَسْعَدُ بخدمَتكم، ومُمتنُّونَ لثقتكم"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>visit-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->

<?php }  }  else { ?>


<?php if ($notification_type == 'mission' && $status_type == "mission_asssign") { ?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center"><?php echo $msg ?></td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as folowing employee in <?php echo $msg ?>. Please check your panel for more details.
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "case_convert") { ?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Converted Customer</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as converted  employee. Please check your panel for more details.
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>


<?php if ($notification_type == 'case' && $status_type == "case_follow_emp") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Assigen E-service</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as followeup employee on E-service No. <?php echo getCaseNumber($case); ?>
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->


<?php } ?>


<?php if ($notification_type == 'case' && $status_type == "case_res_emp") {?> 
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Created</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
    You have assigen as responsible employee on E-service No. <?php echo getCaseNumber($case); ?>
	</td>
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->


<?php } ?>



<?php if ($notification_type == 'invoice' && $status_type == "create") {?>
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Invoice</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	شريكنا العزيز<br />
	We hope that “Nassr” services have fulfilled your expectations.The invoice for service No. #<?php echo getCaseNumber($case_id) ;?> was issued. We appreciate your payment within the next few hours<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->

<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "add") { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Created</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Your recently E-Service (#<?php echo getCaseNumber($case_id) ;?>) has been added successfully.  Please visit your account.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>lawsuit-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->

<?php } ?>

<?php if ($notification_type == 'fine') { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Fine</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	You have new fine. reason for fine is <?php echo $status_type; ?> Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr>
 <!-- Email Body -->
<?php } ?>

<?php if ($notification_type == 'hre') { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">HR service</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Your HR service has been <?php echo $status_type; ?>. Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr> 
<?php } ?>

<?php if ($notification_type == 'mission_note') { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center"><?php echo $msgd; ?></td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	You have new message in <?php echo $msgd; ?><br><?php echo $status_type; ?>. Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr> 

<?php } ?>

<?php if ($notification_type == 'project') { ?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Project </td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	You have new message in <?php echo $msgd; ?><br><?php echo $status_type; ?>. Please check your panel for more details.<br /> 
	</td>
</tr>
<tr>
	<!--<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-invoice.jpg" alt="albarakatilaw" border="0" /></td>-->
</tr> 
<!-- Email Body -->
<?php } ?>

<?php if ($status_type == "reject") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Rejected</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	The request for No. (#<?php echo getCaseNumber($case_id) ;?>) wasrefused.For details, please visit one of “Nassr” platforms.<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>task-service-rejection.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->
 
<?php } ?>


<?php if ($notification_type == 'case' && $status_type == "change-approve") {?>
<p><span [removed]="font-weight: bold;">Dear Partner:,</span></p>
<p><span [removed]="font-weight: bold;">Your E-Service no (#<?php echo getCaseNumber($case_id) ;?>) changes has been approved successfully.  Please visit your account o check your changes .</span></p>


<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "approve") {?>
<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">E-Service Approved</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	The request for service No. #<?php echo getCaseNumber($case_id) ;?> was accepted. You can follow the procedures for service execution by entering any of “Nassr” platforms.<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>visit-complete2.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->
<?php } ?>

<?php if ($notification_type == 'case' && $status_type == "edit") {?>
<p><span [removed]="font-weight: bold;">Dear Partner:,</span></p>
<p><span [removed]="font-weight: bold;">Your E-Service no (#<?php echo getCaseNumber($case_id) ;?>) has been edit successfully.  Please visit your account to check your changes .</span></p>

<?php }   ?>
<?php if ($notification_type == 'case' && $status_type == "assign") {?>

<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">E-service Assign</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	    Dear Partner<br>
	
	     E-Service #<?php echo getCaseNumber($case_id) ;?> has been assigen.  For details, please visit any of “Nassr” platforms.<br> 
		<br /> 
		</td>
    </tr>
    <tr>
    </tr>
    
    <!-- End Email Body --> 
<?php } ?>

<?php if ($notification_type == 'customer' && $status_type == "assign") {?>
<p><span [removed]="font-weight: bold;">Dear Partner:,</span></p>
<p><span [removed]="font-weight: bold;">You assign as a customer under <?php echo $ename;?>.  For details, please visit any of “Nassr” platforms.</span></p>

<?php } ?>


<?php if ($notification_type == 'general_appoinment' && $status_type == "add") {?>

<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">General Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		Dear Partner<br />
		We received your general request for service No. <?php echo getCaseNumber($case_id) ;?> and will update you. For details, please visit any of “Nassr” platforms.<br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>general-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr> 
 
<?php } ?>

<?php if ($notification_type == 'general_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">General Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Dear Partner:Your legal General service task No. <?php echo getCaseNumber($case_id); ?> was successfully accomplished. For details, please visit any of “Nassr” platforms.<br>"We are happy to serve you and we are grateful for your trust"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>general-service.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->    

<?php } ?>

<?php if ($notification_type == 'session_appoinment' && $status_type == "add") {?>
<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Session Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		Dear Partner<br />
		We received your request Session for (lawsuit) service  No. <?php echo getCaseNumber($case_id) ;?> and will update you. For details, please visit any of “Nassr” platforms.<br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>hearing-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->  

<?php } ?>

<?php if ($notification_type == 'session_appoinment' && $status_type == "close") {?>


<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Session Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
our legal session service task No. <?php echo getCaseNumber($case_id); ?> was successfully accomplished. For details, please visit any of “Nassr” platforms.<br>"We are happy to serve you and we are grateful for your trust"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>hearing-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>
 <!-- Email Body -->

<?php } ?>

<?php if ($notification_type == 'writings_appoinment' && $status_type == "add") {?>
 <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Writing Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
        Dear Partner<br />
		We received your request for legal writing service No. <?php echo getCaseNumber($case_id) ;?> and will update you. For details, please visit any of “Nassr” platforms. 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>writing-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body --> 
	 
<?php } ?>

<?php if ($notification_type == 'writings_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Writing Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Dear Partner:Your legal writing service task No. <?php echo getCaseNumber($case_id); ?> was successfully accomplished. For details, please visit any of “Nassr” platforms.<br>"We are happy to serve you and we are grateful for your trust"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>writing-service-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->  

<?php } ?>

<?php if ($notification_type == 'consultation_appoinment' && $status_type == "add") {?>
<!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Consultation Service Application Receipt Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
		Dear Partner<br />
		We received your request for  consultation service  No. <?php echo getCaseNumber($case_id);?> and will update you. For details, please visit any of “Nassr” platforms.  <br /> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>legal-service.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->  


<?php } ?>

<?php if ($notification_type == 'consultation_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Consultation Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Dear Partner:Your legal consultation service task No. <?php echo getCaseNumber($case_id); ?> was successfully accomplished. For details, please visit any of “Nassr” platforms.<br>"We are happy to serve you and we are grateful for your trust"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>consulting-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->   

<?php } ?>

<?php if ($notification_type == 'visiting_appoinment' && $status_type == "add") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Visit Service Application Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	We received your visiting request  No. <?php echo getCaseNumber($case_id) ;?> and will update you. For details, please visit any of “Nassr” platforms.<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>visiting-service.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->  

<?php } ?>

<?php if ($notification_type == 'visiting_appoinment' && $status_type == "close") {?>

<!-- Email Body -->
<tr>
	<td style="color:#c8a458; font-size:32px;" align="center">Visit Service Accoomplishment Receipt Message</td>
</tr>
<tr>
	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
	Dear Partner<br />
	Dear Partner:Your legal visiting service task No. <?php echo getCaseNumber($case_id); ?> was successfully accomplished. For details, please visit any of “Nassr” platforms.<br>"We are happy to serve you and we are grateful for your trust"<br /> 
	</td>
</tr>
<tr>
	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>visit-complete.jpg" alt="albarakatilaw" border="0" /></td>
</tr>

<!-- End Email Body -->   

<?php }   } ?>


<!-- Footer -->
    
	<tr><td height="20"></td></tr>
    <tr>
    	<td align="center" style="background:#102b4e;">
        	<table cellpadding="0" cellspacing="0" border="0" width="700" align="center" style="background:#102b4e;">
				<tr><td height="20"></td></tr>
            	<tr>
                	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>start-service.jpg" alt="albarakatilaw" border="0" /></td>
                </tr>
                <tr><td height="10"></td></tr>
                <tr>
                    <td style="color:#c8a458; font-size:28px;" align="center">START OUR SERVICES</td>
                </tr>
                <tr><td height="40"></td></tr>
                <tr>
                    <td style="color:#c8a458; font-size:22px;" align="center">Questions? Call</td>
                </tr>
                <tr><td height="10"></td></tr>
                <tr>
                    <td style="color:#ffffff; font-size:20px;" align="center">Tel. 920002916 Riyad . Jeddah . Makkah</td>
                </tr>
                <tr><td height="40"></td></tr>
                <tr>
                    <td style="color:#c8a458; font-size:22px;" align="center">Connect With Us</td>
                </tr>
                <tr><td height="10"></td></tr>
                <tr>
                    <td style="color:#ffffff; font-size:20px;" align="center" valign="middle"><a href="https://www.facebook.com/Albarakatilaw/"><img src="<?php echo base_url('assets/images/email/');?>fb.jpg" alt="albarakatilaw" border="0" style="vertical-align:middle;" /></a> <a href="https://twitter.com/albarakatilaw?lang=ar"><img src="<?php echo base_url('assets/images/email/');?>twitter.jpg" alt="albarakatilaw" border="0" style="vertical-align:middle;" /></a> <a href="https://ae.linkedin.com/company/nassr-albarakati-law-firm"><img src="<?php echo base_url('assets/images/email/');?>linkedin.jpg" alt="albarakatilaw" border="0" style="vertical-align:middle;" /></a> <span style="vertical-align:middle;">ALBARAKATILAW</span></td>
                </tr>
                <tr><td height="40"></td></tr>
            </table>
        </td>
    </tr>
    <tr>
    	<td align="center">
        	<table cellpadding="0" cellspacing="0" border="0" width="700" align="center" style="padding:15px 0px 15px 0px; font-size:13px;">
            	<tr>
                	<td width="233" align="center"><a href="#" style="text-decoration:none; color:#7a7b7e;">Was this tutorial useful?</a></td>
                	<td width="233" align="center"><a href="https://albarakatilaw.com/" style="text-decoration:none; color:#7a7b7e;">www.albarakatilaw.com</a></td>
                	<td width="233" align="center"><a href="#" style="text-decoration:none; color:#7a7b7e;">You can unsubscribe</a></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body> 
</html>