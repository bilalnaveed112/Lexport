<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">
<style>
.datafiles .fa {
    font-size: 70px;
}
</style>

        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Archives');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">
				<?php 
$c = isset($_POST['file_type'])?$_POST['file_type']:''; 
$case_id = isset($_POST['cases'])?$_POST['cases']:''; 
$custo_id = isset($_POST['clients'])?$_POST['clients']:''; 
				echo form_open("admin/archive/list_archive/",['id'=>'archive']); ?>

                    <div class="row align-items-center dataTables_wrapper dt-bootstrap4 no-footer" style="margin-bottom: 20px">

                   
                        <div class="col-md-12">
                            
                            <div class="row">
<?php if($this->session->userdata('role_id') == 1){
		$users =  $this->db->select("users.*,chat.create_date,chat.user_id")->join('chat', "chat.user_id = users.id", 'left')
			->where("users.role_id",3)->order_by('chat.create_date', 'DESC')->group_by('users.id')
			->get("users")
			->result_array();
		} ELSE {
			$users =  $this->db->select("customers.*,chat.create_date,chat.user_id")->join('chat', "chat.user_id = customers.user_id", 'left')
			->where("customers.user_id",$this->session->userdata('admin_id'))->order_by('chat.create_date', 'DESC')->group_by('customers.user_id')
			->get("customers")
			->result_array();
		} ?>
                                <div class="col-md-4">
		<select id="clientsel" class="form-control" name="clients">
		    	<option><?php echo $this->lang->line('Select_Client');?></option>
				
			<?php  foreach ($users as $get_per_clients) {?>
			<?php if($this->session->userdata('role_id') == 1){ ?>
		    	<option value="<?php echo $get_per_clients['id']?>" <?php if($custo_id==$get_per_clients['id']){ echo "selected=selected";}?>><?php echo $get_per_clients['name']?></option>
			<?php } else {?>
			
		    	<option value="<?php echo $get_per_clients['customers_id']?>" <?php if($custo_id==$get_per_clients['customers_id']){  }?>><?php echo $get_per_clients['client_name']?></option>
			<?php } } ?>
		    </select>
                                </div>
	<div class="col-md-3">
		<select class="form-control" id="casesel" name="cases">
			<option><?php echo $this->lang->line('Select_E_Service');?></option>
			<?php /* foreach ($get_per_case as $get_per_case) {?>
			<option value="<?php echo $get_per_case['doc_id']?>" <?php if($case_id==$get_per_case['doc_id'] AND $get_per_case['doc_id'] !='') {echo "selected=selected";}?>><?php echo $get_per_case['case_number']?></option>
			<?php }*/?>	    
		</select> 
</div>
<div class="col-md-3">
<select id="" class="form-control" name="file_type"><option value=""><?php echo $this->lang->line('File_Type');?></option>
<option value="1" <?php if($c==1) echo "selected=selected";?>><?php echo $this->lang->line('Documentation');?></option>
<option value="2" <?php if($c==2) echo "selected=selected";?>><?php echo $this->lang->line('Data');?></option>
<option value="3" <?php if($c==3) echo "selected=selected";?>><?php echo $this->lang->line('Contract');?></option>
<option value="4" <?php if($c==4) echo "selected=selected";?>><?php echo $this->lang->line('Report');?></option>
<option value="6" <?php if($c==6) echo "selected=selected";?>><?php echo $this->lang->line('Procuation');?></option>
<option value="7" <?php if($c==7) echo "selected=selected";?>><?php echo $this->lang->line('Referrals');?></option>
</select>
                                </div>

                                <div class="col-md-1">
									
                                  <?php $find=$this->lang->line('Find');	echo form_submit(['id'=>'addcustomer','value'=>$find,'class'=>'btn btn-primary ']); ?>
                                </div>
                                <div class="col-md-1">
                               <a href="" class="btn btn-danger"  ><?php echo $this->lang->line('Reset');?></a>
                                </div>
                                
                            </div>
                            
                        </div>

                    </div>


</form>

                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr" style="text-align:center;">
                                <th><?php echo $this->lang->line('SR_NO');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Thumb');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('File_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('File_Type');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Modify_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Uploaded_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Uploaded_by');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </thead>
                            <tbody>
<?php 
              $count=1;
              foreach($data as $archives){
		 
				$did= getCaseIdByDocId($archives['temp_app_id']);
			
				 if($this->session->userdata('role_id') == 1){
			  ?>
			  
              <tr class="hide<?php echo $archives['id'] ?>" style="text-align:center;">
                <td><?= $count++ ?></td>
                <td><a href="<?=base_url('uploads/case_file/'.$archives["name"]);?>" class='dwnl' title="<?php echo $this->lang->line('Download');?>" download><?php    $src = base_url()."uploads/case_file/".$archives['name'];
                 	 

 $ext = pathinfo($archives['name'], PATHINFO_EXTENSION);
                 	if($ext == 'jpeg' || $ext == 'jpg' || $ext == 'png'){
                 	    $src = base_url()."uploads/case_file/".$archives['name'];
                 	   echo "<img src='".$src."' width='70'>"; 
                 	  
                 	}
                 	else if($ext == 'avi' || $ext == 'mp4' || $ext == 'flv' || $ext == 'mov' || $ext == 'wmv' || $ext == '3gp' ){
                 	    echo "<div class='datafiles'><i class='fa fa-video-camera 5x'></i></div>";
                 	}
                 	else if($ext == 'mp3' || $ext == 'wav' || $ext == 'ogg' || $ext == 'aac' || $ext == 'mpc' ){
                 	    echo "<div class='datafiles'><i class='fa fa-microphone 5x'></i></div>";
                 	} else {
                 	     echo "<div class='datafiles'><i class='fa fa-file 5x'></i></div>";
                 	}
?></a></td>
                <td><?= $archives['name'] ?></td>
                <td><?php //echo  pathinfo($archives['name'], PATHINFO_EXTENSION); 
				if($archives['cat_id']==1){ echo "Documentation"; }
				if($archives['cat_id']==2){ echo "Data"; }
				if($archives['cat_id']==3){ echo "Contract"; }
				if($archives['cat_id']==4){ echo "Report"; }
				if($archives['cat_id']==5){ echo "Tuning"; }
if($archives['cat_id']==6){ echo "Procuation"; }
if($archives['cat_id']==7){ echo "Referrals"; }
				?></td>
                <td><?php  $date= date("d/m/Y", strtotime($archives['updatedate'])); echo getTheDayAndDateFromDatePan($date); ?> </td>
                <td> <?php  $date= date("d/m/Y", strtotime($archives['created'])); echo getTheDayAndDateFromDatePan($date); ?> </td>
                <td><?php echo getEmployeeName($archives['uploaded_by']);?></td>
					<td class="action">
					 
<span style="overflow: visible; position: relative;">
		<a href="javascript:;" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill delete_contract" id=<?= $archives['id'] ?> title="<?php echo $this->lang->line('Close');?>">
			<i class="fa fa-close"></i>
		</a>
	</span>
<span style="overflow: visible; position: relative;">

		<!--<a href="<?= base_url("admin/c_case/edit_case/{$did}#armanage") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill" title="">
			<i class="fa fa-edit"></i>
		</a>-->
</span>

                </td>
              </tr>
            <?php } else {
				if($archives['cat_id']!=3){
					 ?>
			  
              <tr class="hide<?php echo $archives['id'] ?>" style="text-align:center;">
                <td><?= $count++ ?></td>
                <td><a href="<?=base_url('uploads/case_file/'.$archives["name"]);?>" class='dwnl' download><?php    $src = base_url()."uploads/case_file/".$archives['name'];
                 	 

 $ext = pathinfo($archives['name'], PATHINFO_EXTENSION);
                 	if($ext == 'jpeg' || $ext == 'jpg' || $ext == 'png'){
                 	    $src = base_url()."uploads/case_file/".$archives['name'];
                 	   echo "<img src='".$src."' width='70'>"; 
                 	  
                 	}
                 	else if($ext == 'avi' || $ext == 'mp4' || $ext == 'flv' || $ext == 'mov' || $ext == 'wmv' || $ext == '3gp' ){
                 	    echo "<div class='datafiles'><i class='fa fa-video-camera 5x'></i></div>";
                 	}
                 	else if($ext == 'mp3' || $ext == 'wav' || $ext == 'ogg' || $ext == 'aac' || $ext == 'mpc' ){
                 	    echo "<div class='datafiles'><i class='fa fa-microphone 5x'></i></div>";
                 	} else {
                 	     echo "<div class='datafiles'><i class='fa fa-file 5x'></i></div>";
                 	}
?></a></td>
                <td><?= $archives['name'] ?></td>
                <td><?php //echo  pathinfo($archives['name'], PATHINFO_EXTENSION); 
				if($archives['cat_id']==1){ echo "Documentation"; }
				if($archives['cat_id']==2){ echo "Data"; }
				if($archives['cat_id']==3){ echo "Contaract"; }
				if($archives['cat_id']==4){ echo "Report"; }
				if($archives['cat_id']==5){ echo "Tuning"; }
if($archives['cat_id']==6){ echo "Procuation"; }
if($archives['cat_id']==7){ echo "Referrals"; }
				?></td>
                <td><?php  $date= date("d/m/Y", strtotime($archives['updatedate'])); echo getTheDayAndDateFromDatePan($date); ?> </td>
                <td> <?php  $date= date("d/m/Y", strtotime($archives['created'])); echo getTheDayAndDateFromDatePan($date); ?> </td>
                  <td><?php echo getEmployeeName($archives['uploaded_by']);?></td>
					<td class="action">
	 
<span style="overflow: visible; position: relative;">
		<a href="javascript:;" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill delete_contract" id=<?= $archives['id'] ?> title="<?php echo $this->lang->line('Close');?>">
			<i class="fa fa-close"></i>
		</a>
	</span>
<!--<span style="overflow: visible; position: relative;">
		<a href="<?= base_url("admin/c_case/edit_case/{$did}#armanage") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill" title="">
			<i class="fa fa-edit"></i>
		</a>
</span>-->
                </td>
              </tr> <?php
				}
			}
			
			} ?>

                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>


        </div>

    </div>

<?php

include('footer.php');
?>

<script type="text/javascript">
  <?php if(isset($datas[13][3]) && $datas[13][3] == 1){?>
      $('.dataTables_filter').show();
    <?php }else{?>
      $('.dataTables_filter').hide();
    <?php } ?>
  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });

  $('.delete_contract').click(function(){
    
    var id=$(this).attr("id");

    var url="<?= base_url('admin/archive/delete_archive'); ?>"; 
    bootbox.confirm("Are you sure?", function(result){
      if(result)
      {
        $.ajax({
          type:'ajax',
          method:'post',
          url:url,
          data:{"id" : id},
          success:function(data){
            $('#msg').show();
            $('#msg').html(data);
          },
        });
        $('.hide'+id).hide(200);
        return true;
      }
      else
      {
        $('#msg').show();
        $('#msg').html('delete failed');
      }
    })
  });
$('#clientsel').on('change', function() {
var url="<?= base_url('admin/archive/select_case'); ?>"; 
var id = this.value;
$.ajax({
  type:'ajax',
  method:'post',
  url:url,
  data:{"id" : id},
  success:function(data){
 
	$('#casesel').html(data);
  },
});
});
</script>
