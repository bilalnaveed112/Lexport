<?php $sub == 'new') {?>

<p><span [removed]="font-weight: bold;">Hello Mr.<?php echo $to_email; ?>,</span></p>
<p><span [removed]="font-weight: bold;">Thank you for joining at our site:-&nbsp;</span>Albarakati<span [removed]="font-weight: bold;">.</span></p>
<p><span [removed]="font-weight: bold;">Your account type is : User</span></p>
<p><span [removed]="font-weight: bold;">Case Number is : [<?php echo $case_number; ?>]</span></p>
<p>Login from here : <a href="<?php echo base_url('admin/login'); ?>">Login</a></p>
<p>&nbsp;Best wishes.....</p>
<p><br></p>
<p><span [removed]="font-weight: bold;">Thanks.....</span></p>
<?php }?>
