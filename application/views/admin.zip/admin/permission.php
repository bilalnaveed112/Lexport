<?php
include('header.php');

?>

    <style>
        .m-form.m-form--group-seperator-dashed .m-form__group {
            border-bottom: 0px dashed #ebedf2;
        }
        .thh h3{
            background: #1F3958;
            color: #fff;
            font-weight: bold;
            font-size: 15px;
            text-transform: uppercase;
            padding: 10px 10px 10px 29px;
            -webkit-border-top-left-radius: 20px !important;
            -webkit-border-top-right-radius: 20px !important;
            -moz-border-radius-topleft: 20px !important;
            -moz-border-radius-topright: 20px !important;
            border-top-left-radius: 20px !important;
            border-top-right-radius: 20px !important;
            margin: 15px 15px 0 15px;
        }
        .in_fo{
            box-shadow: 0px 5px 10px 0px #cccccc !important;
            margin: 0 15px;
            padding-bottom: 20px;
            -webkit-border-bottom-right-radius: 20px;
            -webkit-border-bottom-left-radius: 20px;
            -moz-border-radius-bottomright: 20px;
            -moz-border-radius-bottomleft: 20px;
            border-bottom-right-radius: 20px;
            border-bottom-left-radius: 20px;
        }
        .m-form.m-form--group-seperator-dashed .m-form__group {
            border-bottom: 0px dashed #ebedf2;
            padding-bottom: 0;
            padding-top: 10px;
        }
        .m-portlet .m-form.m-form--fit > .m-portlet__body {
            padding-bottom: 40px !important;
        }
        .nav {
            display: -webkit-box;
        }
        .m-portlet {
            margin-bottom: 0;
        }
        .m-widget4 .m-widget4__item .m-widget4__info {
            width: 97.7%;
        }
		.setper {
    padding: 5px 2px;width: 100%;
}
.setper .sublab {
    margin-left: 5px;
}
.perlable {
    width: 11%;
}
    </style>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">

        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
								Permission
                            </h3>
                        </div>
                    </div>
                </div>

                <!--begin::Form-->
<?php echo form_open_multipart('admin/permission/store_permission',['id'=>'permission','class'=>'m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed']); ?>
<div class="m-portlet__body">
<div class="row thh">
<div class="col-lg-12">
<h3>Select User</h3>
</div>
</div>
<div class="in_fo">
<div class="form-group m-form__group row pp_col">
<div class="col-lg-12">
<select class="form-control" id="employee_id" name="user_id" required>
<option value="">Select employee </option>
<?php  foreach ($employees as $employee) {?>
<option value="<?php echo $employee['id']?>"><?php echo $employee['name']?></option>
<?php }?>	    
</select>
</div>
</div>
</div>
<div class="row thh">
<div class="col-lg-12">
<h3>Set Permission <div style=" float: right; "><input type="radio" name="chks" id="ckbCheckAll" /> Check All <input type="radio" name="chks"  id="unckbCheckAll" />  UnCheck All</div></h3>
</div>
</div>
<div class="in_fo">
<div class="form-group m-form__group row pp_col">
<?php
			$count = count($permission);
			foreach ($permission as $pm) { ?>
			<div class="setper">
				<label for="clients" class="form-control-label perlable"><b><?php echo $pm['name'];?>:</b></label>
				<?php if($pm['id']==1) { ?>
				<input type="checkbox" value="1" id="1<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Assign 
				<input type="checkbox" value="2" id="2<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Edit
				<input type="checkbox" value="3" id="3<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> View
				<input type="checkbox" value="4" id="4<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Add Mission 
				<input type="checkbox" value="5" id="5<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Delete
				<input type="checkbox" value="6" id="6<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Invoice
				<input type="checkbox" value="7" id="7<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Expense
				<?php } else { ?>
				
				
				<input type="checkbox" value="1" id="1<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Edit 
				<input type="checkbox" value="2" id="2<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Close
				<input type="checkbox" value="3" id="3<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> View
				<input type="checkbox" value="4" id="4<?php echo $pm['id'];?>" class="sublab" name="pm[<?php echo $pm['id'];?>][]"> Convert 
				
				
				<?php } ?>
			</div>
		<?php } ?>

	</div> 
</div>
</div>

<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
	<div class="m-form__actions m-form__actions--solid">
		<div class="row">
			<div class="col-lg-6">
			 <?php echo form_submit(['id'=>'add_permissions','value'=>'Submit','class'=>'btn btn-primary btn-lg']); ?>
			</div>
		</div>
	</div>
</div>
</form>

                <!--end::Form-->
            </div>

            <!--end::Portlet-->
        </div>
    </div>
<p id="msg"></p>
<?php include "footer.php";?>
<script type="text/javascript">
	
  	var url="<?= base_url('admin/permission/get_permission'); ?>"; 
	$('#employee_id').on('change',function(){
	    $(".sublab").prop('checked', false);
		var id=$(this).val();
		$.ajax({
		    type:'ajax',
		    method:'post',
		    url:url,
		    data:{"id" : id},
		    success:function(data){
			    var obj = $.parseJSON(data);   
					
				for(var i = 1; i < <?php echo $count; ?>+1; i++) {
				    var cube = obj[i];
				    	
				    for(var j = 1; j < 8; j++) {
				        var item = j+''+i;
				        if(cube[j] == 1){
				        	$("#" + item).prop('checked', true);
				        }
				    }
				}
		    },
		});
	})
	
$(document).ready(function () {
    $("#ckbCheckAll").click(function () {
            $(".sublab").prop('checked', true);
    });
	    $("#unckbCheckAll").click(function () {
       $(".sublab").prop('checked', false);
    });
});
</script>