<?php
include('header.php');

?>

    <style>
        .m-widget25 .m-widget25__price {
            color: #CAA459 !important;
        }
        .st_img{
            width: 100%;
            background: #1F3958;
            padding: 15px;
            border-radius: 30px;
        }
        .m-widget17 .m-widget17__stats {
            display: table;
            width: 100%;
            margin-top: 15px;
        }
        .m-widget17 .m-widget17__stats .m-widget17__items .m-widget17__item {
            position: unset !important;
            margin-top: 0 !important;
            margin-bottom: 40px !important;
            height: 11rem !important;
            padding-bottom: 10px !important;
        }
        .m-widget17__item:hover{
            background: #f3f3f3 !important;
        }
        .m-timeline-3 .m-timeline-3__item .m-timeline-3__item-desc .m-timeline-3__item-text {
            font-size: 1.5rem;
        }
        .m-timeline-3 .m-timeline-3__item .m-timeline-3__item-desc {
            display: block;
        }
        .m-timeline-3 .m-timeline-3__item .m-timeline-3__item-time {
            padding-top: 3px;
        }
    </style>


    <!-- END: Left Aside -->
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <div class="row">
			<?php if($this->session->userdata('role_id') == 1){ ?>
                <div class="col-xl-4">
                    <!--begin:: Widgets/Product Sales-->
                    <div class="m-portlet m-portlet--bordered-semi m-portlet--space m-portlet--full-height ">
                        <div class="m-portlet__body">
                            <div class="m-widget25">
								<a href="<?php  echo base_url('admin/employee/list_employee');?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <img src="<?php echo base_url('assets/images/'); ?>img/icons/V333.png" class="st_img" />
                                        </div>
                                        <div class="col-md-8" style="padding-top: 7%;">
                                            <span class="m-widget25__price m--font-brand"><?=$no_of_emp?></span><br>
                                            <span class="m-widget25__desc"><?php echo strtoupper($this->lang->line('Total_Employees'));?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!--end:: Widgets/Product Sales-->
                </div><?php } ?>
                <div class="col-xl-4">
                    <!--begin:: Widgets/Product Sales-->
                    <div class="m-portlet m-portlet--bordered-semi m-portlet--space m-portlet--full-height ">
                        <div class="m-portlet__body">
                            <div class="m-widget25">

                                <a href="<?php  echo base_url('admin/customer/list_customer');?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <img src="<?php echo base_url('assets/images/'); ?>img/icons/V333.png" class="st_img" />
                                        </div>
                                        <div class="col-md-8" style="padding-top: 7%;">
                                            <span class="m-widget25__price m--font-brand"><?=$no_of_cus?></span><br>
                                            <span class="m-widget25__desc"><?php echo $this->lang->line('TOTAL_CUSTOMERS');?></span>
                                        </div>
                                    </div>
                                </a>

                            </div>
                        </div>
                    </div>
                    <!--end:: Widgets/Product Sales-->
                </div>
                <div class="col-xl-4">
                    <!--begin:: Widgets/Product Sales-->
                    <div class="m-portlet m-portlet--bordered-semi m-portlet--space m-portlet--full-height ">
                        <div class="m-portlet__body">
                            <div class="m-widget25">

                                <a href="<?php  echo base_url('admin/c_case/list_case');?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <img src="<?php echo base_url('assets/images/'); ?>img/icons/E-111.png" class="st_img" />
                                        </div>
                                        <div class="col-md-8" style="padding-top: 7%;">
                                            <span class="m-widget25__price m--font-brand"><?=$no_of_case?></span><br>
                                            <span class="m-widget25__desc"><?php echo $this->lang->line('TOTAL_E_SERVICES');?></span>
                                        </div>
                                    </div>
                                </a>

                            </div>
                        </div>
                    </div>
                    <!--end:: Widgets/Product Sales-->
                </div>	
				
            </div>

            <div class="row">

                <div class="col-xl-12 col-lg-12">

                    <!--Begin::Portlet-->
                    <div class="m-portlet  m-portlet--full-height  m-portlet--rounded">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo $this->lang->line('Reminders_&_Alerts');?>
                                    </h3>
                                </div>
                            </div>

                        </div>

                        <div class="m-portlet__body">

                            <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <thead>
                                    <tr class="netTr">

                                        <th><?php echo $this->lang->line('PROJECT_PLANING');?></th>
                                      
                                        <th><?php echo $this->lang->line('Consultation');?></th>
                                        <th><?php echo $this->lang->line('Visiting');?></th>
                                        <th><?php echo $this->lang->line('WRITING');?></th>
                                        <th><?php echo $this->lang->line('Session');?></th>
                                        <th><?php echo $this->lang->line('GENERAL');?></th>
                                        <th></th>

                                    </tr>
                                    </thead>
                                    <tbody>
		<?php foreach ($all_report as $value) {?>
            <tr style="text-align: center;">
                <td><a href="<?php echo base_url("admin/project/list_project");?> "><?php echo $value[1]; ?></a></td>
                <td><a href="<?php echo base_url("admin/mission_consultation/list_mission");?> "><?php echo $value[3]; ?></a></td>
                <td><a href="<?php echo base_url("admin/mission_visiting/list_mission");?> "><?php echo $value[4]; ?></a></td>
                <td><a href="<?php echo base_url("admin/mission_writings/list_mission");?> "><?php echo $value[5]; ?></a></td>
                <td><a href="<?php echo base_url("admin/mission_session/list_mission");?> "><?php echo $value[6]; ?></a></td>
                <td><a href="<?php echo base_url("admin/mission_general/list_mission");?> "><?php echo $value[7]; ?></a></td>
				<td><b><?php echo $value[8]; ?></b></td>
                
            </tr>
        <?php } ?>
                                    </tbody>
                                </table>
								
								<table class="table table-hover table-striped">
                                    <thead>
                                    <tr class="netTr">
                                    
                                         <th><?php echo $this->lang->line('Consultation');?></th>
                                        <th><?php echo $this->lang->line('Visiting');?></th>
                                        <th><?php echo $this->lang->line('WRITING');?></th>
                                        <th><?php echo $this->lang->line('Session');?></th>
                                        <th><?php echo $this->lang->line('GENERAL');?></th>
                                             <th><?php echo $this->lang->line('ASSIGNMENT');?></th>
                                        <th></th>

                                    </tr>
                                    </thead>
                                    <tbody>
									<?php foreach ($all_report_re as $value) {?>
										<tr style="text-align: center;">
										        
           
												<td><a href="<?php echo base_url("admin/mission_consultation/list_mission");?> "><?php echo $value[3]; ?></a></td>
											<td><a href="<?php echo base_url("admin/mission_visiting/list_mission");?> "><?php echo $value[4]; ?></a></td>
											<td><a href="<?php echo base_url("admin/mission_writings/list_mission");?> "><?php echo $value[5]; ?></a></td>
											<td><a href="<?php echo base_url("admin/mission_session/list_mission");?> "><?php echo $value[6]; ?></a></td>
											<td><a href="<?php echo base_url("admin/mission_general/list_mission");?> "><?php echo $value[7]; ?></a></td>
											 <td><a href="<?php echo base_url("admin/assignment/list_assignment_case");?> "><?php echo $value[8]; ?></a></td>
											<td><b><?php echo $value[9]; ?></b></td>
											
										</tr>
									<?php } ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-xl-6 col-lg-12">

                    <!--Begin::Portlet-->
                    <div class="m-portlet  m-portlet--full-height  m-portlet--rounded">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo $this->lang->line('Recent_E_Services');?>
                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <ul class="nav nav-pills nav-pills--brand m-nav-pills--align-right m-nav-pills--btn-pill m-nav-pills--btn-sm" role="tablist">
                                    <li class="nav-item m-tabs__item">
                                        <a href="<?php echo base_url('admin/c_case/list_case'); ?>" class="btn btn-primary btn-sm pull-right"><?php echo $this->lang->line('View_all');?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="m-portlet__body">

                            <div class="col-xl-12">
                                <!--begin:: Widgets/Activity-->
                                <div class="">
                                    <div class="">
                                        <div class="m-widget17">
                                            <div class="m-widget17__stats">

                                                <div class="row">
<?php $count=0; foreach ($recent_case as $recent_case) { $count++; ?>
                                                    <div class="col-md-4">
                                                        <a href="<?php echo base_url('admin/c_case/customer_case_list/'.$recent_case['customers_id']);?>">
                                                            <div class="m-widget17__items m-widget17__items-col1">
                                                                <div class="m-widget17__item">
                                                            <span class="m-widget17__icon"><?php if($recent_case['is_reject'] == 1){ ?>
								<span class="m-badge  m-badge--danger m-badge--wide"><?php echo $this->lang->line('Reject');?></span>
								<?php } else if(isset($recent_case['case_id'])) { ?>
								<span class="m-badge  m-badge--warning m-badge--wide"><?php echo $this->lang->line('Pending');?></span>
								<?php }else{ ?>
								<span class="m-badge  m-badge--success m-badge--wide"><?php echo $this->lang->line('Approve');?></span>
								<?php }?>
                                                            </span>
                                                                    <span class="m-widget17__subtitle"><?= getServiceName($recent_case['service_types']) ?></span>
                                                                    <span class="m-widget17__desc"><?php echo $this->lang->line('Number');?>: <?=$recent_case['case_number'];?></span>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
<?php } ?>
                                                   
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--end:: Widgets/Activity-->
                            </div>
                        </div>
                    </div>

                    <!--End::Portlet-->
                </div>

                <div class="col-xl-6 col-lg-12">
                    <!--Begin::Portlet-->
                    <div class="m-portlet m-portlet--full-height ">

                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo $this->lang->line('New_Customers');?>
                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <ul class="nav nav-pills nav-pills--brand m-nav-pills--align-right m-nav-pills--btn-pill m-nav-pills--btn-sm" role="tablist">
                                    <li class="nav-item m-tabs__item">
                                        <a href="<?php echo base_url('admin/customer/list_customer'); ?>" class="btn btn-primary btn-sm pull-right"><?php echo $this->lang->line('View_all');?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="m-portlet__body">
						<?php  $count=0; foreach ($new_cus as $new_cus) { $count++; ?>
                            <div class="m-timeline-3" style="<?php if ($count % 2 == 0) echo "background: #f3f3f3;";  ?> padding: 8px 10px 1px 5px;">
                                <div class="m-timeline-3__items">
                                    <div class="m-timeline-3__item m-timeline-3__item--brand">
                                        <span class="m-timeline-3__item-time"><?=$new_cus['id'];?></span>
                                        <div class="m-timeline-3__item-desc">
                                            <div class="row">
                                                <div class="col-md-10">
                                                    <span class="m-timeline-3__item-text"><?=$new_cus['client_name'];?></span>
                                                </div>
                                                <div class="col-md-2" style="text-align: right;">
                                                    <a href="<?php echo base_url('admin/customer/view_customer/'.$new_cus['id']);?>" class="m-link m-link--metal m-timeline-3__item-link"><i class="fa fa-eye"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
	<?php } ?>
                       
                        </div>
                    </div>
                    <!--End::Portlet-->
                </div>
				 <div class="col-xl-6 col-lg-12">
                    <!--Begin::Portlet-->
                    <div class="m-portlet m-portlet--full-height ">

                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                     <?php    //echo $this->lang->line('New_Customers');?> Functional works
                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                 
                            </div>
                        </div>
		<style>
		 
.todotop{
	    background: green;
    color: #fff;
    padding: 0 5px;
    font-size: 10px;
    border-radius: 5px 5px 0px 0px;
}
		</style>
	<div class="m-portlet__body" style=" overflow: auto;    height: 300px; ">
		<span class="addtext"></span>
	<?php  $count=0; foreach ($todo_list as $tl) { $count++; ?>
	<div class="todotop" style="<?php if ($tl['admin_id']!=0) echo "background: #1f3959;font-weight: bold;";  ?>"><?php $timestamp = strtotime($tl['create_date']); echo  date("d M Y G:i",$timestamp); ?><span style=" float: right; "><?php if($tl['admin_id']!=0) { echo "By ".getEmployeeName($tl['admin_id']); } else {echo "By You"; } if($this->session->userdata('role_id') == 1){ echo " | Send to ".getEmployeeName($tl['user_id']);  } ?></span></div>
                            <div class="" style="background: #f3f3f3; padding: 8px 10px 1px 5px;">
							 
                                    <div class="m-timeline-3__item m-timeline-3__item--brand">
										<?php echo $tl['note']; ?>
                                    </div>
                               
                            </div>
							<br>
	<?php } ?>
					
                       
                        </div>
							<br>
					<br>
					<br>
                    </div>
				
					 <div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit" style=" background: #f3f3f3; padding: 10px; margin-top: -85px; border-radius: 0px 0px 20px 20px; ">
                        <div class="m-form__actions m-form__actions--solid">
                            <div class="row">
                                <div class="col-lg-9">
								 <?php if($this->session->userdata('role_id') == 1){ ?> <select class="form-control" style=" margin-bottom: 5px; " id="employee_id" name="employee_id"><option value="">Select employee </option><?php  foreach ($emp_name as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select>
								 <span class="err" style="color:red"></span>
								<?php }    ?>  	 
								<div class="col-lg-3">
                                </div>
                                </div>
								
                                <div class="col-lg-9">
                                
								<?php  echo form_input(['id'=>'addtodotext','placeholder'=>'Note','type'=>'text','class'=>'form-control']);  ?>  
								<span class="errn" style="color:red"></span>								
                                </div>
								 <div class="col-lg-3">
								 <?php echo form_submit(['id'=>'addtodo','value'=>$this->lang->line('Submit'),'class'=>'btn btn-primary btn-lg']);  ?>  	
                                </div>
                            
                            </div>
                        </div>
                    </div>
                    <!--End::Portlet-->
                </div>
                   <div class="col-xl-6 col-lg-12" style="display:none">
                    <!--Begin::Portlet-->
                    <div class="m-portlet m-portlet--full-height ">

                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                     <?php    //echo $this->lang->line('New_Customers');?> Notification
                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                 
                            </div>
                        </div>
		<style>
		.empnotificion span.m-timeline-3__item-text {
    font-size: 15px !important;
}
		</style>
	
                        <div class="m-portlet__body empnotificion">
                         <div class="m-scrollable" data-scrollable="true" data-height="350" data-mobile-height="300" style="width: 100%;padding: 15px;">

                                <!--Begin::Timeline 2 -->
                                <div class="m-timeline-2" id="m-timeline-2">
                                    <div class="m-timeline-2__items  m--padding-top-25 m--padding-bottom-30">
									<?php
									
									if($this->session->userdata('role_id') == 1){
									    
									$this->db->select('*');
									$files = $this->db->order_by("id", "desc")->get('notification')->result_array();
									
									} else {
								    $cid = $this->session->userdata('admin_id');
									$this->db->select('*')->where("(user_id='$cid')", NULL, FALSE);
									$files = $this->db->order_by("id", "desc")->get('notification')->result_array();
									}
									foreach ($files as $n) { ?>
									<?php if($n['status_type'] == 'logout'){ ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
                                                <?php echo $this->lang->line('Logged_out_successfully');?>
                                            </div>
                                        </div>
									<?php } ?>
									<?php if($n['status_type'] == 'login'){ ?>
									<?php $dinfo = json_decode($n['device_log']);  ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
                                                <?php echo $this->lang->line('Logged_in_from');?> <?php echo $dinfo->name; echo " "; echo $dinfo->platform; ?> <br> <?php echo $this->lang->line('from_IP');?>: <?php echo $n['login_ip'];?>
                                            </div>
                                        </div>
									<?php } ?>
									
									<?php if($n['status_type'] == 'register'){ ?>
									<?php $dinfo = json_decode($n['device_log']);  ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item  <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
Registration successfully  <?php echo $dinfo->name; echo " "; echo $dinfo->platform; ?>  A<?php echo $this->lang->line('from_IP');?>: <?php echo $n['login_ip'];?>
                                            </div>
                                        </div>
									<?php } ?>
									<?php if($n['notification_type'] == 'msg'){ ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item  <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
                                                <?php echo $this->lang->line('You_have_New_message');?> 
                                            </div>
                                        </div>
			 
									<?php } ?>
									<?php if($n['notification_type'] == 'invoice'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-brand"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/alert/") ?>" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                                <?php echo $this->lang->line('Your_invoice_for_case');?> (#<?php echo getCaseNumber($n['case_id']) ;?>)  <?php echo $this->lang->line('has_been_created');?>
												</a>
                                            </div>
                                        </div>
										<?php } ?>
										<?php if($n['notification_type'] == 'case'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?php echo base_url("/front/view_case/{$n['case_id']}") ?>"  class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>"><span  >#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Your_e_service_has_been_added');?></span></a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'reject'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
										<a href="<?= base_url("/front/view_case/{$n['case_id']}") ?>"  class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>"><span >#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Your_e_service_has_been_rejected');?></span></a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'approve'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-brand"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_case/{$n['case_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>"><span style="color:green">#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Your_e_service_has_been_approved');?></span></a>
                                            </div>
                                        </div>
										<?php } ?>
 
										 <?php } ?>
										<?php if($n['notification_type'] == 'session_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Session_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Session_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 
										<?php if($n['notification_type'] == 'general_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_general_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('General_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_general_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('General_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 
										 <?php if($n['notification_type'] == 'visiting_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_visiting_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Visiting_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_visiting_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Visiting_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 <?php if($n['notification_type'] == 'consultation_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_consultation_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Consultation_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_consultation_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Consultation_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 
										 <?php if($n['notification_type'] == 'writings_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_writings_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Writing_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_writings_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Writing_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 <?php } ?>
                                    </div>
                                </div>

                                <!--End::Timeline 2 -->
                            </div>      
                        </div>
                    </div>
                    <!--End::Portlet-->
                </div>
                <div class="col-xl-6 col-lg-12">
                    
                  <div class="" style=" margin-top: 40px; "></div>
                    <!--Begin::Portlet-->
                    <div class="m-portlet m-portlet--full-height ">

                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                     <?php    //echo $this->lang->line('New_Customers');?> Messagess
                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                 
                            </div>
                        </div>
		<style>
		.empnotificion span.m-timeline-3__item-text {
    font-size: 15px !important;
}
		</style>
	
                        <div class="m-portlet__body empnotificion">
						<?php    $count=0; foreach ($employee_notification as $en) { $count++; ?>
                            <div class="m-timeline-3" style="<?php if ($count % 2 == 0) echo "background: #f3f3f3;";  ?> padding: 8px 10px 1px 5px;">
                                <div class="m-timeline-3__items">
                                    <div class="m-timeline-3__item m-timeline-3__item--brand">
                                        <span class="m-timeline-3__item-time"><?php $timestamp = strtotime($en['create_date']); echo  date("G:i",$timestamp);?></span>
                                        <div class="m-timeline-3__item-desc">
                                            <div class="row">
											<?php 
												$type = $en['type'];
												if($type == "session"){
													$mt = "You have new message in session mission";
													$link = "mission_session/find_mission/".$en['app_id'];
												}
												if($type == "consultati"){
													$mt = "You have new message in consultation mission";
													$link = "mission_consultation/find_mission/".$en['app_id'];
												}
												if($type == "general"){
													$mt = "You have new message in general mission";
													$link = "mission_general/find_mission/".$en['app_id'];
												}
												if($type == "visiting"){
													$mt = "You have new message in visiting mission";
													$link = "mission_visiting/find_mission/".$en['app_id'];
												}
												if($type == "writing"){
													$mt = "You have new message in writing mission";
													$link = "mission_writings";
												}
												if($type == "fine"){
													$mt = "You have new fine";
													$link = "hr/list_hr_fine";
												}
												if($type == "hre"){
													$mt = "Your HR service has been ".$en['note'];
													$link = "hr/list_hr_eservice";
												}
												if($type == "project"){
													$mt = "You have new message in project";
													$link = "project/find_project/".$en['app_id'];
												}
												?>
												
                                                <div class="col-md-10">
                                                    <span class="m-timeline-3__item-text" style="<?php if ($en['view'] == 0){ echo "font-weight:bold;"; }?> padding: 8px 10px 1px 5px;"><?php echo $mt ?></span>
                                                </div>
                                                <div class="col-md-2" style="text-align: right;">
                                                    <a href="<?php echo base_url("admin/$link");?>" class="m-link m-link--metal m-timeline-3__item-link" data-read="<?php echo $en['id']; ?>" id="readnotificaion"><i class="fa fa-eye"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
	<?php } ?>
                       
                        </div>
                    </div>
                    <!--End::Portlet-->
                </div>
               
            </div>


            <!--End::Section-->
        </div>
    </div>



<?php

include('footer.php');
?>
<script>
$('[id="addtodo"]').on('click', function(){
	var val=$('#addtodotext').val();  
	 	var  empid = $('#employee_id :selected').val();
		if(empid == ''){
			$('.err').html('Employee is required'); return false;
		} else {
			$('.err').html(''); 
		}
		if(val==''){
			$('.errn').html('Note is required'); return false;
		} else{
			$('.errn').html(''); 
		}
	var url="<?=base_url('admin/dashboard/to_do_list');?>";
    $.ajax({
		type:'ajax',
		method:'post',
		url:url,
		data:{"note" : val,'user_id':empid},
		success:function(data){
			$(".addtext").after(data);
		 $('#addtodotext').val('');  
		  
		}
	});
});
$('[id="readnotificaion"]').on('click', function(){
	var id=$(this).data("read");  
	var url="<?=base_url('admin/dashboard/read_notification_status');?>";
    $.ajax({
		type:'ajax',
		method:'post',
		url:url,
		data:{"id" : id},
		success:function(data){
		  $('.noticount').html(data);
		}
	});
});
</script>