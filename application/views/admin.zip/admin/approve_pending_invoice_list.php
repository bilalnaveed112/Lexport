<?php
include('header.php');

?>
    <style>
        .nav {
            display: -webkit-box;
        }
    </style>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Financial');?>
                            </h3>
                        </div>
                    </div>
                </div>
				<?php echo $this->session->flashdata('showMsg'); ?>
                <div class="m-portlet__body">
                    <!-- Sec tabs --->
                    <ul class="nav nav-tabs" role="tablist">
                       <li class="nav-item">
                            <a class="nav-link" data-toggle="" href="<?php echo base_url('admin/finance'); ?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('List');?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="" href="<?php echo base_url('admin/finance/expenses_list'); ?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Expense_List');?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo base_url('admin/finance/approve_pending_invoice_list'); ?>" data-target=" "><?php echo $this->lang->line('Pending_Invoice');?></a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
                            <div class="">
 
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped" id="m_datatable">
                                            <thead>
                                            <tr class="netTr">

                                                <th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Case_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('File_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Client_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Phone');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                  <th>Main <?php echo $this->lang->line('Invoice_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Invoice_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Created_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Created_Time');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Due_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Due_Time');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Created_By');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Invoice_Title');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Total_Cost');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('VAT_0_5');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Total_Amount');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Status');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                
                                                <th><?php echo $this->lang->line('ACTION');?></th>

                                            </tr>
                                            </thead>
                                            <tbody>
						 <?php $i=0; foreach ($invoice as $invoice){ $i++; ?>
                      <tr class="hide<?php echo $invoice['id'] ?>">
                        <td><?= $i; ?></td>
                        <td><?= $invoice['case_number'] ?></td>
                        <td><?= $invoice['client_file_number'] ?></td>
                        <td><?= $invoice['client_name'] ?></td>
             <td><?= getCustomerMobile($invoice['customers_id']) ?></td>
                             <td><?= $invoice['main_invoice_no'] ?></td>
						<td><?= $invoice['invoice_no'] ?></td>
                    	<td><?php $timestamp = strtotime($invoice['create_date']); echo  getTheDayAndDateFromDatePan(date("d/m/Y",$timestamp));?></td>
						<td><?php $timestamp = strtotime($invoice['create_date']); echo  date("h:i a",$timestamp);?></td>
                        <td><?= $invoice['due_date'] ?></td>
                        <td><?= $invoice['due_time'] ?></td>
                        <td><?php echo getEmployeeName($invoice['created_by']); ?></td>
						<td><?= $invoice['invoice_title'] ?></td>
						<td><?php  $vat = $invoice['main_total']/$invoice['financial_payments']; echo number_format((float)$vat, 2, '.', '');?></td>
						<td><?php $assd=  ($vat * 5) / 100;  echo number_format((float)$assd, 2, '.', '');?></td>
						<td><?= $invoice['total'] ?></td>
						<td><?= $invoice['payment_status'] ?></td>
				
						<td class="action">
						    		<?php if($invoice['is_reject'] == 1) { ?>
						    			<span class="m-badge  m-badge--danger m-badge--wide"><?php echo $this->lang->line('Reject');?></span>
							
						    		<?php } else { ?>
						<a  href='<?= base_url("admin/finance/edit_invoice/{$invoice['id']}"); ?>' class="fa fa-edit" title="Edit Invoice"></a>
					<?php if($invoice['created_by'] == $this->session->userdata('admin_id') || $this->session->userdata('role_id') == 1){  ?>
					<a href=<?= base_url("admin/finance/approve_pending_invoice/{$invoice['id']}") ?>  title="Approve " class="fa fa-check-circle"></a>  
			
					<a href=<?= base_url("admin/finance/reject_pending_invoice/{$invoice['id']}") ?>  title="Reject " class="fa fa-ban"></a> 
					<?php } } ?>
					</td>
                    </tr>
					<?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                     
                                </div>


                            </div>
                        </div>
                       
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php

include('footer.php');

?> <script type="text/javascript">
$(document).ready(function() {
	$('#msg').hide();
});
</script>
<script type="text/javascript">

<?php if(isset($datas[2][3]) && $datas[2][3] == 1){?>
  $('.dataTables_filter').show();
<?php }else{?>
  $('.dataTables_filter').hide();
<?php } ?>
$("#m_datatable").on("click", ".delete_case", function() {
var id=$(this).attr("id");
var url="<?= base_url('admin/finance/delete_invoice'); ?>"; 
bootbox.confirm("Are you sure?", function(result){
if(result){
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);
      },
  });
$('.hide'+id).hide(200);
return true;
}
else
{
$('#msg').show();
	$('#msg').html('delete failed');
}
})
});
$('#clientsel').on('change', function() {
var url="<?= base_url('admin/archive/select_case'); ?>"; 
var id = this.value;
$.ajax({
  type:'ajax',
  method:'post',
  url:url,
  data:{"id" : id},
  success:function(data){
 
	$('#casesel').html(data);
  },
});
});
</script> 