<?php
include('header.php');

?>

    <style>
        .m-form.m-form--fit .m-form__content, .m-form.m-form--fit .m-form__heading, .m-form.m-form--fit .m-form__group {
            padding-left: 0px;
            padding-right: 0px;
        }
        .m-portlet__body{
            padding: 30px !important;
        }
    </style>

    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('View_Customer');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body" style="padding-bottom: 0 !important;">
                    <ul>
                        <li><h3><b><?php echo $this->lang->line('client_File_number');?>:</b> <?php echo $data->client_file_number; ?></h3></li>
 
                          <li><h3><b><?php echo $this->lang->line('Date');?>:</b> <?php  $date= date("d/m/Y", strtotime($data->createdate)); echo getTheDayAndDateFromDatePan($date); ?></h3></li>
                    </ul>
                </div>

                <!--begin::Form-->
                <form class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed">
                    <div class="m-portlet__body">

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Customer_Information');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-3">
                                <label><?php echo $this->lang->line('Identification_Numbers');?>:</label>
                                <input type="text" class="form-control m-input" value="<?php echo $data->identification_number;?>" readonly>
                            </div>
                            <div class="col-lg-3">
                                <label class=""><?php echo $this->lang->line('Email');?>:</label>
                                <input type="text" class="form-control m-input" readonly value="<?php echo $user['email'];?>">
                            </div>
                            <div class="col-lg-3">
                                <label><?php echo $this->lang->line('client_File_number');?>:</label>
                                <input type="text" class="form-control m-input" readonly value="<?php echo $data->client_file_number;?>">

                            </div>
                            <div class="col-lg-3">
                                <label class=""><?php echo $this->lang->line('client_full_name');?>:</label>
                                <input type="text" class="form-control m-input" readonly value="<?php echo $data->client_name;?>">
                            </div>

                            <div class="col-lg-3">
                                <label class=""><?php echo $this->lang->line('Contact_number');?>:</label>
                                <input type="text" class="form-control m-input" readonly value="<?php echo $data->contact_number;?>">
                            </div>

                            <div class="col-lg-3">
                                <label class=""><?php echo $this->lang->line('branch');?></label>
                                <input type="text" class="form-control m-input" readonly value="<?php echo getBranchName($data->branch);?>">
                            </div>

                            <div class="col-lg-3">
                                <label class=""><?php echo $this->lang->line('City');?></label>
                                <input type="text" class="form-control m-input" readonly value="<?php if($data->city){ echo getCityByID($data->city); } ?>">
                            </div>
                        </div>


                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('E_SERVICES_LIST');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('E_Service_No');?></th>
                                            <th><?php echo $this->lang->line('Name');?></th>
                                            <th><?php echo $this->lang->line('E_Service_Name');?></th>
                                            <th><?php echo $this->lang->line('Contract_No');?></th>
                                            <th><?php echo $this->lang->line('ACTION');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
										   <?php foreach ($case_list as $case){ ?>
                      <tr style="text-align: center;" class="hide<?php echo $case['id'] ?>">
                        <td><?= $case['case_number'] ?></td>
                        <td><?= $case['client_name'] ?></td>
                        <td><?= getServiceType($case['service_types']) ?></td>
                        <td><?= $case['contract_number'] ?></td>
					<td>
						<span style="overflow: visible; position: relative;">
							<a href="<?= base_url("admin/c_case/edit_case/{$case['id']}"); ?>#armanage" class="btn btn-primary" title=""><?php echo $this->lang->line('Archives');?></a>
						</span>
					</td>
                </tr> <?php } ?>
                                       

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Session');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('No');?></th>
                                            <th><?php echo $this->lang->line('E_Service_No');?></th>
                                            <th><?php echo $this->lang->line('Sub_Mission');?></th>
                                            <th><?php echo $this->lang->line('Session_Number');?></th>
                                            <th><?php echo $this->lang->line('Session_Date');?></th>
                                            <th><?php echo $this->lang->line('Session_End_Date');?></th>
                                            <th><?php echo $this->lang->line('Client_Name');?></th>
                                            <th><?php echo $this->lang->line('Note');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                         <?php 
              $count=1;
              foreach($session as $appoinment){  ?>
              <tr style="text-align: center;" class="hide<?php echo $appoinment['id'] ?>">
                <td><?= $count++ ?></td>
				<td><?= $appoinment['case_number'] ?></td>
				<td><a href="https://albarakatilaw.com/admin/mission_session/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"session_mission"); ?></a> </td>
                <td><?= $appoinment['session_number'] ?></td>
                
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_date']);?></td>
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']) ?></td>
                <td><?= $appoinment['client_name'] ?></td>
                <td><?= $appoinment['note'] ?></td>
       
		        <!--      <td class="action">
                    <?php if(isset($datas[3][2]) && $datas[3][2] == 1){?>
                    <a href=<?= base_url("admin/appoinment/find_session_appoinment/{$appoinment['id']}") ?> class="btn btn-outline-primary fa fa-pencil-square-o editadmin" id=<?= $appoinment['id'] ?>></a>
                   <?php  } ?>
                    <a href="javascript:;" class="btn btn-outline-danger fa fa-trash delete_appoinment" id=<?= $appoinment['id'] ?>></a>
        				    <a href=<?= base_url("admin/appoinment/view_session_appoinment/{$appoinment['id']}") ?>  title="View Case " class="fa fa-eye btn btn-outline-success" target="_blnak"></a>
                </td> -->
              </tr>
            <?php } ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Writings');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('No');?></th>
                                            <th><?php echo $this->lang->line('E_Service_No');?></th>
                                            <th><?php echo $this->lang->line('Sub_Mission');?></th>
                                            <th><?php echo $this->lang->line('Writing_Number');?></th>
                                            <th><?php echo $this->lang->line('Writing_Date');?></th>
                                            <th><?php echo $this->lang->line('Writing_End_Date');?></th>
                                            <th><?php echo $this->lang->line('Client_Name');?></th>
                                            <th><?php echo $this->lang->line('Note');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>


                                            <?php 
              $count=1;
              foreach($writings as $appoinment){  ?>
              <tr style="text-align: center;" class="hide<?php echo $appoinment['id'] ?>">
                <td><?= $count++ ?></td>
				   <td><?= $appoinment['case_number'] ?></td>
				   <td><a href="https://albarakatilaw.com/admin/mission_writings/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"writing_misssion"); ?></a> </td>
                <td><?= $appoinment['session_number'] ?></td>
                
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_date']);?></td>
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']) ?></td>
                <td><?= $appoinment['client_name'] ?></td>
                <td><?= $appoinment['note'] ?></td>
               
		          <!--    <td class="action">
                  <?php if(isset($datas[4][2]) && $datas[4][2] == 1){?> 
                  <a href=<?= base_url("admin/appoinment/find_writings_appoinment/{$appoinment['id']}") ?> class="btn btn-outline-primary fa fa-pencil-square-o editadmin" id=<?= $appoinment['id'] ?>></a>
                  <?php } ?>
                  <a href="javascript:;" class="btn btn-outline-danger fa fa-trash delete_writings" id=<?= $appoinment['id'] ?>></a>
                 <a href=<?= base_url("admin/appoinment/view_writings_appoinment/{$appoinment['id']}") ?>  title="View Case " class="fa fa-eye btn btn-outline-success" target=""></a>
                </td>-->
              </tr>
            <?php } ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Consultation');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('No');?></th>
                                            <th><?php echo $this->lang->line('E_Service_No');?></th>
                                            <th><?php echo $this->lang->line('Sub_Mission');?></th>
                                            <th><?php echo $this->lang->line('Consultation_Number');?></th>
                                            <th><?php echo $this->lang->line('Consultation_Date');?></th>
                                            <th><?php echo $this->lang->line('Consultation_End_Date');?></th>
                                            <th><?php echo $this->lang->line('Client_Name');?></th>
                                            <th><?php echo $this->lang->line('Note');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
  <?php 
              $count=1;
              foreach($consultation as $appoinment){  ?>
              <tr style="text-align: center;" class="hide<?php echo $appoinment['id'] ?>">
                <td><?= $count++ ?></td>
			   <td><?= $appoinment['case_number'] ?></td>
			     <td><a href="https://albarakatilaw.com/admin/mission_consultation/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"consultation_mission"); ?></a> </td>
                <td><?= $appoinment['session_number'] ?></td>
                
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_date']);?></td>
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']) ?></td>
                <td><?= $appoinment['client_name'] ?></td>
                <td><?= $appoinment['note'] ?></td>
             
		         <!--     <td class="action">
                <?php if(isset($datas[5][2]) && $datas[5][2] == 1){?>
                  <a href=<?= base_url("admin/appoinment/find_consultation_appoinment/{$appoinment['id']}") ?> class="btn btn-outline-primary fa fa-pencil-square-o editadmin" id=<?= $appoinment['id'] ?>></a>
                <?php } ?>  
                  <a href="javascript:;" class="btn btn-outline-danger fa fa-trash delete_consultation" id=<?= $appoinment['id'] ?>></a>
                  <a href=<?= base_url("admin/appoinment/view_consultation_appoinment/{$appoinment['id']}") ?>  title="View Case " class="fa fa-eye btn btn-outline-success" target=""></a>
                </td> -->
              </tr>
            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Visiting');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('No');?></th>
                                            <th><?php echo $this->lang->line('E_Service_No');?></th>
                                            <th><?php echo $this->lang->line('Sub_Mission');?></th>
                                            <th><?php echo $this->lang->line('Visiting_Number');?></th>
                                            <th><?php echo $this->lang->line('Visiting_Date');?></th>
                                            <th><?php echo $this->lang->line('Visiting_End_Date');?></th>
                                            <th><?php echo $this->lang->line('Client_Name');?></th>
                                            <th><?php echo $this->lang->line('Note');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                       <?php 
              $count=1;
              foreach($visiting as $appoinment){  ?>
              <tr style="text-align: center;"  class="hide<?php echo $appoinment['id'] ?>">
                <td><?= $count++ ?></td>
				   <td><?= $appoinment['case_number'] ?></td>
	   		     <td><a href="https://albarakatilaw.com/admin/mission_visiting/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"visiting_mission"); ?></a> </td>
                <td><?= $appoinment['session_number'] ?></td>
                
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_date']);?></td>
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']) ?></td>
                <td><?= $appoinment['client_name'] ?></td>
                <td><?= $appoinment['note'] ?></td>
               
		         <!--     <td class="action">
                  <?php if(isset($datas[6][2]) && $datas[6][2] == 1){?>
                  <a href=<?= base_url("admin/appoinment/find_visiting_appoinment/{$appoinment['id']}") ?> class="btn btn-outline-primary fa fa-pencil-square-o editadmin" id=<?= $appoinment['id'] ?>></a>
                  <?php }?>
                  <a href="javascript:;" class="btn btn-outline-danger fa fa-trash delete_visiting" id=<?= $appoinment['id'] ?>></a>
				   <a href=<?= base_url("admin/appoinment/view_visiting_appoinment/{$appoinment['id']}") ?>  title="View Case " class="fa fa-eye btn btn-outline-success" target=""></a>
                </td> -->
              </tr>
            <?php } ?>

                                       
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>


                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('GENERAL');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('No');?></th>
                                            <th><?php echo $this->lang->line('E_Service_No');?></th>
                                            <th><?php echo $this->lang->line('Sub_Mission');?></th>
                                            <th><?php echo $this->lang->line('General_Number');?></th>
                                            <th><?php echo $this->lang->line('General_Date');?></th>
                                            <th><?php echo $this->lang->line('General_End_Date');?></th>
                                            <th><?php echo $this->lang->line('Client_Name');?></th>
                                            <th><?php echo $this->lang->line('Note');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                       <?php 
              $count=1;
              foreach($general as $appoinment){  ?>
              <tr style="text-align: center;"  class="hide<?php echo $appoinment['id'] ?>">
                <td><?= $count++ ?></td>
				   <td><?= $appoinment['case_number'] ?></td>
				    <td><a href="https://albarakatilaw.com/admin/mission_general/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"general_mission"); ?></a> </td>
                <td><?= $appoinment['session_number'] ?></td>
                
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_date']);?></td>
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']) ?></td>
                <td><?= $appoinment['client_name'] ?></td>
                <td><?= $appoinment['note'] ?></td>
            
		         <!--     <td class="action">
                  <?php if(isset($datas[6][2]) && $datas[6][2] == 1){?>
                  <a href=<?= base_url("admin/appoinment/find_visiting_appoinment/{$appoinment['id']}") ?> class="btn btn-outline-primary fa fa-pencil-square-o editadmin" id=<?= $appoinment['id'] ?>></a>
                  <?php }?>
                  <a href="javascript:;" class="btn btn-outline-danger fa fa-trash delete_visiting" id=<?= $appoinment['id'] ?>></a>
				   <a href=<?= base_url("admin/appoinment/view_visiting_appoinment/{$appoinment['id']}") ?>  title="View Case " class="fa fa-eye btn btn-outline-success" target=""></a>
                </td> -->
              </tr>
            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Project_List');?><br>&nbsp;</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                        <tr class="netTr">
                                            <th><?php echo $this->lang->line('No');?></th>
                                            <th><?php echo $this->lang->line('Project_Name');?></th>
                                            <th><?php echo $this->lang->line('E_service');?></th>
                                            <th><?php echo $this->lang->line('Client_Name');?></th>
                                            <th><?php echo $this->lang->line('Status');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                         <?php 
              $count=1; 
              foreach($projects as $project){   ?>
              <tr style="text-align: center;"   class="hide<?php echo $project['id'] ?>">
                <td><?= $count++ ?></td>
                <td><?= $project['project_name'] ?></td>
                <td><?= $project['case'] ?></td>
                <td><?= $project['client_name'] ?></td>
                <td><?= $project['project_status'] ?></td>
		          <!--    <td class="action">
                  <?php if(isset($datas[10][2]) && $datas[10][2] == 1){?>
                    <a href=<?= base_url("admin/project/find_project/{$project['id']}") ?> class="btn btn-outline-primary fa fa-pencil-square-o editadmin" id=<?= $project['id'] ?>></a>
                  <?php } ?>
                  <a href="javascript:;" class="btn btn-outline-danger fa fa-trash delete_consultation" id=<?= $project['id'] ?>></a>
                   <a href=<?= base_url("admin/project/view_project/{$project['id']}") ?>  title="View project" class="fa fa-eye btn btn-outline-success" target="_blnak"></a>
                  <!-- <a href="javascript:;" class="btn btn-outline-success fa fa-file " id=<?= $appoinment['id'] ?>>Report</a> 
                </td>-->
              </tr>
            <?php } ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>


                    </div>
                </form>

                <!--end::Form-->
            </div>

            <!--end::Portlet-->
        </div>
    </div>


<?php

include('footer.php');