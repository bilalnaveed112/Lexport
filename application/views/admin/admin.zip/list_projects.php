<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Project');?>
                            </h3>
                        </div>
                    </div>
                </div>
 
                <div class="m-portlet__body">
 
                    <div class="row align-items-center" style="margin-bottom: 20px">


                        <div class="col-xl-8 order-2 order-xl-1">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">

                                <div class="col-md-4">
 
          
			<strong class=" "><a class="btn btn-success btn-lg" href="<?=base_url('admin/project/add_project');?>"><i class="fa fa-plus"></i> <?php echo $this->lang->line('Add_Project');?></a></strong>
 
                 
                                </div>

                            </div>

                        </div>
 

                    </div>



                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">

                                <th><?php echo $this->lang->line('No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Project_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Project_Type');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Project_Team_Manager');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Status');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('ACTION');?></th>

                            </tr>
                            </thead>
                            <tbody>
 <?php 
              $count=1;
              foreach($data as $consultation){  
              if(in_array($this->session->userdata('admin_id'),getGroupByID($consultation['add_group'])) OR $this->session->userdata('role_id')==1){
              ?>
              <tr class="hide<?php echo $consultation['id'] ?>">
                <td><?php echo $count++; ?></td>
                <td><?= $consultation['project_name'] ?></td>
                <td><?= getProjectTypeName($consultation['project_type']); ?></td>
                <td><?=  getEmployeeName($consultation['project_team_manager']); ?></td>
                <td><?= $consultation['project_status'] ?></td>
		            <td class="action">
                
                    <a href=<?= base_url("admin/project/find_project/{$consultation['id']}") ?> class="fa fa-pencil-square-o editadmin" id=<?= $consultation['id'] ?> title="<?php echo $this->lang->line('Edit');?>"></a>
        
                  <a href="javascript:;" class="fa fa-trash delete_consultation" id=<?= $consultation['id'] ?> title="<?php echo $this->lang->line('Delete');?>"></a>
                   <a href=<?= base_url("admin/project/view_project/{$consultation['id']}") ?>  title="<?php echo $this->lang->line('View');?>" class="fa fa-eye" target="_blnak"></a>
                  <!-- <a href="javascript:;" class="btn btn-outline-success fa fa-file " id=<?= $appoinment['id'] ?>>Report</a> -->
                </td>
              </tr>
            <?php } } ?>
      

                            </tbody>
                        </table>

 
                    </div>


                </div>
            </div>


        </div>




    </div>

<?php

include('footer.php');

?>

<script type="text/javascript">
  <?php if(isset($datas[10][3]) && $datas[10][3] == 1){?>
      $('.dataTables_filter').show();
    <?php }else{?>
      $('.dataTables_filter').hide();
    <?php } ?>

  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });

  $('.delete_consultation').click(function(){
    
    var id=$(this).attr("id");

    var url="<?= base_url('admin/project/delete_project'); ?>"; 
    bootbox.confirm("Are you sure?", function(result){
      if(result)
      {
        $.ajax({
          type:'ajax',
          method:'post',
          url:url,
          data:{"id" : id},
          success:function(data){
            $('#msg').show();
            $('#msg').html(data);
          },
        });
        $('.hide'+id).hide(200);
        return true;
      }
      else
      {
        $('#msg').show();
        $('#msg').html('delete failed');
      }
    })
  });
</script>
