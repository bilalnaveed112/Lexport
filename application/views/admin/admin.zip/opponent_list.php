<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Opponent_List');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">


                    <div class="row align-items-center dataTables_wrapper dt-bootstrap4 no-footer" style="margin-bottom: 20px">

<style>
.nedbtn .btn {
    margin-right: 10px !important;
}
</style>
                        <div class="col-xl-12 order-2 order-xl-1 nedbtn">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">
								<a class="btn btn-info"href="<?=base_url('admin/admin/all_users');?>"><?php echo $this->lang->line('Registered_List');?> <span class="badge badge-danger noticount admin"><?php echo userNotification(); ?></span></a>
				<a class="btn btn-success"href="<?=base_url('admin/c_case/padding_case');?>"><?php echo $this->lang->line('Pending_E_Service');?> <span class="badge badge-danger noticount admin"><?php echo casePendingNotification(); ?></span></a>
				 <a href="<?=base_url('admin/c_case/reject_case_list');?>" class="btn btn-danger"><?php echo $this->lang->line('Reject_E_Service_List');?></a>
				 <a href="<?=base_url('admin/c_case/opponent_list');?>" class="btn btn-info"><?php echo $this->lang->line('Opponent_List');?></a>

                            </div>

                        </div>

               

                    </div>




                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">
						<th><?php echo $this->lang->line('SR_NO');?></th>
                        <th><?php echo $this->lang->line('Name');?></th>
                        <th><?php echo $this->lang->line('Note');?></th>
						<th><?php echo $this->lang->line('Phone');?>	</th>
                        <th><?php echo $this->lang->line('Lawyer');?></th>
						<th><?php echo $this->lang->line('identification_types');?></th>
                        <th><?php echo $this->lang->line('Opponent_Number');?></th>
 
                            </tr>
                            </thead>
                            <tbody>
   <?php $count=1;
                       foreach($data as $Padding_cus) { ?>
                        <tr class="">
                        <td><?= $count++ ?></td>
                        <td><?= $Padding_cus['opponent_full_name'] ?></td>
                        <td><?= $Padding_cus['opponent_note'] ?></td>
                        <td><?= $Padding_cus['opponent_phone'] ?></td>
                        <td><?= $Padding_cus['opponent_lawyer'] ?></td>
                        <td><?= $Padding_cus['opponent_identification_types'] ?></td>
                        <td><?= $Padding_cus['opponent_number'] ?></td>
                        
                      </tr>
				<?php } ?>
                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>


        </div>




    </div>

<?php

include('footer.php');

?> 
    <script type="text/javascript">

        $(document).ready(function() {
           $('#msg').hide();
          $('#customers-table').DataTable();
        } );
    </script>

  <script type="text/javascript">

$('.approve_customer').click(function(){
  var id=$(this).attr("id");
  var url="<?=base_url('admin/customer/approve_customer');?>";
   
      $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},

    success:function(data){
       $('#msg').show();
         $('#msg').html(data);
         $('.hide'+id).hide(200);
      },
      error:function(){
         $('#msg').show();
       $('#msg').html('approve failed');
      },
  });
});
  
</script>