<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Note_List');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">


                    <div class="row align-items-center" style="margin-bottom: 20px">


                        <div class="col-xl-8 order-2 order-xl-1">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">

                                <div class="col-md-4">

                                    <a href="<?=base_url('admin/admin/add_note');?>" class="btn btn-primary m-btn btn-cst  m-btn--custom m-btn--icon m-btn--air" style="border-radius: 20px;">
                                        <span>
                                            <i class="fa fa-plus"></i>
                                        <span><?php echo $this->lang->line('Add');?></span>
                                        </span>
                                    </a>

                                </div>

                            </div>

                        </div>

                        

                    </div>




                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">
                                <th><?php echo $this->lang->line('No');?></th>
                                <th><?php echo $this->lang->line('Customer_Name');?></th>
                                <th><?php echo $this->lang->line('E_service');?></th>
                                <th><?php echo $this->lang->line('Mission_Type');?></th>
                                <th><?php echo $this->lang->line('Date');?></th>
                                <th><?php echo $this->lang->line('Note');?></th>
                                <th><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </thead>
                            <tbody>
  <?php $count=1;?>
                      <?php foreach($data as $data){ ?>
                      <tr class="hide<?php echo $data['id'] ?>"  style="text-align: center;"> 
                        <td><?= $count++ ?></td>
                        <td><?= getEmployeeName($data['user_id']); ?></td>
                        <td><?= getCaseNumberById($data['case_id']); ?></td>
                        <td><?= $data['mission_type'] ?></td>
                        <td><?= getTheDayAndDateFromDatePan($data['date']); ?></td>
                        <td><?= $data['discription'] ?></td>
            <td class="action">
 
              <span style="overflow: visible; position: relative;">
				<a href="<?= base_url("admin/admin/find_note/{$data['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill editadmin" title="<?php echo $this->lang->line('Edit');?>">
					<i class="fa fa-edit"></i>
				</a>
			</span>
			   <span style="overflow: visible; position: relative;">
				<a href="javascript:;" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill delete_note" title="<?php echo $this->lang->line('Delete');?>" id=<?= $data['id'] ?>>
					<i class="fa fa-close"></i>
				</a>
			</span>
 
               </td>
                      </tr>
                    <?php } ?>
                         
  
                            </tbody>
                        </table>
 
                    </div>


                </div>
            </div>


        </div>

    </div>

<?php

include('footer.php');

?>
<script src="<?= base_url('assets/js/ajax.js'); ?>"></script>
<script type="text/javascript">

$(document).ready(function()
{
  $('#msg').hide();
   $('#customers-table').DataTable();
});
</script>

 <script type="text/javascript">

    $('.delete_note').click(function(){
  var id=$(this).attr("id");
  var url="<?= base_url('admin/admin/delete_note'); ?>"; 
   bootbox.confirm("Are you sure?", function(result){
    if(result)
    {
      $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
  
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);

      },
  });
$('.hide'+id).hide(200);
return true;
  }
  else
  {
      $('#msg').show();
       $('#msg').html('delete failed');
  }
    })
    });
</script>