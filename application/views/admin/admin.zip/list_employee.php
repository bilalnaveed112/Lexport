<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('HR_E_services');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">

                    <div class="row" style="margin-bottom: 20px">

                        <div class="col-xl-12 order-2 order-xl-1">

<div id="msg" class="sufee-alert alert with-close alert-success alert-dismissible fade show success"></div>
                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">

                                <div class="col-md-4">

                                    <a href="<?=base_url('admin/employee/add_employee');?>" class="btn btn-primary m-btn btn-cst  m-btn--custom m-btn--icon m-btn--air" style="border-radius: 20px;">
                                        <span>
                                            <i class="fa fa-plus"></i>
                                        <span><?php echo $this->lang->line('Add_Employee');?></span>
                                        </span>
                                    </a>

                                </div>

                            </div>

                        </div>

                    </div>

                  


                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                        <thead>
                      <tr class="netTr"> 
                        <th><?php echo $this->lang->line('No');?></th>
                        <th><?php echo $this->lang->line('Name');?></th>
                        <th><?php echo $this->lang->line('Department');?></th>
                        <th><?php echo $this->lang->line('branch');?></th>
                        <th><?php echo $this->lang->line('Employee_Type');?></th>
                        <th><?php echo $this->lang->line('ACTION');?></th>
                      </tr>
                    </thead>
                    <tbody>
                     
                  <?php 
                     $count=1;
                  foreach($data as $emp){ ?>
                     <tr class="hide<?php echo $emp['id'] ?>" style="text-align:center">
                        <td><?= $count++ ?></td>
                        <td><?= $emp['name'] ?></td>
                        <td><?php echo getDepartmentName($emp['department_id'] ); ?></td>
                        <td><? echo getBranchName($emp['branch']); ?></td>
                        <td><?= $emp['employee_type'] ?></td>
						<td class="action">  <a href=<?= base_url("admin/employee/find_employee/{$emp['id']}") ?> title="<?php echo $this->lang->line('Edit_Employee');?>" class="fa fa-pencil-square-o editadmin" id=<?= $emp['id'] ?>></a>
						<a href="javascript:;" title="<?php echo $this->lang->line('delete_employee');?>" class="fa fa-trash delete_employee" id=<?= $emp['id'] ?>></a>
						<a href=<?= base_url("admin/employee/view_employee/{$emp['id']}") ?>  title="<?php echo $this->lang->line('View_Employee');?>" class="fa fa-eye" target="_blnak"></a>
						</td>
                      </tr>
                  <?php } ?>

                            </tbody>
                        </table>
 
                    </div>


                </div>
            </div>


        </div>

    </div>

<?php include "footer.php";?>

<script type="text/javascript">

$(document).ready(function()
{
  $('#msg').hide();
   $('#customers-table').DataTable();
});
</script>

 <script type="text/javascript">

$("#m_datatable").on("click", ".delete_employee", function() {
   var id=$(this).attr("id");
  var url="<?= base_url('admin/employee/delete_employee'); ?>"; 
   bootbox.confirm("Are you sure?", function(result){
    if(result)
    {
      $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
  
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);

      },
  });
//$('.hide'+id).hide(200);
return true;
  }
  else
  {
      $('#msg').show();
       $('#msg').html('delete failed');
  }
    })
    });
</script>