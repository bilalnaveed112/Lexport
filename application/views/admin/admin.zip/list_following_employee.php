<?php
include('header.php');

?>
<style>
    .nav {
        display: -webkit-box;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">

        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('ASSIGNMENT');?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="m-portlet__body">

    <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link " data-toggle=" " href="<?=base_url('admin/assignment');?>"><?php echo $this->lang->line('File_assignment');?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="" href="<?=base_url('admin/assignment/list_assignment_case');?>"><?php echo $this->lang->line('E_Service_assignment');?></a>
                    </li>
                </ul>
                   
                <div class="tab-content">
                    <div class="tab-pane active" id="m_tabs_3_1" role="tabpanel">

                        <div class="m-portlet__body">
							<div class="tab-pane" id="m_tabs_1_3" role="tabpanel">
                                <div class="m-portlet__body">


                          <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link " data-toggle=" " href="<?=base_url('admin/assignment/list_assignment_case');?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('All');?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle=" " href="<?=base_url('admin/assignment/list_responsible_employee');?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Responsible_Employee');?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle=" " href="<?=base_url('admin/assignment/list_following_employee');?>" data-target="#m_tabs_1_3"><?php echo $this->lang->line('Following_Employee');?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle=" " href="<?=base_url('admin/assignment/padding_assigenment_list');?>" data-target="#m_tabs_1_4"><?php echo $this->lang->line('Pending_Assignment');?></a>
                            </li>
                        </ul>
						       <div class="tab-content">
								<div class="tab-pane active" id="m_tabs_1_2" role="tabpanel">
                                <div class="m-portlet__body">
                                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                        <div class="table-responsive">
                                            <table class="table table-hover table-striped" id="m_datatable">
                                                <thead>
                                                <tr class="netTr">
                                                    <th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                    <th><?php echo $this->lang->line('Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                    <th><?php echo $this->lang->line('client_File_number');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                    <th><?php echo $this->lang->line('E_Service_Number');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                    <th><?php echo $this->lang->line('Following_Employee');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                    <th><?php echo $this->lang->line('Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                  <!--  <th><?php echo $this->lang->line('Due_Time');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>-->
                                                    <th><?php echo $this->lang->line('ACTION');?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
						<?php $i=0; foreach ($list as $case){ $i++;  
						//if($case['user_id'] != 0) {
						?>
						  <tr class="hide<?php echo $case['id'] ?>" style="text-align: center;">
							<td><?= $i; ?></td>
							<td><?= $case['client_name'] ?></td>
							<td><?=  $case['client_file_number'] ?> </td>
							<td><?= $case['case_number'] ?></td>

							<td><?php echo getEmployeeName($case['follow_up_employee']); ?></td>
							<td><?= $case['case_date']?></td>
							<!--	<td><span class='countdown' style=" color: #0e8a00; font-weight: bold; " value='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>' data-countdown='<?php echo mission_due_time($case['ending_date'],$case['ending_time']);?>'></span></td>-->
							<td class="action">
						<?php  

						if($this->session->userdata('role_id') ==1){
						if(empty($case['case_id'])){ ?>

						 
					<span style="overflow: visible; position: relative;">
						<a href="javascript:;" id="<?= $case['id'] ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill delete_case" title="<?php echo $this->lang->line('Delete');?>">
							<i class="fa fa-trash"></i>
						</a>
					</span>

						<?php } } else {
						//if(isset($datas[2][2]) && $datas[1][2] == 1){
						?>	 <?php }?>
								
 
					 <span style="overflow: visible; position: relative;">
						<a href="<?= base_url("admin/c_case/edit_case/{$case['id']}"); ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit_On_File');?>">
							<i class="fa fa-edit"></i>
						</a>
					</span>
 
					<span style="overflow: visible; position: relative;">
						<a href="<?= base_url("admin/c_case/view_case/{$case['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('View');?>">
							<i class="fa fa-eye"></i>
						</a>
					</span>
						<span style="overflow: visible; position: relative;">
							<a href="javascript:;" data-toggle="modal" id="<?= $case['case_id'] ?>" data-target="#myModal" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill assign_type" title="<?php echo $this->lang->line('Book_Appointment');?>">
								<i class="fa fa-calendar"></i>
							</a>
						</span>
						</td>

						</tr> 
						<?php 
						    
					//	} 
						} ?>
                                             
 
                                                </tbody>
                                            </table>
                                        </div>

                                         
                                    </div>


                                </div>
                            </div>
        
                        </div>

                    </div>
                </div>

            </div>

        </div>


    </div>

</div>
</div>
</div>
</div>
</div>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <select class="form-control" id="type" name="type">
			<option value=""><?php echo $this->lang->line('Select_Mission');?></option> 
			<option value="1"><?php echo $this->lang->line('Session');?></option> 
			<option value="2"><?php echo $this->lang->line('Visiting');?></option> 
			<option value="3"><?php echo $this->lang->line('Writings');?></option> 
			<option value="4"><?php echo $this->lang->line('Consultation');?></option> 
			<option value="5"><?php echo $this->lang->line('GENERAL');?></option> 
        </select>
        <input type="hidden" value="" id="case_id" name="case_id">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('Close');?></button>
      </div>
    </div>

  </div>
</div>

<div id="note_dialog"></div>
<style>
.assignpopup .form-control {
    float: left;
    margin: 5px 0px;
}
</style>
<?php include "footer.php";?>
 <script type="text/javascript">
$(document).ready(function() {
	$('#msg').hide();

});

$('#type').on('change',function(){

  var type_val = $('#type').val();
  var case_id = $('#case_id').val();
  
  if(type_val == 1)
  {
    window.location.href = "<?php echo base_url('admin/appoinment/add_session_appoinment'); ?>/"+case_id;
  }else if(type_val == 2)
  {
    window.location.href = "<?php echo base_url('admin/mission_visiting/add_mission'); ?>/"+case_id;
  }
  else if(type_val == 3)
  {
    window.location.href = "<?php echo base_url('admin/mission_writings/add_mission'); ?>/"+case_id;
  } else if(type_val == 5)
  {
    window.location.href = "<?php echo base_url('admin/mission_general/add_mission'); ?>/"+case_id;
  }else
  {
    window.location.href = "<?php echo base_url('admin/mission_consultation/add_mission'); ?>/"+case_id;
  }
})
</script>
<script type="text/javascript">

$("#m_datatable").on("click", ".convert_case", function() {
var id=$(this).attr("id");
var case_id=$(this).data("user");

var msg= $('#note_dialog').html();
var url="<?= base_url('admin/assignment/convert_assignment'); ?>";  
bootbox.confirm('<div class="assignpopup"><select class="form-control" id="employee_id" name="employee_id"><option>Select Responsible employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><select class="form-control" id="eid" name="eid"><option>Select Following Employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><select class="form-control" id="reason" name="reason"><option>Reason to convert</option><option value="Passing the date">Passing the date</option><option value="Unsuffienet time">Unsuffienet time</option></select><textarea placeholder="Notes" name="note" id="notes" class="form-control col-md-12"></textarea></div>', function(result){
if(result){
	var  empid = $('#employee_id :selected').val();
	var  eid = $('#eid :selected').val();  
	var  reason = $('#reason :selected').val();
	var  notes = $('#notes').val();

    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id,"case_id" : case_id,'empid':empid,'eid':eid,'reason':reason,'notes':notes,},
    success:function(data){
       $('#msg').show();
	   //alert(data);
         $('#msg').html(data);
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Assign Failed');
}
})
});


$(".assign_type").on("click", function() {
    var id=$(this).attr("id");
    $('#case_id').val(id);
})

$('#type').on('change',function(){

  var type_val = $('#type').val();
  var case_id = $('#case_id').val();
  
  if(type_val == 1)
  {
    window.location.href = "<?php echo base_url('admin/mission_session/add_mission'); ?>/"+case_id;
  }else if(type_val == 2)
  {
    window.location.href = "<?php echo base_url('admin/mission_visiting/add_mission'); ?>/"+case_id;
  }
  else if(type_val == 3)
  {
    window.location.href = "<?php echo base_url('admin/mission_writings/add_mission'); ?>/"+case_id;
  } else if(type_val == 5)
  {
    window.location.href = "<?php echo base_url('admin/mission_general/add_mission'); ?>/"+case_id;
  }else
  {
    window.location.href = "<?php echo base_url('admin/mission_consultation/add_mission'); ?>/"+case_id;
  }
})



$("#m_datatable").on("click", ".assign_case", function() {
var id=$(this).attr("id");
var customers_id=$(this).data("user");

var msg= $('#note_dialog').html();
var url="<?= base_url('admin/assignment/update_assign_case'); ?>"; 
bootbox.confirm('<div class="assignpopup"><select class="form-control" id="following_employee_id" name="following_employee_id"><option>Select Following Employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><textarea placeholder="Notes" name="note" id="notes" class="form-control col-md-12"></textarea></div>', function(result){
if(result){

	var  following_employee_id = $('#following_employee_id :selected').val();
	var  notes = $('#notes').val();
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id":id,"customers_id":customers_id,'following_employee_id':following_employee_id,'notes':notes},
    success:function(data){
       $('#msg').show();
	   alert(data);
         $('#msg').html(data);
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Assign Failed');
}
})
});
 $(document).on("click", ".modal-body", function () {
$('#start_date, #end_date').datetimepicker({  format: 'yyyy-mm-dd',  minView: 2, pickTime: false, autoclose: true,startDate: new Date()});
  $("#start_time,#end_time").datetimepicker({
    pickDate: false,
    minuteStep: 15,
    pickerPosition: 'bottom-right',
    format: 'HH:ii p',
    autoclose: true,
    showMeridian: true,
    startView: 1,
    maxView: 1,
  });
});
</script> 

<style>
    .modal .modal-content .modal-header .close:before {
        content: "X";
        font-family: arial;
    }
    .modal .modal-content {
        background: #ffffff;
    }
</style>

 