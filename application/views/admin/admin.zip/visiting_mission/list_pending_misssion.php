<?php include __DIR__ . "/../header.php"; $control="mission_visiting";?>
<style>
    .nav {
        display: -webkit-box;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">

        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('Visiting');?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="m-portlet__body">

                <!-- SUb -->
					<?php 
					if($this->uri->segment(4)){ 
					    $subid = $this->uri->segment(4);
					} else {
					     $subid ='';
					}
					?>
					<!-- Sub --><ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_mission/$subid");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('All');?></a>
                    </li> 
					<li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_responsible") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_responsible/$subid");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('Responsible_Employee');?> <span class="num_tab"><?php echo ResponsibleNotification('visiting_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_follow_up") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_follow_up/$subid");?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Following_Employee');?> <span class="num_tab"><?php echo FollowNotification('visiting_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_pending_misssion") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_pending_misssion/$subid");?>" data-target="#m_tabs_1_3"><?php echo $this->lang->line('Pending');?> <span class="num_tab"><?php echo PendingNotification('visiting_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_close_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_close_mission/$subid");?>" data-target="#m_tabs_1_4"><?php echo $this->lang->line('Close_Mission');?> <span class="num_tab"><?php echo CloseNotification('visiting_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_review") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_review/$subid");?>" data-target="#m_tabs_1_5"><?php echo $this->lang->line('In_Review');?> <span class="num_tab"><?php echo ReviewNotification('visiting_mission'); ?></span></a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
                        <div class="m-portlet__body">
                            <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                <div class="table-responsive">
                                    <table class="table table-hover table-striped" id="m_datatable">
                                        <thead>
                                       <tr class="netTr">
				<th><?php echo $this->lang->line('SR_NO');?></th>
                <th><?php echo $this->lang->line('File_Number');?></th>
				<th><?php echo $this->lang->line('Client_Name');?></th>
				<th><?php echo $this->lang->line('Client_Type');?></th>
				<th><?php echo $this->lang->line('E_Service_Number');?></th>
				<!-- sub -->
                                            <?php if(empty($this->uri->segment(4))){ ?>
                                            <th><?php echo $this->lang->line('Sub_Mission');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        	<?php } ?>
				<th><?php echo $this->lang->line('E_Service_Type');?></th>
				<th><?php echo $this->lang->line('Date');?></th>
				<th><?php echo $this->lang->line('Time');?></th>
				<th><?php echo $this->lang->line('Visiting_Place');?></th>
				<th><?php echo $this->lang->line('Visitor_Employee');?></th>
               <!-- <th>Responsible Employee</th>-->
                <th><?php echo $this->lang->line('Requirement');?></th>
				<th><?php echo $this->lang->line('Due_Time');?></th>
                <th><?php echo $this->lang->line('ACTION');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
              <?php 
              $count=1;
              foreach($data as $appoinment){  ?>
			<tr class="hide<?php echo $appoinment['id'] ?>" style="text-align:center;">
                 <td>
                     <?php  
		if($this->session->userdata('role_id') == 1){
			if($appoinment['read_admin'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } else if(in_array($this->session->userdata('admin_id'),getFileManager())){
			if($appoinment['read_manager'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } 
        else { 
			if($appoinment['read_follow'] == 0){ echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; } else {
			if($appoinment['read_response'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; }
		}
 
		?>
                 </td>
                <td><?= $appoinment['client_file_number'] ?></td>
                <td><?= $appoinment['client_name'] ?></td>
				<td><?php   $row = $this->db->select('*')->where('client_file_number',$appoinment['client_file_number'])->get('customers')->row();   if($row){ echo $row->type_of_customer; }?></td>
	 
                <td><?= $appoinment['case_number'] ?></td>
				<!-- sub -->
			    <?php if(empty($this->uri->segment(4))){ ?>
			    <td><a href="https://albarakatilaw.com/admin/mission_visiting/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"visiting_mission"); ?></a> </td>
				<?php  } ?>
				<!-- sub -->
				<td><?= getServiceType($appoinment['service_types']); ?></td>
                <td><span class='hidetd'><?php echo getdateforshorting($appoinment['session_date']); ?></span><?php echo getTheDayAndDateFromDatePan($appoinment['session_date']); ?></td>
                <td><?= $appoinment['session_time'] ?></td>
                <td><?php echo getEmployeeName($appoinment['visitor_employee']); ?></td>
				<td><?= $appoinment['department'] ?></td>
                <!--<td><?php  if($appoinment['responsible_employee'] != ''){ echo getEmployeeName($appoinment['responsible_employee']); } ?></td>-->

                <td><?= $appoinment['note'] ?></td>
				<td><span class='countdown' style=" color: #0e8a00; font-weight: bold; " 
				  value='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>' data-countdown='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>'></span></td>

		          <td class="action">
				  <span style="overflow: visible; position: relative;">
					<?php if(isset($datas[5][1]) && $datas[5][1] == 1) { ?>
					<a href=<?= base_url("admin/$control/find_mission/{$appoinment['id']}") ?> class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill editadmin" id=<?= $appoinment['id'] ?> title="<?php echo $this->lang->line('Edit');?>"><i class="fa fa-edit"></i></a>
					<?php } ?>
				<?php if(isset($datas[5][3]) && $datas[5][3] == 1) { ?>
					<a href=<?= base_url("admin/$control/view_mission/{$appoinment['id']}") ?>  title="<?php echo $this->lang->line('View');?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" ><i class="fa fa-eye"></i></a>	
				<?php } ?>
					<?php  if($this->session->userdata('role_id') == 1 ||  in_array($this->session->userdata('admin_id'),getFileManager()) AND $appoinment['is_reject']==0){  ?>
					<a href=<?= base_url("admin/$control/approve_pending_mission/{$appoinment['id']}") ?>  title="<?php echo $this->lang->line('Approve');?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill  "><i class="fa fa-check"></i></a>
					<?php } ?>
					 <?php if($appoinment['is_reject']==1){  ?>
					 	<a href="#" title="<?php echo $this->lang->line('Rejected');?>" class="btn btn-danger"><?php echo $this->lang->line('Rejected');?></a> 
					 <?php } ?>
					  <?php if($appoinment['is_reject']==0 AND $this->session->userdata('role_id') == 1 AND in_array($this->session->userdata('admin_id'),getFileManager())){  ?>
					<a href=<?= base_url("admin/$control/reject_pending_mission/{$appoinment['id']}") ?>  title="<?php echo $this->lang->line('Close');?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill  "><i class="fa fa-close"></i></a> 
					<?php } ?>

 
</span>
                </td>
              </tr>
            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
 
                            </div>


                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>

        </div>


    </div>

</div>


<?php include __DIR__ . "/../footer.php"; ?>

<script type="text/javascript">

  <?php if(isset($datas[3][3]) && $datas[3][3] == 1){?>
    $('.dataTables_filter').show();
  <?php }else{?>
    $('.dataTables_filter').hide();
  <?php } ?>

  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });
</script>
