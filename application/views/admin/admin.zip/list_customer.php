<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

<div id="msg" class="sufee-alert alert with-close alert-success alert-dismissible fade show success" style="display:none;"></div>
            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('List_Customers');?>
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="m-portlet__body">


                    <div class="row align-items-center" style="margin-bottom: 20px">
	  
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <div class="table-responsive">
                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                           <tr class="netTr">
                                <th><?php echo $this->lang->line('No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('File_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Client_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Client_Type');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('E_Service_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('branch');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('TOTAL_E_SERVICES');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </thead>
                            <tbody>
						<?php $count=1;  
                       foreach($list_customer as $list_customer) {   
						//if(check_block($list_customer['customers_id']) == "false"){ ?>
                        <tr style="text-align: center;" class="hide<?php echo $list_customer['id'] ?>">
                        <td><?= $count++ ?></td>
                        <td><?= $list_customer['client_file_number'] ?></td>
                        <td><?= $list_customer['client_name'] ?></td>
                        <td><?= $list_customer['type_of_customer'] ?></td>
                        <td><?php echo getCustomerCaseServices($list_customer['customers_id']);  ?></td>
                         <td><?php echo getBranchName($list_customer['branch']) ?></td>
						 
						<?php 
					//	$case=$this->db->select('*')->where('customers_id',$list_customer['customers_id'])->get('c_case')->row_array();
						$this->db->where('customers_id', $list_customer['customers_id']);
						$num_rows = $this->db->count_all_results('c_case'); 
                        $this->db->where(['customers_id'=>$list_customer['customers_id'],'is_reject'=>1]);
						$num_rows1 = $this->db->count_all_results('case_temp'); 
						//echo $num_rows;
						?>
						<td><a href="<?=base_url("admin/c_case/customer_case_list/{$list_customer['customers_id']}");?>" class="num_tab" style="background-color: green;"><?php echo $num_rows-$num_rows1; ?> </a> 
						</td>
                       
						<td class="action"><!--$list_customer['id']-->
						<span style="overflow: visible; position: relative;">
						<a href="<?= base_url("admin/customer/view_customer/{$list_customer['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('View');?>">
						<i class="fa fa-eye"></i>
						</a>
						</span>
						<span style="overflow: visible; position: relative;">
										<a href="<?=base_url("admin/customer/manage/{$list_customer['id']}");?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit_On_File');?>">
											<i class="fa fa-edit"></i>
										</a>
						</span>
						<span style="overflow: visible; position: relative;">
						<a href="<?=base_url("admin/c_case/add_case/{$list_customer['customers_id']}");?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('ADD_E_SERVICES');?>">
						<i class="fa fa-plus"></i>
						</a>
						</span>
						<?php if($this->session->userdata('role_id') == 1){ ?>
						
						<span style="overflow: visible; position: relative;">
						<a href='javascript:;' id="<?=$list_customer['id']?>"  class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill delete_customer" title="<?php echo $this->lang->line('Delete_E_Services');?>">
						<i class="fa fa-trash"></i>
						</a>
						</span>
				 
						<?php } ?>
						<?php if($this->session->userdata('role_id') == 1 AND $list_customer['user_id'] == 0){?> 
						<a  href="javascript:;" id="<?= $list_customer['id'] ?>" class="btn btn-outline-success assign_case" title="<?php echo $this->lang->line('Assign_File');?>"><i class="fa fa-plus"></i><i class="fa fa-user"></i></a><?php } ?>  
						</td>
						
						</tr>
						<?php }?>
                            
                            </tbody>
                        </table>
                        </div>
                    </div>


                </div>
            </div>


        </div>

    </div>

<?php

include('footer.php');

?>

<script type="text/javascript">
$(function(){
//$('.assign_case').click(function(){
$("#m_datatable").on("click", ".assign_case", function() {
var id=$(this).attr("id");
var msg= $('#note_dialog').html();
var url="<?= base_url('admin/customer/assign_customer'); ?>"; 
bootbox.confirm('<select class="form-control" id="employee_id" name="user_id"><option>Select employee </option><?php  foreach ($employees as$employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><label class="nterr1" style="color:red"></label> <br> <textarea name="nnote" class="form-control" placeholder="Note*"  id="nnote"></textarea> <label class="nterr" style="color:red"></label>', function(result){
if(result){ 	 var nnote=$('#nnote').val();

var  empid = $('#employee_id :selected').val();
if(empid =='Select employee'){
	$('.nterr1').html('Employee is required');
	return false;
}
if(nnote==''){
	$('.nterr').html('Note is required');
	return false;
}
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id,'empid':empid, "nnote":nnote},
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Assign Failed');
}
})
});
});
</script>
 <script type="text/javascript">
$("#m_datatable").on("click", ".delete_customer", function() {
  var id=$(this).attr("id");
  var url="<?=base_url('admin/customer/delete_customer');?>";
   bootbox.confirm("Are you sure?", function(result){
    if(result)
    {

      $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);
      },
  });
$('.hide'+id).hide(200);
return true;
}
else
{
  $('#msg').show();
   $('#msg').html('delete failed');
}
})
});
</script>