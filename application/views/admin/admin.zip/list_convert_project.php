<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Convert_Project');?>
                            </h3>
                        </div>
                    </div>
                </div>

  
                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
         <div class="m-portlet__body">

                        <table class="table table-hover table-striped">
                            <thead>
                            <tr class="netTr">

                                <th><?php echo $this->lang->line('No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Project_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Case_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Client_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('Status');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                <th><?php echo $this->lang->line('ACTION');?></th>

                            </tr>
                            </thead>
                            <tbody>

                          <?php 
              $count=1;
              foreach($data as $convert_project){  ?>
              <tr class="hide<?php echo $convert_project['id'] ?>">
                <td><?= $count++ ?></td>
                <td><?= $convert_project['employee_name'] ?></td>
                <td><?= $convert_project['designated_employee_name'] ?></td>
                <td><?= $convert_project['project_number'] ?></td>
                <td><?= $convert_project['follow_up_employee'] ?></td>
		            <td class="action">
                  <a href=<?= base_url("admin/project/find_convert_project/{$convert_project['id']}") ?> class="editadmin" id=<?= $convert_project['id'] ?> title="<?php echo $this->lang->line('Edit');?>"><i class="fa fa-pencil-square-o "></i></i></a>
                  <a href="javascript:;" class="delete_consultation" id=<?= $convert_project['id'] ?> title="<?php echo $this->lang->line('Delete');?>"><i class="fa fa-trash"></i></a>
                  <!-- <a href="javascript:;" class="btn btn-outline-success fa fa-file " id=<?= $appoinment['id'] ?>>Report</a> -->
                </td>
              </tr>
            <?php } ?>

                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>



        </div>
        </div>




    </div>

<?php include "footer.php";?>

<script type="text/javascript">
  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });

  $('.delete_consultation').click(function(){
    
    var id=$(this).attr("id");

    var url="<?= base_url('admin/project/delete_convert_project'); ?>"; 
    bootbox.confirm("Are you sure?", function(result){
      if(result)
      {
        $.ajax({
          type:'ajax',
          method:'post',
          url:url,
          data:{"id" : id},
          success:function(data){
            $('#msg').show();
            $('#msg').html(data);
          },
        });
        $('.hide'+id).hide(200);
        return true;
      }
      else
      {
        $('#msg').show();
        $('#msg').html('delete failed');
      }
    })
  });
</script>
