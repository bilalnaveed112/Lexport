<?php
include('header.php');

?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">

        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            Customer case list
                        </h3>
                    </div>
                </div>
            </div>


            <div class="m-portlet__body">


                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                    <table class="table table-hover table-striped">
                        <thead>
                        <tr class="netTr">
                            <th>Sr. No. <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th>Name <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th>E-Service Name <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th>Contract No. <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th>E-Service No. <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th>Client File Number <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        <tr style="text-align: center;">
                            <td>234</td>
                            <td>Mohammed</td>
                            <td>Commercial Business</td>
                            <td>CFN000005</td>
                            <td>FN000005</td>
                            <td>CU000458</td>
                            <th>
                                                        <span style="overflow: visible; position: relative;">
                                                            <a href="javascript:;" class="btn btn-danger" title="Pending">
                                                                Pending
                                                            </a>
                                                        </span>
                                <span style="overflow: visible; position: relative;">
                                                            <a href="pending_case_view.php" class="btn btn-info" title="View">
                                                                View
                                                            </a>
                                                        </span>
                            </th>
                        </tr>

                        <tr style="text-align: center;">
                            <td>234</td>
                            <td>Mohammed</td>
                            <td>Commercial Business</td>
                            <td>CFN000005</td>
                            <td>FN000005</td>
                            <td>CU000458</td>
                            <th>
                                                        <span style="overflow: visible; position: relative;">
                                                            <a href="view_case.php" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="View">
                                                                <i class="fa fa-eye"></i>
                                                            </a>
                                                        </span>
                                <span style="overflow: visible; position: relative;">
                                                            <a href="edit_case.php" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Edit On File">
                                                                <i class="fa fa-edit"></i>
                                                            </a>
                                                        </span>
                                <span style="overflow: visible; position: relative;">
                                                            <a href="" data-toggle="modal" data-target="#myModalAss" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Assign E-Service">
                                                                <i class="fa fa-user-plus"></i>
                                                            </a>
                                                        </span>
                                <span style="overflow: visible; position: relative;">
                                                            <a href="create_invoice.php" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Create Invoice">
                                                                <i class="fa fa-file-text-o"></i>
                                                            </a>
                                                        </span>
                                <span style="overflow: visible; position: relative;">
                                                            <a href="add_expenses.php" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Add Expenses">
                                                                <i class="fa fa-file-o"></i>
                                                            </a>
                                                        </span>
                                <span style="overflow: visible; position: relative;">
                                                            <a href="" data-toggle="modal" data-target="#myModalMiss" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Add Mission">
                                                                <i class="fa fa-plus"></i>
                                                            </a>
                                                        </span>
                            </th>
                        </tr>

                        </tbody>
                    </table>

                    <div class="m-datatable__pager m-datatable--paging-loaded clearfix">
                        <ul class="m-datatable__pager-nav">
                            <li>
                                <a title="First" class="m-datatable__pager-link m-datatable__pager-link--first m-datatable__pager-link--disabled" data-page="1" disabled="disabled">
                                    <i class="fa fa-angle-double-left"></i>
                                </a>
                            </li>
                            <li>
                                <a title="Previous" class="m-datatable__pager-link m-datatable__pager-link--prev m-datatable__pager-link--disabled" data-page="1" disabled="disabled">
                                    <i class="fa fa-angle-left"></i>
                                </a>
                            </li>

                            <li><a class="m-datatable__pager-link m-datatable__pager-link-number m-datatable__pager-link--active" data-page="1" title="1">1</a></li>
                            <li><a class="m-datatable__pager-link m-datatable__pager-link-number" data-page="2" title="2">2</a></li>
                            <li><a class="m-datatable__pager-link m-datatable__pager-link-number" data-page="3" title="3">3</a></li>
                            <li><a class="m-datatable__pager-link m-datatable__pager-link-number" data-page="4" title="4">4</a></li>
                            <li><a class="m-datatable__pager-link m-datatable__pager-link-number" data-page="5" title="5">5</a></li>
                            <li><a class="m-datatable__pager-link m-datatable__pager-link-number" data-page="6" title="6">6</a></li>
                            <li><a title="More pages" class="m-datatable__pager-link m-datatable__pager-link--more-next" data-page=""><i class="fa fa-ellipsis-h"></i></a></li>
                            <li><a title="Next" class="m-datatable__pager-link m-datatable__pager-link--next" data-page=""><i class="fa fa-angle-right"></i></a></li>
                            <li><a title="Last" class="m-datatable__pager-link m-datatable__pager-link--last" data-page=""><i class="fa fa-angle-double-right"></i></a></li>
                        </ul>


                    </div>
                </div>


            </div>
        </div>


    </div>

</div>

<?php

include('footer.php');

?>

<style>
    .modal .modal-content .modal-header .close:before {
        content: "X";
        font-family: arial;
    }
    .modal .modal-content {
        background: #ffffff;
    }
    .col-md-12, .col-md-6{
        margin-bottom: 10px;
    }
</style>

<!-- Modal cal -->
<div id="myModalMiss" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <select class="form-control" id="type" name="type">
                    <option value="">Select Mission</option>
                    <option value="1">Session</option>
                    <option value="2">Visiting</option>
                    <option value="3">Writings</option>
                    <option value="4">Consultation</option>
                    <option value="5">General</option>
                </select>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<!-- Modal Ass -->
<div id="myModalAss" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body">

                <div class="row">

                    <div class="col-md-6">
                        <select class="form-control m-bootstrap-select m-bootstrap-select--air m-bootstrap-select--pill m_selectpicker" id="" name="responsible_employee" value="">
                            <option>Select employee</option>
                            <option value="313">emp</option>
                            <option value="402">1ET</option>
                            <option value="404">3ET</option>
                            <option value="405">4ET</option>
                            <option value="409">4ET</option>
                            <option value="410">5ET</option>
                            <option value="424">raya alharbi</option>
                            <option value="425">Bashayer Alshreef</option>
                            <option value="426">nassr albarakti</option>
                            <option value="427">Naeem M Albarakati</option>
                            <option value="428">mohammad daud</option>
                            <option value="429">Jasmin Kanani</option>
                            <option value="445">sulaf zainy</option>
                            <option value="446">21312</option>
                            <option value="451">بنسل</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <select class="form-control m-bootstrap-select m-bootstrap-select--air m-bootstrap-select--pill m_selectpicker" id="" name="responsible_employee" value="">
                            <option value="0">Select Following Employee</option>
                            <option value="313">emp</option>
                            <option value="402">1ET</option>
                            <option value="404">3ET</option>
                            <option value="405">4ET</option>
                            <option value="409">4ET</option>
                            <option value="410">5ET</option>
                            <option value="424">raya alharbi</option>
                            <option value="425">Bashayer Alshreef</option>
                            <option value="426">nassr albarakti</option>
                            <option value="427">Naeem M Albarakati</option>
                            <option value="428">mohammad daud</option>
                            <option value="429">Jasmin Kanani</option>
                            <option value="445">sulaf zainy</option>
                            <option value="446">21312</option>
                            <option value="451">بنسل</option>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <div class="input-group date">
                            <input type="text" class="form-control m-input" readonly placeholder="Start date" id="m_datepicker_2" />
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-calendar-check-o"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group date">
                            <input type="text" class="form-control m-input" readonly placeholder="End date" id="m_datepicker_2" />
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-calendar-check-o"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group date">
                            <input type="text" class="form-control m-input" readonly placeholder="Start time" id="m_datetimepicker_7" />
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-clock-o"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group date">
                            <input type="text" class="form-control m-input" readonly placeholder="End time" id="m_datetimepicker_77" />
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-clock-o"></i></span>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-12" style="margin-top: 10px">
                        <textarea placeholder="Notes" name="note" id="notes" class="form-control col-md-12"></textarea>
                    </div>

                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button data-bb-handler="confirm" type="button" class="btn btn-primary">OK</button>
            </div>
        </div>

    </div>
</div>