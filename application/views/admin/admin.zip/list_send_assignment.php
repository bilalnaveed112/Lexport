<?php
include('header.php');

?>
<style>
    .nav {
        display: -webkit-box;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">

<div id="msg" class="sufee-alert alert with-close alert-success alert-dismissible fade show success" style="display:none;"></div>
        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('ASSIGNMENT');?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="m-portlet__body">

                <ul class="nav nav-pills" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link " data-toggle=" " href="<?=base_url('admin/assignment');?>"><?php echo $this->lang->line('File_assignment');?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="" href="<?=base_url('admin/assignment/list_assignment_case');?>"><?php echo $this->lang->line('E_Service_assignment');?></a>
                    </li>
					 <li class="nav-item">
                        <a class="nav-link active" data-toggle="" href="<?=base_url('admin/assignment/list_send_assignment');?>"><?php //echo $this->lang->line('E_Service_assignment');?> Send Assignment</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="m_tabs_3_1" role="tabpanel">

                        <div class="m-portlet__body">
 
                            <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                <table class="table table-hover table-striped" id="m_datatable">
                                    <thead>
                                    <tr class="netTr">
                                        <th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        <th><?php echo $this->lang->line('Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        <th><?php echo $this->lang->line('Customer_File_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        <th><?php echo $this->lang->line('Assign_Employee_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        <th><?php echo $this->lang->line('Assign_Note');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
					<?php $count=1;
                       foreach($list as $list_customer) {   
					?>
                        <tr class="hide<?php echo $list_customer['id'] ?>" style="text-align: center;">
                        <td><?= $count++ ?></td>
                      
                        <td><?= $list_customer['client_name'] ?></td>
						<td><?= $list_customer['client_file_number'] ?></td>
                        <td><?php echo getEmployeeName($list_customer['user_id']); ?></td>
						<td><?= $list_customer['assign_note'] ?></td>           
						<?php /*<td class="action"><!--$list_customer['id']-->
	 
						<span style="overflow: visible; position: relative;">
										<a href="<?=base_url("admin/c_case/add_case/{$list_customer['customers_id']}");?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('ADD_E_SERVICES');?>">
											<i class="fa fa-plus"></i>
										</a>
						</span>
		 
						  <span style="overflow: visible; position: relative;">
							<a href="<?=base_url("admin/customer/manage/{$list_customer['id']}");?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit_On_File');?>">
								<i class="fa fa-edit"></i>
							</a>
						</span>
                       
							<span style="overflow: visible; position: relative;">
							<a href="<?= base_url("admin/customer/view_customer/{$list_customer['id']}") ?> " class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('View');?>">
								<i class="fa fa-eye"></i>
							</a>
							
							</span>
                   
						<?php if($this->session->userdata('role_id') == 1){ ?>
				 
                       
							<span style="overflow: visible; position: relative;">
							<a href="javascript:;" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill delete_customer" title="<?php echo $this->lang->line("Delete_Customer");?>" id="<?=$list_customer['id']?>">
								<i class="fa fa-trash"></i>
							</a>
							
							</span>
						<?php } ?>
						<?php if($this->session->userdata('role_id') == 1){ ?>
							
							<span style="overflow: visible; position: relative;">
							<a  href="javascript:;" data-user="<?= $list_customer['id'] ?>" data-convert_from_id="<?= $list_customer['user_id'] ?>" data-convert_from="<?php if($list_customer['user_id'] != 0) echo getEmployeeName($list_customer['user_id']); ?>" id="<?= $list_customer['id'] ?>"  class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill convert_case" title="<?php echo $this->lang->line('Convert_Customer');?>"  >
								<i class="fa fa-refresh"></i>
							</a>
						<?php  } ?> 

                 
                                          
								</td> */ ?>

								</tr>

								<?php  }?>



                                    </tbody>
                                </table>
 
                            </div>


                        </div>

                    </div>
                  
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>



<?php

include('footer.php');

?>
 
 