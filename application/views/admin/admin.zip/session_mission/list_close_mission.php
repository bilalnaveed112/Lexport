<?php include __DIR__ . "/../header.php"; $control="mission_session";?>
<style>
    .nav {
        display: -webkit-box;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">

        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('Session');?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="m-portlet__body">

                <!-- SUb -->
					<?php 
					if($this->uri->segment(4)){ 
					    $subid = $this->uri->segment(4);
					} else {
					     $subid ='';
					}
					?>
					<!-- Sub --><ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_mission/$subid");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('All');?></a>
                    </li> 
					<li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_responsible") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_responsible/$subid");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('Responsible_Employee');?> <span class="num_tab"><?php echo ResponsibleNotification('session_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_follow_up") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_follow_up/$subid");?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Following_Employee');?> <span class="num_tab"><?php echo FollowNotification('session_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_pending_misssion") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_pending_misssion/$subid");?>" data-target="#m_tabs_1_3"><?php echo $this->lang->line('Pending');?> <span class="num_tab"><?php echo PendingNotification('session_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_close_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_close_mission/$subid");?>" data-target="#m_tabs_1_4"><?php echo $this->lang->line('Close_Mission');?> <span class="num_tab"><?php echo CloseNotification('session_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_review") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_review/$subid");?>" data-target="#m_tabs_1_5"><?php echo $this->lang->line('In_Review');?> <span class="num_tab"><?php echo ReviewNotification('session_mission'); ?></span></a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
                        <div class="m-portlet__body">
                            <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                <div class="table-responsive">
                                    <table class="table table-hover table-striped" id="m_datatable">
                                        <thead>
                                       <tr class="netTr">
                                            <th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('File_Number');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Client_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Client_Type');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('E_Service_Number');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
											 <!-- sub -->
                                            <?php if(empty($this->uri->segment(4))){ ?>
                                            <th><?php echo $this->lang->line('Sub_Mission');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        	<?php } ?>
                                            <th><?php echo $this->lang->line('E_Service_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Entry_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Court_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Judicial_Circuit');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Start_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Start_Time');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Requirement');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                            <th><?php echo $this->lang->line('Responsible_Employee');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                     <th><?php echo $this->lang->line('Close_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                         
                                            <th><?php echo $this->lang->line('ACTION');?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
    <?php 
              $count=1;
              foreach($data as $appoinment){  ?>
				<tr class="hide<?php echo $appoinment['id'] ?>" style="text-align: center;">
		<td><?php  
		if($this->session->userdata('role_id') == 1){
			if($appoinment['read_admin'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } else if(in_array($this->session->userdata('admin_id'),getFileManager())){
			if($appoinment['read_manager'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } 
        else { 
			if($appoinment['read_follow'] == 0){ echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; } else {
			if($appoinment['read_response'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; }
		}
        /*else if($this->session->userdata('admin_id')== $data->follow_up_employee){
			if($appoinment['read_follow'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } else if($this->session->userdata('admin_id') == $data->responsible_employee){
			if($appoinment['read_response'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } */
		?></td>
                <td><?= $appoinment['client_file_number'] ?></td>
                <td><?= $appoinment['client_name'] ?></td>
				<td><?php $row = $this->db->select('*')->where('client_file_number',$appoinment['client_file_number'])->get('customers')->row();   if($row){ echo $row->type_of_customer; }?></td>
				<td><?= $appoinment['case_number'] ?></td>
				<!-- sub -->
			    <?php if(empty($this->uri->segment(4))){ ?>
			    <td><a href="https://albarakatilaw.com/admin/mission_session/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"session_mission"); ?></a> </td>
				<?php  } ?>
				<!-- sub -->
				<td><?= getServiceType($appoinment['service_types']); ?></td>
				<td><?= $appoinment['entry_no'] ?></td>
				<td><?= gtCourtName($appoinment['court_name']);  ?></td>
                <td><?= $appoinment['department'] ?></td>
				<td><span class='hidetd'><?php echo getdateforshorting($appoinment['session_date']); ?></span><?php  echo getTheDayAndDateFromDatePan($appoinment['session_date']);  ?></td>
                <td><?= $appoinment['session_time'] ?></td>
				<td><?= $appoinment['note'] ?></td>			
				<td><?php  if($appoinment['responsible_employee'] != ''){ echo getEmployeeName($appoinment['responsible_employee']); } ?></td>
			 <td><?php echo clsoe_diff($appoinment['session_end_date'],$appoinment['session_end_time'],$appoinment['close_date']); ?></td>
		            <td class="action"> <span style="overflow: visible; position: relative;">
					<?php if(isset($datas[2][3]) && $datas[2][3] == 1) { ?>
					<a href="<?= base_url("admin/$control/view_mission/{$appoinment['id']}") ?>" id="readnotificaion" data-read="<?php echo $appoinment['id']; ?>" title="<?php echo $this->lang->line('View');?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" ><i class="fa fa-eye"></i></a>
					<?php } ?>
				<?php if($appoinment['report_file']) {?>
					<a href=<?= base_url("/uploads/case_file/{$appoinment['report_file']}") ?>  title="<?php echo $this->lang->line('Download_Report');?>" class="btn-info  btn btn-success" target="_blnak" download><i class="fa fa-download"></i> <?php echo $this->lang->line('Report');?> </a>
					<?php } ?>
					<?php
					$files = $this->db->select('*')->where("(temp_app_id = '{$appoinment["id"]}' AND cat_id = 8 AND type='session')", NULL, FALSE)->get('document')->row(); 
					if($files){
					?>
					<a href=<?= base_url("admin/$control/view_mission/{$appoinment['id']}/#attechmntrec") ?><?php //base_url("/uploads/case_file/{$files->name}") ?>  title="<?php echo $this->lang->line('Download_Mission');?>" class="btn btn-info  " target="_blnak"> <i class="fa fa-file"></i> <?php echo $this->lang->line('Attachment');?></a>
					<?php } ?> </span>
					<?php $p_data=$this->db->select('*')->where('mission_id',$appoinment['id'])->where('mission_type','session_mission')->get('mission_rating')->row(); $id =$appoinment["id"];
					if(!isset($p_data)){ ?> 
						<a href='<?= base_url("admin/admin/review_mission/$id/session_mission") ?>'  title="<?php echo $this->lang->line('Add_Review');?>" class="btn btn-info" target=""><i class="fa fa-star"></i> <?php echo $this->lang->line('Add_Review');?></a>
						<?php
					}
					else if($p_data->follow_rating == 0 || $p_data->responsible_rating == 0  || $p_data->master_rating== 0 ){
					?>
						<a href='<?= base_url("admin/admin/review_mission/$id/session_mission") ?>'  title="<?php echo $this->lang->line('Add_Review');?>" class="btn btn-info" target=""><i class="fa fa-star"></i> <?php echo $this->lang->line('Add_Review');?></a>
						<?php
					}
					?>
                </td>
              </tr>
            <?php } ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
 
                            </div>


                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>

        </div>


    </div>

</div>


<?php include __DIR__ . "/../footer.php"; ?>

<script type="text/javascript">

  <?php if(isset($datas[3][3]) && $datas[3][3] == 1){?>
    $('.dataTables_filter').show();
  <?php }else{?>
    $('.dataTables_filter').hide();
  <?php } ?>

  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });

  $('.delete_appoinment').click(function(){
    
    var id=$(this).attr("id");

    var url="<?= base_url('admin/$control/delete_mission'); ?>"; 
    bootbox.confirm("Are you sure?", function(result){
      if(result)
      {
        $.ajax({
          type:'ajax',
          method:'post',
          url:url,
          data:{"id" : id},
          success:function(data){
            $('#msg').show();
            $('#msg').html(data);
          },
        });
        $('.hide'+id).hide(200);
        return true;
      }
      else
      {
        $('#msg').show();
        $('#msg').html('delete failed');
      }
    })
  });
</script>

<style>
    .modal .modal-content .modal-header .close:before {
        content: "X";
        font-family: arial;
    }
    .modal .modal-content {
        background: #ffffff;
    }
</style>
 <script> /*
$('[id="readnotificaion"]').on('click', function(){
	var id=$(this).data("read");  
	var segment=<?php echo $this->uri->segment(3); ?>;
	var tb = <?php echo $control ?>;
	var url="<?=base_url('admin/admin/mission_notification_ct');?>";
    $.ajax({
		type:'ajax',
		method:'post',
		url:url,
		data:{"id" : id,"segment":segment,"tb":tb},
		success:function(data){
	 
		}
	});
});*/
</script>
