<?php include __DIR__ . "/../header.php"; $control="mission_general";?>
<style>
    .nav {
        display: -webkit-box;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">

        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('GENERAL');?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="m-portlet__body">

                <!-- SUb -->
					<?php 
					if($this->uri->segment(4)){ 
					    $subid = $this->uri->segment(4);
					} else {
					     $subid ='';
					}
					?>
					<!-- Sub --><ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_mission/$subid");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('All');?></a>
                    </li> 
					<li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_responsible") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_responsible/$subid");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('Responsible_Employee');?> <span class="num_tab"><?php echo ResponsibleNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_follow_up") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_follow_up/$subid");?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Following_Employee');?> <span class="num_tab"><?php echo FollowNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_pending_misssion") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_pending_misssion/$subid");?>" data-target="#m_tabs_1_3"><?php echo $this->lang->line('Pending');?> <span class="num_tab"><?php echo PendingNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_close_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_close_mission/$subid");?>" data-target="#m_tabs_1_4"><?php echo $this->lang->line('Close_Mission');?> <span class="num_tab"><?php echo CloseNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_review") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_review/$subid");?>" data-target="#m_tabs_1_5"><?php echo $this->lang->line('In_Review');?> <span class="num_tab"><?php echo ReviewNotification('general_mission'); ?></span></a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
                        <div class="m-portlet__body">
                            <div id="msg" class="sufee-alert alert with-close alert-success alert-dismissible fade show success" style="display:none;"></div>
                            <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                <div class="table-responsive">
                                    <table class="table table-hover table-striped" id="m_datatable">
                                        <thead>
                                       <tr class="netTr">
                                          
					<th><?php echo $this->lang->line('SR_NO');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('File_Number');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Client_Type');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Client_Name');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('E_Service_Number');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					  <!-- sub -->
                                            <?php if(empty($this->uri->segment(4))){ ?>
                                            <th><?php echo $this->lang->line('Sub_Mission');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        	<?php } ?>
					<th><?php echo $this->lang->line('General_Type');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Responsible_Employee');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('End_Date');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('End_Time');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Requirement');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
				 	<th><?php echo $this->lang->line('Due_Time');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('ACTION');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        </tr>
                                        </thead>
                                        <tbody>
           <?php 
              $count=1;
              foreach($data as $appoinment){  ?>
					<tr class="hide<?php echo $appoinment['id'] ?>" style="text-align:center;">
                 <td>
                 <?php  
		if($this->session->userdata('role_id') == 1){
			if($appoinment['read_admin'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } else if(in_array($this->session->userdata('admin_id'),getFileManager())){
			if($appoinment['read_manager'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; 
        } 
        else { 
			if($appoinment['read_follow'] == 0){ echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; } else {
			if($appoinment['read_response'] == 0) echo "<i class='fa fa-dot-circle-o singnoti'></i>"; echo $count++; }
		}
 
		?>
                 </td>
                <td><?= $appoinment['client_file_number'] ?></td>
				<td><?php   $row = $this->db->select('*')->where('client_file_number',$appoinment['client_file_number'])->get('customers')->row();   if($row){ echo $row->type_of_customer; }?></td>
                <td><?= $appoinment['client_name']; ?></td>
                <td><?= $appoinment['case_number']; ?></td>
								<!-- sub -->
			    <?php if(empty($this->uri->segment(4))){ ?>
			    <td><a href="https://albarakatilaw.com/admin/mission_general/list_mission/<?php echo $appoinment['id'] ?>" class="num_tab" style="background-color: green;"><?php echo	getMissionCount( $appoinment['id'],"general_mission"); ?></a> </td>
				<?php  } ?>
				<!-- sub -->
				<td><?= getGeneralType($appoinment['general_type']); ?></td>
				 
            	<td><?php echo getEmployeeName($appoinment['responsible_employee']); ?></td>
			 
                <td><span class='hidetd'><?php echo getdateforshorting($appoinment['session_end_date']); ?></span><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']); ?></td>
                <td><?= $appoinment['session_end_time'] ?></td>
				<td><?= $appoinment['note'] ?></td>
					<td><span class='countdown' style=" color: #0e8a00; font-weight: bold; " 
				  value='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>' data-countdown='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>'></span></td>

		          		            <td class="action">
					<span style="overflow: visible; position: relative;"> 
					<?php if (isset($datas[6][1]) && $datas[6][1] == 1) { ?>
					<a href="<?= base_url("admin/$control/find_mission/{$appoinment['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit');?>">
					<i class="fa fa-edit"></i>
					</a>
                <?php  } ?>
				    <?php if($this->session->userdata('role_id') == 1  ){ ?>
                    
					<a href="javascript:;" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill delete_appoinment"  id="<?= $appoinment['id'] ?>" title="<?php echo $this->lang->line('Delete');?>">
					<i class="fa fa-trash"></i>
					</a>
					 <?php  } ?>
					  
				<?php if(isset($datas[6][3]) && $datas[6][3] == 1) { ?>
					<a href="<?= base_url("admin/$control/view_mission/{$appoinment['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('View');?>">
					<i class="fa fa-eye"></i>
					</a>
				<?php } ?>
					</span>
					<?php if(isset($datas[6][4]) && $datas[6][4] == 1) { ?>
					<span style="overflow: visible; position: relative;">
					<a href="javascript:;" data-user="<?= $appoinment['case_id'] ?>" id="<?= $appoinment['id'] ?>"  class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill convert_case" title="<?php echo $this->lang->line('Convert_Case');?>">
					<i class="fa fa-refresh"></i>
					</a>
					</span>
					 <?php  } ?>
                </td>
              </tr>
            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
 
                            </div>


                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>

        </div>


    </div>

</div>


<?php include __DIR__ . "/../footer.php"; ?>
<script type="text/javascript">
$("#m_datatable").on("click", ".convert_case", function() {
var id=$(this).attr("id");
var case_id=$(this).data("user");

var msg= $('#note_dialog').html();
var url="<?= base_url("admin/appoinment/convert_mission"); ?>";  
bootbox.confirm('<div class="assignpopup"><select class="form-control" id="eid" name="eid"><option>Select Following Employee </option><?php  foreach ($employees as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><br><select class="form-control" id="reason" name="reason"><option>Reason to convert</option><option value="Passing the date">Passing the date</option><option value="Unsuffienet time">Unsuffienet time</option></select><br><textarea placeholder="Notes" name="note" id="notes" class="form-control col-md-12"></textarea></div>', function(result){
if(result){
	var  empid = $('#employee_id :selected').val();
	var  eid = $('#eid :selected').val();  
	var  reason = $('#reason :selected').val();
	var  notes = $('#notes').val();

    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id,"case_id" : case_id,'empid':empid,'eid':eid,'reason':reason,'notes':notes,'type':'general',},
    success:function(data){
       $('#msg').show();
	   //alert(data);
         $('#msg').html(data);
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Convert Failed');
}
})
});
  <?php if(isset($datas[3][3]) && $datas[3][3] == 1){?>
    $('.dataTables_filter').show();
  <?php }else{?>
    $('.dataTables_filter').hide();
  <?php } ?>

  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });

 
    $("#m_datatable").on("click", ".delete_appoinment", function() {
    var id=$(this).attr("id");

    var url="<?= base_url("admin/$control/delete_mission"); ?>"; 
    bootbox.confirm("Are you sure?", function(result){
      if(result)
      {
        $.ajax({
          type:'ajax',
          method:'post',
          url:url,
          data:{"id" : id},
          success:function(data){
            $('#msg').show();
            $('#msg').html(data);
          },
        });
        $('.hide'+id).hide(200);
        return true;
      }
      else
      {
        $('#msg').show();
        $('#msg').html('delete failed');
      }
    })
  });
</script>