<?php
include('header.php');

?>
    <style>
        .nav {
            display: -webkit-box;
        }
    </style>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Financial');?>
                            </h3>
                        </div>
                    </div>
                </div>
				<?php echo $this->session->flashdata('showMsg'); ?>
                <div class="m-portlet__body">
                    <!-- Sec tabs --->
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle=" " href="<?php echo base_url('admin/finance'); ?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('List');?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle=" " href="<?php echo base_url('admin/finance/expenses_list'); ?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Expense_List');?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('admin/finance/approve_pending_invoice_list'); ?>" data-target=" "><?php echo $this->lang->line('Pending_Invoice');?></a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
                            <div class="">


                                <div class="row align-items-center dataTables_wrapper dt-bootstrap4 no-footer" style="margin-bottom: 20px">
<?php if($this->session->userdata('role_id') == 1){
		$users =  $this->db->select("users.*,chat.create_date,chat.user_id")->join('chat', "chat.user_id = users.id", 'left')
			->where("users.role_id",3)->order_by('chat.create_date', 'DESC')->group_by('users.id')
			->get("users")
			->result_array();
		} ELSE {
			$users =  $this->db->select("customers.*,chat.create_date,chat.user_id")->join('chat', "chat.user_id = customers.user_id", 'left')
			->where("customers.user_id",$this->session->userdata('admin_id'))->order_by('chat.create_date', 'DESC')->group_by('customers.user_id')
			->get("customers")
			->result_array();
		} ?>
                              
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <?php echo form_open("admin/finance",['id'=>'archive']); ?> 
                <select id="clientsel" class="form-control" name="clients">
		    	<option><?php echo $this->lang->line('Select_Client');?></option>
				
			<?php  foreach ($users as $get_per_clients) {?>
			<?php if($this->session->userdata('role_id') == 1){ ?>
		    	<option value="<?php echo $get_per_clients['id']?>" <?php if($custo_id==$get_per_clients['id']){ echo "selected=selected";}?>><?php echo $get_per_clients['name']?></option>
			<?php } else {?>
			
		    	<option value="<?php echo $get_per_clients['customers_id']?>" <?php if($custo_id==$get_per_clients['customers_id']){  }?>><?php echo $get_per_clients['client_name']?></option>
			<?php } } ?>
				<?php /*
				$c  = isset($_POST['clients'])?$_POST['clients']:'';  
				$t  = isset($_POST['cases'])?$_POST['cases']:'';  
				foreach ($users as $get_per_clients) {?>
		    	<option value="<?php echo $get_per_clients['id']?>" <?php if($c==$get_per_clients['id']) echo "selected=selected";?>><?php echo $get_per_clients['name']?></option>
				<?php } */?>
				</select>
				</div>
				<div class="col-md-3">
				<select class="form-control" id="casesel" name="cases">
		    	<option value=""><?php echo $this->lang->line('Select_E_Service');?></option>
				<?php /* foreach ($get_per_case as $get_per_case) {?>
				<option value="<?php echo $get_per_case['id']?>" <?php if($t==$get_per_case['id']) echo "selected=selected";?>><?php echo $get_per_case['case_number']?></option>
				<?php } */?>	    
				</select> 
                                            </div>

                                            <div class="col-md-1">
                                                <?php echo form_submit(['id'=>'addcustomer','value'=>'Find','class'=>'btn btn-primary ']); ?>
                                            </div>
                                            <div class="col-md-1">
                                               <a href="" class="btn btn-danger"  ><?php echo $this->lang->line('Reset');?></a>
                                            </div>
                                            
<?php if($this->session->userdata('admin_id') == 463 OR $this->session->userdata('admin_id') == 470 OR (isset($datas[1][6]) && $datas[1][6] == 1)){ ?>
											<div class="col-md-3 ">    <a href="<?php echo base_url('admin/finance/pending_invoice_list'); ?>" class="btn btn-success  float-right"><i class="fa fa-plus"></i> <?php echo $this->lang->line('Create_Invoice');?></a>
											</div>
											<?php } ?>
                                        </div>
                                    </div>
	</form>
        
                                </div>
                                <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped" id="m_datatable">
                                            <thead>
                                            <tr class="netTr">

                                                <th><?php echo $this->lang->line('SR_NO');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Case_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('File_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Client_Name');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Phone');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                  <th>Main <?php echo $this->lang->line('Invoice_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Invoice_No');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Created_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Created_Time');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Due_Date');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Due_Time');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Created_By');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Invoice_Title');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Total_Cost');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('VAT_0_5');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Total_Amount');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                                <th><?php echo $this->lang->line('Status');?></th>
                                                <th><?php echo $this->lang->line('ACTION');?></th>

                                            </tr>
                                            </thead>
                                            <tbody>
						<?php $i=0; foreach ($invoice as $invoice){ $i++; ?>
                      <tr class="hide<?php echo $invoice['id'] ?>"  style="text-align: center;">
                        <td><?= $i; ?></td>
                        <td><?= $invoice['case_number'] ?></td>
                        <td><?= $invoice['client_file_number'] ?></td>
                        <td><?= $invoice['client_name'] ?></td>
                        <td><?= getCustomerMobile($invoice['customers_id']) ?></td>
                        <td><?= $invoice['main_invoice_no'] ?></td>
						<td><?= $invoice['invoice_no'] ?></td>
						<td><?php $timestamp = strtotime($invoice['create_date']); echo  getTheDayAndDateFromDatePan(date("d/m/Y",$timestamp));?></td>
						<td><?php $timestamp = strtotime($invoice['create_date']); echo  date("h:i a",$timestamp);?></td>
                        <td><?= getTheDayAndDateFromDatePan($invoice['due_date']); ?></td>
                        <td><?= $invoice['due_time'] ?></td>
                        <td><?php echo getEmployeeName($invoice['created_by']); ?></td>
						<td><?= $invoice['invoice_title'] ?></td>
						<td><?php  $vat = $invoice['main_total']/$invoice['financial_payments']; echo number_format((float)$vat, 2, '.', '');?></td>
						<td><?php $assd=  ($vat * 5) / 100;  echo number_format((float)$assd, 2, '.', '');?></td>
						<td><?= $invoice['total'] ?></td>
						<td><?php if($invoice['payment_status'] == 'paid'){ $dd = "success"; } else if($invoice['payment_status'] == 'process') { $dd="warning"; } else { 	$dd="warning"; } ?><span class="m-badge  m-badge--<?php echo $dd; ?> m-badge--wide"><?php echo $invoice['payment_status'] ?></span></td>
						<td class="action">
                        <?php if($invoice['is_reject'] == 1) { ?>
                        <span class="m-badge  m-badge--danger m-badge--wide"><?php echo $this->lang->line('Reject');?></span>
							
			    		<?php } else { ?>
						<a  href='<?= base_url("admin/finance/edit_invoice/{$invoice['id']}"); ?>' class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit_Invoice');?>"><i class="fa fa-edit"></i></a>
						<a  href='<?= base_url("admin/finance/generate_invoice/{$invoice['id']}"); ?>' class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill " title="<?php echo $this->lang->line('generate_invoice');?>"><i class="fa fa-file-pdf-o"></i></a>
						<a href="javascript:;" id="<?= $invoice['id'] ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill  delete_case" title="<?php echo $this->lang->line('delete_invoice');?>"><i class="fa fa-trash"></i></a>
					<?php } ?>
					</td>

                </tr> 
                <?php } ?> 
                                            </tbody>
                                        </table>
                                    </div>

                                     
                                </div>


                            </div>
                        </div>
                       
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php

include('footer.php');

?>
 <script type="text/javascript">
$(document).ready(function() {
	$('#msg').hide();
});
</script>
<script type="text/javascript">

 
$("#m_datatable").on("click", ".delete_case", function() {
var id=$(this).attr("id");
var url="<?= base_url('admin/finance/delete_invoice'); ?>"; 
bootbox.confirm("Are you sure?", function(result){
if(result){
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);
      },
  });
$('.hide'+id).hide(200);
return true;
}
else
{
$('#msg').show();
	$('#msg').html('delete failed');
}
})
});
$('#clientsel').on('change', function() {
var url="<?= base_url('admin/archive/select_case_id'); ?>"; 
var id = this.value;
$.ajax({
  type:'ajax',
  method:'post',
  url:url,
  data:{"id" : id},
  success:function(data){
 
	$('#casesel').html(data);
  },
});
});
</script> 