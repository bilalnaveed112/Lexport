<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Fine');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">


                    <div class="row align-items-center dataTables_wrapper dt-bootstrap4 no-footer" style="margin-bottom: 20px">


                        <div class="col-xl-8 order-2 order-xl-1">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">

                                <div class="col-md-4">

                                    <?php   if($this->session->userdata('role_id') == 1){ ?>
					<strong class=" "><a class="btn btn-success btn-lg"href="<?=base_url('admin/hr/add_hr_fine');?>"><i class="fa fa-plus"></i> <?php echo $this->lang->line('Add_Fine');?></a></li></strong>  <?php } ?>

                                </div>

                            </div>

                        </div>

               

                    </div>




                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">

                                <th><?php echo $this->lang->line('SR_NO');?></th>
                                <th><?php echo $this->lang->line('Employee_Name');?></th>
                                <th><?php echo $this->lang->line('Fine_Type');?></th>
                                <th><?php echo $this->lang->line('Date');?></th>
                                <th><?php echo $this->lang->line('Reason');?></th>
<?php   if($this->session->userdata('role_id') == 1){ ?>   <th><?php echo $this->lang->line('ACTION');?></th> <?php } ?>
                            </tr>
                            </thead>
                            <tbody>
  <?php $count=1;
                       foreach($data as $Padding_cus) { ?>
                       <tr class="hide<?= $Padding_cus['id']; ?>" style="text-align: center;">
                        <td><?= $count++ ?></td>
                        <td><?= getEmployeeName($Padding_cus['user_id']) ?></td>
                        <td><?= getFineName($Padding_cus['fine_type']) ?></td>
                        <td><?php echo getTheDayAndDateFromDatePan($Padding_cus['start_date']);?></td>
                        <td><?= $Padding_cus['reason'] ?></td>
						<?php   if($this->session->userdata('role_id') == 1){ ?>
						<td>
						 <a href=<?= base_url("admin/hr/find_hr_fine/{$Padding_cus['id']}") ?> class="fa fa-edit "  title="<?php echo $this->lang->line('Edit_Fine');?>" id=<?= $Padding_cus['id'] ?>> </a> &nbsp;
						   <a href="javascript:;" class="fa fa-trash deleteservices" id='<?= $Padding_cus['id']; ?>' title="<?php echo $this->lang->line('Delete_Fine');?>"> </td>
						</td> 
						<?php } ?>
                      </tr>
				<?php } ?> 
                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>


        </div>




    </div>

<?php

include('footer.php');

?>

<script type="text/javascript">

	$(document).ready(function() {
	   $('#msg').hide();
	  //$('#customers-table').DataTable();
	} );
	
$(document).ready(function()
{
  $('#msg').hide();

$(".deleteservices").click(function()
{
  var id=$(this).attr("id");
  var url="<?= base_url('admin/hr/delete_hr_fine'); ?>"; 
bootbox.confirm("Are you sure?", function(result){
if(result){
  $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
    dataTyppe: 'json',
  
    success:function(data){
       $('#msg').show();
          $('#msg').html(data);

      },
  });
$('.hide'+id).hide(200);
return true;
}
else
{
$('#msg').show();
	$('#msg').html('Delete Failed');
}
})
 });
});
</script>

