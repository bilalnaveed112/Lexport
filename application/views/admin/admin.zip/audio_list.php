<?php
include('header.php');

?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('Audio_List');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">
 
   <div class="row" style="margin-bottom: 20px">

                        <div class="col-xl-12 order-2 order-xl-1">

                            <div class="form-group m-form__group row align-items-right" style="margin-bottom: 0">

                                <div class="col-md-4">

                                    <a href="<?=base_url('admin/admin/add_audio_record');?>" class="btn btn-primary m-btn btn-cst  m-btn--custom m-btn--icon m-btn--air" style="border-radius: 20px;">
                                        <span>
                                            <i class="fa fa-plus"></i>
                                        <span><?php echo $this->lang->line('Add_Audio');?></span>
                                        </span>
                                    </a>

                                </div>
                            </div>

                        </div>

                    </div>
                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table class="table table-hover table-striped" id="m_datatable">
                            <thead>
                            <tr class="netTr">
							<th><?php echo $this->lang->line('SR_NO');?></th>
							<th><?php echo $this->lang->line('Audio_Name');?></th>
							<th><?php echo $this->lang->line('Client_Name');?></th>
							<th><?php echo $this->lang->line('Note');?></th>
							<th><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </thead>
                            <tbody>
					<?php $count=1;
                       foreach($data as $ado) { ?>
                        <tr class="" style="text-align: center;">
                        <td><?= $count++ ?></td>
                        <td><?= $ado['audio_name'] ?></td>
						<td><?= getEmployeeName($ado['user_id']); ?></td>
                        <td><?= $ado['note'] ?></td>
                        <td>
						<a class="fa fa-edit" href="<?php echo base_url(); ?>admin/admin/find_audio/<?php echo $ado['id'] ; ?>"></a> 
						<a href="javascript:;" class="fa fa-trash delete_note" id='<?=$ado['id']; ?>' title="<?php echo $this->lang->line('Delete_Audio');?>">
						</td>
                      </tr>
				<?php } ?>
                            </tbody>
                        </table>

                       
                    </div>


                </div>
            </div>


        </div>

    </div>

<?php

include('footer.php');
?>

 <script type="text/javascript">

$("#m_datatable").on("click", ".delete_note", function() {
  var id=$(this).attr("id");
  var url="<?= base_url('admin/admin/delete_audio'); ?>"; 
   bootbox.confirm("Are you sure?", function(result){
    if(result)
    {
      $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id},
  
    success:function(data){
       $('#msg').show();
         $('#msg').html(data);location.reload();

      },
  });
$('.hide'+id).hide(200); 
return true;
  }
  else
  {
      $('#msg').show();
       $('#msg').html('delete failed');
  }
    })
    });
</script>