<?php include __DIR__ . "/../header.php"; $control="mission_general";?>
<style>
    .nav {
        display: -webkit-box;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
<!-- END: Subheader -->
<div class="m-content"> 
        <!--begin::Portlet-->
        <div class="m-portlet">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            <?php echo $this->lang->line('GENERAL');?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="m-portlet__body">
<!-- Assign -->
			<div id="msg" class="sufee-alert alert with-close alert-success alert-dismissible fade show success"></div>
					<!-- Assign -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_mission");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('All');?></a>
                    </li> 
					<li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_responsible") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_responsible");?>" data-target="#m_tabs_1_1"><?php echo $this->lang->line('Responsible_Employee');?> <span class="num_tab"><?php echo ResponsibleNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_follow_up") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_follow_up");?>" data-target="#m_tabs_1_2"><?php echo $this->lang->line('Following_Employee');?> <span class="num_tab"><?php echo FollowNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_pending_misssion") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_pending_misssion");?>" data-target="#m_tabs_1_3"><?php echo $this->lang->line('Pending');?> <span class="num_tab"><?php echo PendingNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_close_mission") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_close_mission");?>" data-target="#m_tabs_1_4"><?php echo $this->lang->line('Close_Mission');?> <span class="num_tab"><?php echo CloseNotification('general_mission'); ?></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($this->uri->segment(3) == "list_review") echo "active";?>" data-toggle="" href="<?=base_url("admin/$control/list_review");?>" data-target="#m_tabs_1_5"><?php echo $this->lang->line('In_Review');?> <span class="num_tab"><?php echo ReviewNotification('general_mission'); ?></span></a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
                        <div class="m-portlet__body">
                            <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                                <div class="table-responsive">
                                    <table class="table table-hover table-striped" id="m_datatable">
                                        <thead>
                                       <tr class="netTr">
                                                        <th><?php echo $this->lang->line('SR_NO');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('File_Number');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Client_Type');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Client_Name');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('E_Service_Number');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('General_Type');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Responsible_Employee');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					 <th><?php echo $this->lang->line('Following_Employee');?> <br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('End_Date');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('End_Time');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Requirement');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('Due_Time');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
					<th><?php echo $this->lang->line('ACTION');?><br><i class="fa fa-arrow-up" style="font-size: 10px;font-weight: normal"></i><i class="fa fa-arrow-down" style="font-size: 10px;font-weight: normal"></i></th>
                                        </tr>
                                        </thead>
                                        <tbody>
             <?php 
              $count=1;
              foreach($data as $appoinment){  ?>
					<tr class="hide<?php echo $appoinment['id'] ?>" style="text-align:center;">
                 <td><?php echo $count++;  ?></td>
                <td><?= $appoinment['client_file_number'] ?></td>
				<td><?php   $row = $this->db->select('*')->where('client_file_number',$appoinment['client_file_number'])->get('customers')->row();   if($row){ echo $row->type_of_customer; }?></td>
                <td><?= $appoinment['client_name']; ?></td>
                <td><?= $appoinment['case_number']; ?></td>
				<td><?= getGeneralType($appoinment['general_type']); ?></td>
				 <td>
				<?php  if($appoinment['responsible_employee'] != ''){ echo getEmployeeName($appoinment['responsible_employee']); } ?>
				</td>
					<td><?php echo getEmployeeName($appoinment['follow_up_employee']); ?></td>
                <td><?php echo getTheDayAndDateFromDatePan($appoinment['session_end_date']); ?></td>
                <td><?= $appoinment['session_end_time'] ?></td>
				<td><?= $appoinment['note'] ?></td>
									<td>
				    
				    <?php 
				    if($appoinment[is_close]==1){
				        echo clsoe_diff($appoinment['session_end_date'],$appoinment['session_end_time'],$appoinment['close_date']);
				    } else {
				    ?> 
				    <span class='countdown' style=" color: #0e8a00; font-weight: bold; " 
				  value='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>' data-countdown='<?php echo mission_due_time($appoinment['session_end_date'],$appoinment['session_end_time']);?>'></span>
				  <?php } ?>
				  </td>
			<td class="action">
				<!-- ASSIGN -->
			<span style="overflow: visible; position: relative;">
				<a href="javascript:;"  data-user="<?= $appoinment['customers_id'] ?>" id="<?= $appoinment['id'] ?>"  class="hideass<?php // $case['id'] ?> m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill assign_type dropdown assign_case" data-case="<?= $appoinment['case_id'] ?>" title="Assign Follow Up Employee">
					<i class="fa fa-user-plus"></i>
				</a>
			</span>
			<!-- ASSIGN -->
					<span style="overflow: visible; position: relative;"> 
				<?php if( isset($datas[6][1]) && $datas[6][1] == 1 ){ ?>
					<a href="<?= base_url("admin/$control/find_mission/{$appoinment['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit');?>">
					<i class="fa fa-edit"></i>
					</a>
                <?php  } ?>
				    <?php if($this->session->userdata('role_id') == 1  ){ ?>
                    
					<a href="javascript:;" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill delete_appoinment"  id="<?= $appoinment['id'] ?>" title="<?php echo $this->lang->line('Delete');?>">
					<i class="fa fa-trash"></i>
					</a>
					 <?php  } ?>
					  
				<?php if(isset($datas[6][3]) && $datas[6][3] == 1) { ?>
					<a href="<?= base_url("admin/$control/view_mission/{$appoinment['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('View');?>">
					<i class="fa fa-eye"></i>
					</a>
				<?php } ?>
					</span>
					<?php if(isset($datas[6][4]) && $datas[6][4] == 1) { ?>
					<span style="overflow: visible; position: relative;">
					<a href="javascript:;" data-user="<?= $appoinment['case_id'] ?>" id="<?= $appoinment['id'] ?>"  class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill convert_case" title="<?php echo $this->lang->line('Convert_Case');?>">
					<i class="fa fa-refresh"></i>
					</a>
					</span>
					 <?php  } ?>
                </td>
              </tr>
            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
 
                            </div>


                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>

        </div>


    </div>

</div>


<?php include __DIR__ . "/../footer.php"; ?>

<script type="text/javascript">

$("#m_datatable").on("click", ".assign_case", function() {
var id=$(this).attr("id");
var customers_id=$(this).data("user");
var case_id=$(this).data("case");
<?php 
date_default_timezone_set('Asia/Riyadh');
if($this->session->userdata('admin_site_lang')=="arabic" OR $this->session->userdata('admin_site_lang')==""){
$start_date = explode('-',date('Y-d-m'));
$start_date = Greg2Hijri($start_date[1],$start_date[2],$start_date[0],true); 

} else {
	$start_date = date('d/m/Y');
}
?>
var msg= $('#note_dialog').html();
var url="<?= base_url('admin/admin/assign_mission_following_emp'); ?>"; 

bootbox.confirm('<div class="assignpopup"><h3>Assign Following Employee</h3><select class="form-control" id="following_employee_id" name="following_employee_id" ><option value="0">Select Following Employee </option><?php  foreach (getEmployeeList() as $employee) { ?><option value="<?php echo $employee["id"]?>"><?php echo $employee["name"]?></option><?php } ?></select><!--<input type="text" placeholder="Start date" class="form-control col-md-6" name="start_date" id="start_date" value="<?php echo $start_date; ?>" readonly><input type="text" name="start_time" value="<?php echo date('h:i') ?>" placeholder="Start time" id="start_time" class="form-control  col-md-6" readonly>--><textarea placeholder="Notes*" name="note" id="notes" class="form-control col-md-12" required></textarea><label class="nterr" style="color:red"></label></div>', function(result){
if(result){
 
	var  following_employee_id = $('#following_employee_id :selected').val();
	var  start_date = $('#start_date').val();
	var  end_date = $('#end_date').val();
	var  start_time = $('#start_time').val();
	var  end_time = $('#end_time').val();
	var  notes = $('#notes').val();
if(notes==''){
	$('.nterr').html('Note is required');
	return false;
}
$('.nterr').html('');
    $.ajax({
    type:'ajax',
    method:'post',
    url:url,
    data:{"id" : id,"customers_id" : customers_id,'following_employee_id':following_employee_id,'start_date':start_date,'end_date':end_date,'start_time':start_time,'end_time':end_time,'notes':notes,type:'general_mission',case_id:case_id},
    success:function(data){
       $('#msg').show();
	   //alert(data);
		$('#msg').html(data);
	//	$('.hideass'+id).hide();
      },
  });

return true;
}
else
{
$('#msg').show();
	$('#msg').html('Assign Failed');
}
})
});
  <?php if(isset($datas[3][3]) && $datas[3][3] == 1){?>
    $('.dataTables_filter').show();
  <?php }else{?>
    $('.dataTables_filter').hide();
  <?php } ?>

  $(document).ready(function()
  {
    $('#msg').hide();
    $('#customers-table').DataTable();
  });

$("#m_datatable").on("click", ".delete_appoinment", function() {
    
    var id=$(this).attr("id");

    var url="<?= base_url("admin/$control/delete_mission"); ?>"; 
    bootbox.confirm("Are you sure?", function(result){
      if(result)
      {
        $.ajax({
          type:'ajax',
          method:'post',
          url:url,
          data:{"id" : id},
          success:function(data){
            $('#msg').show();
            $('#msg').html(data);
          },
        });
        $('.hide'+id).hide(200);
        return true;
      }
      else
      {
        $('#msg').show();
        $('#msg').html('delete failed');
      }
    })
  });
</script>

<style>
    .modal .modal-content .modal-header .close:before {
        content: "X";
        font-family: arial;
    }
    .modal .modal-content {
        background: #ffffff;
    }
</style>
 
