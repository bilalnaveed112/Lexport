<?php $nvc = "white-nav sticky shrink modern hover4 radius-drop"; 
$pageTitle = $this->lang->line('e-services');
include('header.php');
?>
 </section>
<?php
include('header_welcome.php');
?>
<!-- END: Left Aside -->
<div class="m-grid__item m-grid__item--fluid m-wrapper">
<style>    .modal .modal-content .modal-header .close:before {
        content: "X";
        font-family: arial;
    }
    .modal .modal-content {
        background: #ffffff;
    }</style>

    <!-- END: Subheader -->
    <div class="m-content">
                   <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                                <?php echo $this->lang->line('e-services');?>
                            </h3>
                        </div>
                    </div>
                </div>


                <div class="m-portlet__body">
 
                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">

                        <table id="m_table_11" class="table table-hover table-striped">
                            <thead>
                            <tr class="netTr">
                                <th scope="col"><?php echo $this->lang->line('E_Service_No');?></th>
                                <th scope="col"><?php echo $this->lang->line('Name');?></th>
                                <th scope="col"><?php echo $this->lang->line('E_Service_Name');?></th>
                               
                                <th scope="col"><?php echo $this->lang->line('Contact_No');?></th>
 <th scope="col"><?php echo $this->lang->line('Contract_No');?></th>
                                <th scope="col"><?php echo $this->lang->line('Status');?></th>
                                <th scope="col"><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </thead>
                            <tbody>
							<?php foreach ($data as $case){ ?>
                            <tr style="text-align: center;" class="hov-tab">
                                <th scope="col"><?= $case['case_number'] ?></th>
                                <th scope="col"><?= $case['client_name'] ?></th>
                                <th scope="col"><?= getServiceType($case['service_types']) ?></th>
                               <th scope="col"><?php echo getCustomerMobile($case['customers_id']);  ?></th>
                                <th scope="col"><?= $case['contract_number'] ?></th>
                                <th scope="col">
								<?php if($case['is_reject'] == 1){ ?>
								<span class="m-badge  m-badge--danger m-badge--wide"><?php echo $this->lang->line('Reject');?></span>
								<?php } else if(isset($case['case_id'])) { ?>
								<span class="m-badge  m-badge--warning m-badge--wide"><?php echo $this->lang->line('Pending');?></span>
								<?php }else{ ?>
								<span class="m-badge  m-badge--success m-badge--wide"><?php echo $this->lang->line('Approve');?></span>
								<?php }?>
								</th>
                                <th scope="col">
			             <?php if($case['is_reject'] == 1){ ?>
                        <span  id="<?php echo $case['case_id']; ?>" class="m-badge  m-badge--danger m-badge--wide rejectr" style=" cursor: pointer; "><?php echo $this->lang->line('View_reject_reason');?></span> 
                        <?php } ?>
                        	  <?php if($case['is_reject'] == 0){ ?>
								<span style="overflow: visible; position: relative;">
							    	<a href="<?= base_url("front/find_case/{$case['id']}"); ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Edit');?>">
										<i class="fa fa-edit"></i>
									</a>
									<?php } ?>
									<a href="<?= base_url("front/view_case/{$case['id']}") ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('View');?>">
										<i class="fa fa-eye"></i>
									</a>
								</span>
                                </th>
                            </tr>
							<?php } ?>
                            

                            </tbody>
                        </table>

                    </div>


                </div>
        <!--End::Section-->
    </div>
</div>
</div>

</div>

<?php

include('footer.php');

?>
<script type="text/javascript">
 
  $(document).ready( function() {
    $('#m_table_11').dataTable({ 
        "lengthChange": true,
        "aaSorting": [],
          language: {
    paginate: {
      next: '<i class="fa fa-angle-left"></i>', // or '→'
      previous: '<i class="fa fa-angle-right"></i>', // or '←' 
      
    },
    <?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") {  ?>
    "sProcessing":   "جارٍ التحميل...",
    "sLengthMenu":   "أظهر _MENU_ ",
    "sZeroRecords":  "لم يعثر على أية سجلات",
    "sInfo":         "إظهار _START_ إلى _END_ من أصل _TOTAL_ مدخل",
    "sInfoEmpty":    "يعرض 0 إلى 0 من أصل 0 سجل",
    "sInfoFiltered": "(منتقاة من مجموع _MAX_ مُدخل)",
    "sInfoPostFix":  "",
    "sSearch":       "ابحث:",
    "sUrl":          "",
    <?php } else { ?>
        "sLengthMenu":   "Show  _MENU_ ",
    <?php  } ?>
  }
    });
})
    $(document).ready(function() {
        $('#msg').hide();
    });

    $('.rejectr').click(function(){
        var id=$(this).attr("id");
        var url="<?= base_url('front/get_reject_case_reason'); ?>"; 
		     $.ajax({
                    type:'ajax',
                    method:'post',
                    url:url,
                    data:{"id" : id},
                    success:function(data){
                       bootbox.alert(data);
                    },
                });
        });

</script>     <script src="<?=base_url('assets/bootbox.min.js')?>"></script>