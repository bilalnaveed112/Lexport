<?php $nvc = "white-nav sticky shrink modern hover4 radius-drop"; 
$pageTitle = $this->lang->line("Dashboard");
include('header.php');
?>
 </section>
<?php
include('header_welcome.php');
?>
<!-- END: Left Aside -->
<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">
        <div class="row">
            <div class="col-xl-6 col-lg-12">

                <!--Begin::Portlet-->
                <div class="m-portlet  m-portlet--full-height  m-portlet--rounded">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <h3 class="m-portlet__head-text">
                                    <?php echo $this->lang->line('Current_E_Services');?>
                                </h3>
                            </div>
                        </div>

                    </div>

                    <div   class="m-portlet__body m-scrollable" data-scrollable="true" data-height="350" data-mobile-height="300" style="width: 100%;padding: 15px;">
                        <div class="m-widget3">
						  <?php foreach ($data as $case){ ?>

                            <div class="m-widget3__item">
                                <div class="m-widget3__header">
                                    <div class="m-widget3__info <?php echo $case['id'] ?>">
                                        <span class="m-widget3__time"><?php echo $this->lang->line('Number');?>: <?= $case['case_number'] ?></span>
                                    </div>
                                    <span class="m-badge m-badge--brand m-badge--wide" style="background-color: <?php if($case['is_reject'] == 1){ echo "red"; } else if(isset($case['case_id'])) { echo "orange"; }else{ echo "green"; } ?>;"><?php if($case['is_reject'] == 1){ echo $this->lang->line("Reject"); } else if(isset($case['case_id'])) { echo $this->lang->line("Pending"); }else{ echo $this->lang->line("Approve"); } ?></span>
                                </div>
                                <div class="m-widget3__body">
                                    <p class="m-widget3__text">
                                        <a href="<?php echo base_url();?>front/view_case/<?php echo $case['id'] ?>">
                                            <b><?= getServiceType($case['service_types']) ?></b>
                                        </a>
                                    </p>
                                </div>
                            </div>
						<?php } ?>
                             

                        </div>
                    </div>
                </div>

                <!--End::Portlet-->
            </div>
            <div class="col-xl-6 col-lg-12">

                <!--Begin::Portlet-->
                <div class="m-portlet m-portlet--full-height  m-portlet--rounded">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <h3 class="m-portlet__head-text">
                                    <?php echo $this->lang->line('Recent_Activities');?>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">

                        <div class="row  align-items-center">
                            <div class="m-scrollable" data-scrollable="true" data-height="350" data-mobile-height="300" style="width: 100%;padding: 15px;">

                                <!--Begin::Timeline 2 -->
                                <div class="m-timeline-2" id="m-timeline-2">
                                    <div class="m-timeline-2__items  m--padding-top-25 m--padding-bottom-30">
									<?php	$cid = $this->session->userdata('user_id');
									$this->db->select('*')->where("(customer_id='$cid')", NULL, FALSE);
									$files = $this->db->order_by("id", "desc")->get('notification')->result_array();
									foreach ($files as $n) { ?>
									<?php if($n['status_type'] == 'logout'){ ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
                                                <?php echo $this->lang->line('Logged_out_successfully');?>
                                            </div>
                                        </div>
									<?php } ?>
									<?php if($n['status_type'] == 'login'){ ?>
									<?php $dinfo = json_decode($n['device_log']);  ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
                                                <?php echo $this->lang->line('Logged_in_from');?> <?php echo $dinfo->name; echo " "; echo $dinfo->platform; ?> <br> <?php echo $this->lang->line('from_IP');?>: <?php echo $n['login_ip'];?>
                                            </div>
                                        </div>
									<?php } ?>
									
									<?php if($n['status_type'] == 'register'){ ?>
									<?php $dinfo = json_decode($n['device_log']);  ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item  <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
Registration successfully  <?php echo $dinfo->name; echo " "; echo $dinfo->platform; ?>  A<?php echo $this->lang->line('from_IP');?>: <?php echo $n['login_ip'];?>
                                            </div>
                                        </div>
									<?php } ?>
									<?php if($n['notification_type'] == 'msg'){ ?>
                                        <div id="readnotificaion"  class="m-timeline-2__item  <?php if($n['read_status'] == 0) echo "notireaded"; ?>" data-read="<?php echo $n['id'];?>">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text  m--padding-top-5">
                                                <?php echo $this->lang->line('You_have_New_message');?> 
                                            </div>
                                        </div>
			 
									<?php } ?>
									<?php if($n['notification_type'] == 'invoice'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-brand"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/alert/") ?>" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                                <?php echo $this->lang->line('Your_invoice_for_case');?> (#<?php echo getCaseNumber($n['case_id']) ;?>)  <?php echo $this->lang->line('has_been_created');?>
												</a>
                                            </div>
                                        </div>
										<?php } ?>
										<?php if($n['notification_type'] == 'case'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?php echo base_url("/front/view_case/{$n['case_id']}") ?>"  class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>"><span  >#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Your_e_service_has_been_added');?></span></a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'reject'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
										<a href="<?= base_url("/front/view_case/{$n['case_id']}") ?>"  class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>"><span >#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Your_e_service_has_been_rejected');?></span></a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'approve'){ ?>
                                        <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-brand"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_case/{$n['case_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>"><span style="color:green">#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Your_e_service_has_been_approved');?></span></a>
                                            </div>
                                        </div>
										<?php } ?>
 
										 <?php } ?>
										<?php if($n['notification_type'] == 'session_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Session_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Session_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 
										<?php if($n['notification_type'] == 'general_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_general_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('General_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_general_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('General_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 
										 <?php if($n['notification_type'] == 'visiting_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_visiting_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Visiting_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_visiting_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Visiting_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 <?php if($n['notification_type'] == 'consultation_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_consultation_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Consultation_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_consultation_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Consultation_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 
										 
										 <?php if($n['notification_type'] == 'writings_appoinment'){ ?>
										<?php if($n['status_type'] == 'add'){ ?>
										  <div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-warning"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_writings_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
                                               #<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Writing_mission_added');?>
											 </a>
                                            </div>
                                        </div>
										 <?php } ?>
										<?php if($n['status_type'] == 'close'){ ?>
										<div class="m-timeline-2__item  ">
                                            <span class="m-timeline-2__item-time"><?php $timestamp = strtotime($n['create_date']); echo  date("G:i",$timestamp);?></span>
                                            <div class="m-timeline-2__item-cricle">
                                                <i class="fa fa-genderless m--font-danger"></i>
                                            </div>
                                            <div class="m-timeline-2__item-text m--padding-top-5">
											<a href="<?= base_url("/front/view_writings_appoinment/{$n['appointment_id']}") ?>" id="readnotificaion" class="<?php if($n['read_status'] == 0) echo "notireaded"; ?>"  data-read="<?php echo $n['id'];?>">
												#<?php echo getCaseNumber($n['case_id']);?> <?php echo $this->lang->line('Writing_mission_has_been_close');?>
											</a>
                                            </div>
                                        </div>
									
										 <?php } ?>
										 <?php } ?>
										 <?php } ?>
                                    </div>
                                </div>

                                <!--End::Timeline 2 -->
                            </div>
                        </div>

                    </div>
                </div>

                <!--End::Portlet-->
            </div>
        </div>


        <!--End::Section-->
    </div>
</div>
</div>



<?php

include('footer.php');

?>
<script>
/* 
$('[id="readnotificaion"]').on('click', function(){
	var id=$(this).data("read");  
	var url="<?=base_url('front/read_notification_status');?>";
    $.ajax({
		type:'ajax',
		method:'post',
		url:url,
		data:{"id" : id},
		success:function(data){
		  $('.noticount').html(data);
		}
	});
});*/
</script>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#m_modal_1').modal('show');
    });
</script>
<style>
.notireaded div {
    font-weight: bold !important;
    cursor: pointer;
}
.notireaded {
    font-weight: bold !important;
    cursor: pointer;
}
    .con-bar-top{
        background: #000000;
        padding: 10px;
    }
    .minSl{
        padding: 50px;
        background: #ffffff;
        border-radius: 20px;
    }
    .con{
        background: #ffffff url(<?php echo base_url('assets/images');?>/img/slIc/bg-1.png);
        background-repeat: no-repeat;
        background-position: center top;
        background-size: 50%;
        *height: 800px;
    }
    .modal {
        top: 0;
    }
    .text-slider{
        text-align: center;
        margin-top: 10%;
        margin-bottom: 10%;
    }
    .text-slider h3{
        font-family: sans-serif;
        font-weight: bold;
        margin-bottom: 10px;
        font-size: 30px;
        color: #1F3959;
    }
    .text-slider p{
        font-family: sans-serif;
        font-size: 16px;
    }
    .carousel-indicators li {
        background-color: #f3f3f3;
        width: 10px;
        height: 10px;
        border-radius: 50%;
    }
    .carousel-indicators .active {
        background-color: #ccc;
    }
    .carousel-indicators {
        bottom: 15%;
    }
    .sr-only {
        position: unset;
    }
    .carousel-control-next, .carousel-control-prev {
        position: unset;
        width: 15%;
        color: #000;
        opacity: unset;
        margin: auto;
    }
    .carousel-control-next span{
        border: 1px solid #CAA457;
        border-radius: 20px;
        font-family: sans-serif;
        color: #CAA457;
        padding: 10px 50px;
    }
    .carousel-control-next:hover span{
        border: 1px solid #CAA457;
        color: #ffffff;
        background: #CAA457;
    }
</style>
<?php if(isset($_GET['popup'])) { ?>
<div class="modal hide fade" id="m_modal_1" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" style="display: block;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">

                <div id="carouselControls" class="carousel slide" data-ride="carousel">

                    <div class="con-bar-top" style="display: none">
                        <button type="button" style="color: #fff;background: transparent;" data-dismiss="modal">
                            <span class="fa fa-close" aria-hidden="true"></span>
                        </button>
                    </div>

                    <ol class="carousel-indicators">
                        <li data-target="#carouselControls" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselControls" data-slide-to="1"></li>
                        <li data-target="#carouselControls" data-slide-to="2"></li>
                        <li data-target="#carouselControls" data-slide-to="3"></li>
                        <li data-target="#carouselControls" data-slide-to="4"></li>
                        <li data-target="#carouselControls" data-slide-to="5"></li>
                    </ol>


                    <div class="minSl">

                        <div class="carousel-inner">
                            <div class="con">

                                <div class="carousel-item active">
                                    <div class="img-slider">
                                        <img src="<?php echo base_url('assets/images');?>/img/slIc/1/animat-rocket-color.gif" style="width: 50%;margin: auto;display: block;" />
                                    </div>
                                    <div class="text-slider">
                                        <h3><?php echo $this->lang->line('Shortcut_the_Time');?></h3>
                                        <p><?php echo $this->lang->line('Start_your_legal_services_quickly');?></p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="img-slider">
                                        <img src="<?php echo base_url('assets/images');?>/img/slIc/2/animat-checkmark-color.gif" style="width: 50%;margin: auto;display: block;" />
                                    </div>
                                    <div class="text-slider">
                                        <h3><?php echo $this->lang->line('Continuous_Achievement');?></h3>
                                        <p><?php echo $this->lang->line('Keep_up_with_the_services_and_be_aware_of_what_has_been_done');?></p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="img-slider">
                                        <img src="<?php echo base_url('assets/images');?>/img/slIc/3/animat-responsive-color.gif" style="width: 50%;margin: auto;display: block;" />
                                    </div>
                                    <div class="text-slider">
                                        <h3><?php echo $this->lang->line('Flexible_Use');?></h3>
                                        <p><?php echo $this->lang->line('Flexible_Use_P1');?></p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="img-slider">
                                        <img src="<?php echo base_url('assets/images');?>/img/slIc/4/animat-search-color.gif" style="width: 50%;margin: auto;display: block;" />
                                    </div>
                                    <div class="text-slider">
                                        <h3><?php echo $this->lang->line('Easy_Access');?></h3>
                                        <p><?php echo $this->lang->line('Search_for_your_request_with_one_click');?></p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="img-slider">
                                        <img src="<?php echo base_url('assets/images');?>/img/slIc/5/animat-lightbulb-color.gif" style="width: 50%;margin: auto;display: block;" />
                                    </div>
                                    <div class="text-slider">
                                        <h3><?php echo $this->lang->line('We_are_closer');?></h3>
                                        <p><?php echo $this->lang->line('We_are_closer_p1');?></p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="img-slider">
                                        <img src="<?php echo base_url('assets/images');?>/img/slIc/6/animat-customize-color.gif" style="width: 50%;margin: auto;display: block;" />
                                    </div>
                                    <div class="text-slider">
                                        <h3><?php echo $this->lang->line('Personal_Control');?></h3>
                                        <p><?php echo $this->lang->line('Personal_Control_P1');?></p>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <a class="carousel-control-prev" href="#carouselControls" role="button" data-slide="prev" style="display: none">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only"><?php echo $this->lang->line('Previous');?></span>
                        </a>
                        <a class="carousel-control-next" href="#carouselControls" role="button" data-dismiss="modal">
                            <span class=""><?php echo $this->lang->line('Skip');?></span>
                        </a>

                    </div>


                </div>

            </div>
        </div>
    </div>
</div>
<?php } ?>
