<?php $nvc = "white-nav sticky shrink modern hover4 radius-drop"; 
$pageTitle = $this->lang->line("Archives");
include('header.php');
?>
 </section>
<?php
include('header_welcome.php');
?>
<!-- END: Left Aside -->
<div class="m-grid__item m-grid__item--fluid m-wrapper">


    <!-- END: Subheader -->
    <div class="m-content">
       
                <div class="m-portlet__body">
 
                    <div class="m_datatable m-datatable m-datatable--default m-datatable--loaded" style="">
<?php 
$c = isset($_POST['file_type'])?$_POST['file_type']:''; 
$case_id = isset($_POST['case_id'])?$_POST['case_id']:''; 
   echo form_open("front/archive_list",['id'=>'archive']); ?>
<div class="row">
<div class="col-md-4">
<select id="" class="form-control" name="file_type"><option  value=""><?php echo $this->lang->line('File_Type');?></option>
<option value="1" <?php if($c==1) echo "selected=selected";?>><?php echo $this->lang->line('Documentation');?></option>
<option value="2" <?php if($c==2) echo "selected=selected";?>><?php echo $this->lang->line('Data');?></option>
<option value="3" <?php if($c==3) echo "selected=selected";?>><?php echo $this->lang->line('Contract');?></option>
<option value="4" <?php if($c==4) echo "selected=selected";?>><?php echo $this->lang->line('Report');?></option>
<option value="6" <?php if($c==6) echo "selected=selected";?>><?php echo $this->lang->line('Procuation');?></option>
<option value="7" <?php if($c==7) echo "selected=selected";?>><?php echo $this->lang->line('Referrals');?></option>
</select></div> 
<div class="col-md-4">

<select name="case_id" id="case_id" class="form-control"  >
<option  value=""><?php echo $this->lang->line('Select_E_Service_No');?></option>
<?php foreach($case_data as $cd) { ?>
		<option value="<?= $cd['doc_id']; ?>"<?php if($case_id==$cd['doc_id']) echo "selected=selected";?>><?= $cd['case_number']; ?></option>
<?php } ?>
</select>

</div> 
<div class="col-md-3"><?php $find=$this->lang->line('Find'); echo form_submit(['id'=>'addcustomer','value'=>$find,'class'=>'btn btn-primary ']); ?><a href="" class="btn btn-danger"  ><?php echo $this->lang->line('Reset');?></a></div></form></div>	
                        <table id="m_table_11" class="table table-hover table-striped">
                            <thead>
                            <tr class="netTr">
                               <tr class="netTr">
                                <th><?php echo $this->lang->line('SR_NO');?></th>
                                <th><?php echo $this->lang->line('Thumb');?></th>
                                <th><?php echo $this->lang->line('File_Name');?></th>
                                <th><?php echo $this->lang->line('File_Type');?></th>
                              
                                 <th><?php echo $this->lang->line('Uploaded_Date');?></th>
                                <th><?php echo $this->lang->line('Uploaded_by');?></th>
                                <th><?php echo $this->lang->line('ACTION');?></th>
                            </tr>
                            </tr>
                            </thead>
                            <tbody>
							  <?php 
							$count=1;
							foreach($data as $archives){

							if($archives['user_id'] != 0 ){
							$user = $this->db->select('name')->where('id',$archives['user_id'])->get('users')->row();
							} else {
							$user = $this->db->select('name')->where('id',$archives['customer_id'])->get('users')->row();
							}

							?>
							
                           <tr style="text-align: center;">
                                <th><?= $count++ ?>	</th>
                                <th>
                                    <?php    $src = base_url()."uploads/case_file/".$archives['name'];
                 	 

				$ext = pathinfo($archives['name'], PATHINFO_EXTENSION);
                 	if($ext == 'jpeg' || $ext == 'jpg' || $ext == 'png'){
                 	    $src = base_url()."uploads/case_file/".$archives['name'];
                 	   echo "<img src='".$src."' width='70'>"; 
                 	  
                 	}
                 	else if($ext == 'avi' || $ext == 'mp4' || $ext == 'flv' || $ext == 'mov' || $ext == 'wmv' || $ext == '3gp' ){
                 	    echo "<div class='datafiles'><i class='fa fa-video-camera 5x'></i></div>";
                 	}
                 	else if($ext == 'mp3' || $ext == 'wav' || $ext == 'ogg' || $ext == 'aac' || $ext == 'mpc' ){
                 	    echo "<div class='datafiles'><i class='fa fa-microphone 5x'></i></div>";
                 	} else {
                 	     echo "<div class='datafiles'><i class='fa fa-file 5x'></i></div>";
                 	}
?></a></th>
                                <th><?= $archives['name'] ?></th>
                                <th><?php echo $ext; ?></th>
                              
                                 <th>
                                <?php  $date= date("d/m/Y", strtotime($archives['created'])); echo getTheDayAndDateFromDatePanFront($date); ?>
                                </th>
                                <th><?= $user->name;?></th>
                                <th>
								<span style="overflow: visible; position: relative;">
									<a href="<?= $src ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill" title="<?php echo $this->lang->line('Download');?>">
										<i class="fa fa-download"></i>
									</a>
								</span>
                                </th>
                            </tr>
							<?php } ?>
                            

                            </tbody>
                        </table>

                    </div>


                </div>
        <!--End::Section-->
    </div>
</div>
</div>



<?php

include('footer.php');

?>
<script type="text/javascript">
$(document).ready(function() { 
    $('#m_table_11').DataTable({
    language: {
    paginate: {
      next: '<i class="fa fa-angle-left"></i>', // or '→'
      previous: '<i class="fa fa-angle-right"></i>', // or '←' 
      
    },
    <?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") {  ?>
    "sProcessing":   "جارٍ التحميل...",
    "sLengthMenu":   "أظهر _MENU_ ",
    "sZeroRecords":  "لم يعثر على أية سجلات",
    "sInfo":         "إظهار _START_ إلى _END_ من أصل _TOTAL_ مدخل",
    "sInfoEmpty":    "يعرض 0 إلى 0 من أصل 0 سجل",
    "sInfoFiltered": "(منتقاة من مجموع _MAX_ مُدخل)",
    "sInfoPostFix":  "",
    "sSearch":       "ابحث:",
    "sUrl":          "",
    <?php } else { ?>
        "sLengthMenu":   "Show  _MENU_ ",
    <?php  } ?>
  }
    });
} );
</script>