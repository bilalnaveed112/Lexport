<div class="col-md-3 sidebarmenu">
<ul class="sidebar-nav">
 <!--   <li class="nav-item"><a href="<?= base_url('front/dashboard'); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
                                          <li class="nav-item active"><a class="nav-link" href="<?= base_url('front/law_suite_view/?mode=edit'); ?>"><i class="fa fa-user"></i> E-Services <span class="sr-only">(current)</span></a></li>
                                        <li class="nav-item"><a href="<?= base_url('front/modify_case'); ?>"><i class="fa fa-user"></i> Profile</a></li>
                                      <li class="nav-item"><a href="<?= base_url('front/attach_files'); ?>"><i class="fa fa-files"></i> Attach File</a></li> 
                                        <li class="nav-item"><a href="<?= base_url('front/bank_transfer'); ?>"><i class="fa fa-money"></i> Wallet </a></li>
                                    <li class="nav-item"><a href="<?= base_url('front/case_list'); ?>"><i class="fa fa-gear"></i> E-Services</a></li> -->

<li class="nav-item"><a href="<?= base_url('home'); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
<li class="nav-item"><a href="<?= base_url('modify_case'); ?>"><i class="fa fa-user"></i> My Details</a></li>
<li class="nav-item"><a href="<?= base_url('case_list'); ?>"><i class="fa fa-file-text"></i> E-Services</a></li>
<li class="nav-item"><a href="<?= base_url('archive_list'); ?>"><i class="fa fa-file-text"></i> Archive</a></li>
<li class="nav-item"><a href="<?= base_url('list_session_appoinment'); ?>"><i class="fa fa-users"></i> Session</a></li>
<li class="nav-item"><a href="<?= base_url('list_writings_appoinment'); ?>"><i class="fa fa-pencil-square"></i> Writings</a></li>
<li class="nav-item"><a href="<?= base_url('list_consultation_appoinment'); ?>"><i class="fa fa-legal"></i> Consultation</a></li>
<li class="nav-item"><a href="<?= base_url('list_visiting_appoinment'); ?>"><i class="fa fa-vcard"></i> Visiting </a></li>
<li class="nav-item"><a href="<?= base_url('list_general_misssion'); ?>"><i class="fa fa-dropbox"></i> General </a></li>

<li class="nav-item"><a href="<?= base_url('alert'); ?>"><i class="fa fa-bell"></i> Notifications</a></li>
<li class="nav-item"><a href="<?= base_url('bank_transfer'); ?>"><i class="fa fa-money"></i> Wallet </a></li>
<li class="nav-item"><a href="<?php echo base_url('front/chat'); ?>"><i class="fa fa-envelope"></i> Chatting</a></li>

   
</ul>

</div>