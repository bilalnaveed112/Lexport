<!DOCTYPE html>
<html>
<head>
	<title>Thank You</title>
</head>
<body>
<center>
	<h1><b>Thank You</b></h1>
</center>
</body>
</html>