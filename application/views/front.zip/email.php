<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Albarakati Law</title>
<link href="https://fonts.googleapis.com/css?family=Dosis:300,400,500,700&display=swap" rel="stylesheet">
</head>
<body>
<table cellpadding="0" cellspacing="0" border="0" width="700" align="center" style="border:solid 1px #cccccc; font-family: 'Dosis', sans-serif, Arial;">
<tr><td height="20"></td></tr>
<tr>
<td align="center"><img src="https://albarakatilaw.com/assets/images/logo.png" alt="albarakatilaw" width="300" border="0" /></td>
</tr>
<tr><td height="20"></td></tr>

<?php if ($lan =='ar') { ?>

<?php if ($role_id == 3 && $sub == 'welmo') { ?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Welcome</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
 شريكنا العزيز,<br>
 شكرًا لتسجيلكم في برنامج &quot;نَصْر&quot;<br>
 ويُسعِدنا أن نقدم لكم طَيفًا من الخدمات القانونيَّة، والاستشارات الحُقوقيَّة المُتكامِلَة، ونَتَطَلَّعُ لإنجاز أعمالِكم
بمِهنيَّة وفاعليَّة. <br>
دخول يُرجَى إضاف: <b><?php echo $otp; ?></b>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>welcome.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    

<?php } ?>
<?php if ($role_id == 3 && $sub == 'otpmo') { ?>

   <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Password Reset Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner<br>
			To reset your password please enter the activation code:<br>
			 <b><?php echo $otp; ?></b><br>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>reset-password.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->

<?php } ?>

<?php if ($role_id == 3 && $sub == 'loginotp') { ?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Verification Code Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
 شريكنا العزيز,<br> 
 شريكنا العزيز: مرحبًا بك في برنامج نصر للدخول يُرجَى إضاف: <?php echo $otp; ?>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>otp.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
<?php } ?>
<?php } else { ?>

<?php if ($role_id == 3 && $sub == 'welmo') { ?>
  <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Welcome</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner,<br>
			Thank you for registering in "“Nassr”"<br>
			We are pleased to offer you an array of legal services and integrated legal consultations and looking forward to finalizing your work professionally and effectively.<br>
			Your activation coe is: <b><?php echo $otp; ?></b> 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>welcome.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    
<?php }?>


<?php if ($role_id == 3 && $sub == 'otpmo') { ?>
<tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Password Reset Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner<br>
			To reset your password please enter the activation code:<br>
			<b><?php echo $otp; ?></b><br>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>reset-password.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
<?php } ?>


<?php if ($role_id == 3 && $sub == 'loginotp') { ?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Verification Code Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner,<br>
			Welcome to “Nassr” program.<br>
			Please enter your activation code: <?php echo $otp; ?>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>otp.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    

<?php } ?>


<?php } ?>

<?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") { ?>

<?php if ($role_id == 3 && $sub == 'new') { ?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Welcome</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
 شريكنا العزيز,<br>
 شكرًا لتسجيلكم في برنامج &quot;نَصْر&quot;<br>
 ويُسعِدنا أن نقدم لكم طَيفًا من الخدمات القانونيَّة، والاستشارات الحُقوقيَّة المُتكامِلَة، ونَتَطَلَّعُ لإنجاز أعمالِكم
بمِهنيَّة وفاعليَّة. 
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>welcome.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    

<?php } ?>


<?php if ($role_id == 3 && $sub == 'otp') { ?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Verification Code Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
 شريكنا العزيز,<br> 
 شريكنا العزيز: مرحبًا بك في برنامج نصر للدخول يُرجَى إضاف: <?php echo $otp; ?>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>otp.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    

<?php } ?>


<?php if ($role_id == 3 && $sub == 'forgot') { ?>

   <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Forgot Password</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner,<br>
			You recently requested a forgot password. We've received the request and your password has been changed.<br>
			Your new password is:<b><?php echo $password; ?></b><br>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>welcome.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->

<?php } ?>
<?php if ($role_id == 3 && $sub == 'change') {?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Change Password</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
        Dear Partner,<br />
        Recently requested a change password. We've received the request and your password has been changed.<br>
		Your new password is :<b><?php echo $password; ?></b>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>reset-password.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    
<?php } ?>
<?php } else { ?>


<?php if ($role_id == 3 && $sub == 'otp') { ?>
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Verification Code Message</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner,<br>
			Welcome to “Nassr” program.<br>
			Please enter your activation code: <?php echo $otp; ?>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>otp.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    

<?php } ?>



<?php if ($role_id == 3 && $sub == 'new') { ?>
  <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Welcome</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner,<br>
			Thank you for registering in "“Nassr”"<br>
			We are pleased to offer you an array of legal services and integrated legal consultations and looking forward to finalizing your work professionally and effectively.<br>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>welcome.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    
<?php }?>

<?php if ($role_id == 3 && $sub == 'forgot') { ?>
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Forgot Password</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
			Dear Partner,<br>
			You recently requested a forgot password. We've received the request and your password has been changed.<br>
			Your new password is:<b><?php echo $password; ?></b><br>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>welcome.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->

<?php } ?>
<?php if ($role_id == 3 && $sub == 'change') {?>

  
    <!-- Email Body -->
    <tr>
    	<td style="color:#c8a458; font-size:32px;" align="center">Change Password</td>
    </tr>
    <tr>
    	<td style="color:#7a7b7e; font-size:18px; padding:20px 100px 20px 100px; line-height:28px;" align="center">
        Dear Partner,<br />
        Recently requested a change password. We've received the request and your password has been changed.<br>
		Your new password is :<b><?php echo $password; ?></b>
		</td>
    </tr>
    <tr>
        <td align="center"><img src="<?php echo base_url('assets/images/email/');?>reset-password.jpg" alt="albarakatilaw" border="0" /></td>
    </tr>
    
    <!-- End Email Body -->
    
 
<?php }?>
<?php } ?>

    <!-- Footer -->
    
	<tr><td height="20"></td></tr>
    <tr>
    	<td align="center" style="background:#102b4e;">
        	<table cellpadding="0" cellspacing="0" border="0" width="700" align="center" style="background:#102b4e;">
				<tr><td height="20"></td></tr>
            	<tr>
                	<td align="center"><img src="<?php echo base_url('assets/images/email/');?>start-service.jpg" alt="albarakatilaw" border="0" /></td>
                </tr>
                <tr><td height="10"></td></tr>
                <tr>
                    <td style="color:#c8a458; font-size:28px;" align="center">START OUR SERVICES</td>
                </tr>
                <tr><td height="40"></td></tr>
                <tr>
                    <td style="color:#c8a458; font-size:22px;" align="center">Questions? Call</td>
                </tr>
                <tr><td height="10"></td></tr>
                <tr>
                    <td style="color:#ffffff; font-size:20px;" align="center">Tel. 920002916 Riyad . Jeddah . Makkah</td>
                </tr>
                <tr><td height="40"></td></tr>
                <tr>
                    <td style="color:#c8a458; font-size:22px;" align="center">Connect With Us</td>
                </tr>
                <tr><td height="10"></td></tr>
                <tr>
                    <td style="color:#ffffff; font-size:20px;" align="center" valign="middle"><a href="https://www.facebook.com/Albarakatilaw/"><img src="<?php echo base_url('assets/images/email/');?>fb.jpg" alt="albarakatilaw" border="0" style="vertical-align:middle;" /></a> <a href="https://twitter.com/albarakatilaw?lang=ar"><img src="<?php echo base_url('assets/images/email/');?>twitter.jpg" alt="albarakatilaw" border="0" style="vertical-align:middle;" /></a> <a href="https://ae.linkedin.com/company/nassr-albarakati-law-firm"><img src="<?php echo base_url('assets/images/email/');?>linkedin.jpg" alt="albarakatilaw" border="0" style="vertical-align:middle;" /></a> <span style="vertical-align:middle;">ALBARAKATILAW</span></td>
                </tr>
                <tr><td height="40"></td></tr>
            </table>
        </td>
    </tr>
    <tr>
    	<td align="center">
        	<table cellpadding="0" cellspacing="0" border="0" width="700" align="center" style="padding:15px 0px 15px 0px; font-size:13px;">
            	<tr>
                	<td width="233" align="center"><a href="#" style="text-decoration:none; color:#7a7b7e;">Was this tutorial useful?</a></td>
                	<td width="233" align="center"><a href="https://albarakatilaw.com/" style="text-decoration:none; color:#7a7b7e;">www.albarakatilaw.com</a></td>
                	<td width="233" align="center"><a href="#" style="text-decoration:none; color:#7a7b7e;">You can unsubscribe</a></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body> 
</html>