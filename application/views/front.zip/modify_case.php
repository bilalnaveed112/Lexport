<?php $nvc = "white-nav sticky shrink modern hover4 radius-drop"; 
$pageTitle = $this->lang->line("Edit_Profile");
include('header.php');
?>
 </section>
<?php
include('header_welcome.php');
?>
<!-- END: Left Aside -->
<div class="m-grid__item m-grid__item--fluid m-wrapper">


        <!-- END: Subheader -->
        <div class="m-content">
            <div class="row">
                <div class="col-xl-3 col-lg-4">
                    <div class="m-portlet m-portlet--full-height  ">
                        <div class="m-portlet__body">
                            <div class="m-card-profile">
                                <div class="m-card-profile__title m--hide">
                                   <?php echo $this->lang->line("Your_Profile"); ?>
                                </div>
                                <div class="m-card-profile__pic">
                                    <div class="m-card-profile__pic-wrapper"> 
                                         <img src="<?php if($idtype['image']) { echo base_url("uploads/profile/".$idtype['image']); } else { echo base_url("uploads/profile/defualt_profile.png"); }?>"   alt=""/>
                                               
                                    </div>
                                </div>
                                <div class="m-card-profile__details">
                                    <span class="m-card-profile__name"><?php echo $request['name']; ?></span>
                                    <a href="" class="m-card-profile__email m-link" style="word-break: break-word;"><?php echo $request['email']; ?></a>
                                </div>
                            </div>
                           
<ul class="nav  mb-3 m-nav m-nav--hover-bg m-portlet-fit--sides" id="pills-tab" role="tablist">
 <li class="m-nav__separator m-nav__separator--fit"></li>
<li class="m-nav__section m--hide">
	<span class="m-nav__section-text"><?php echo $this->lang->line("Section"); ?></span>
</li>
  <li class="m-nav__item">
    <a class="active m-nav__link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true"> <i class="m-nav__link-icon flaticon-profile-1"></i>
		<span class="m-nav__link-title">
			<span class="m-nav__link-wrap">
				<span class="m-nav__link-text"> <?php echo $this->lang->line("Profile"); ?> </span>

			</span>
		</span>
	</a>
  </li> 
 <style>
 .m-nav.m-nav--hover-bg .m-nav__item > .m-nav__link {
    padding: 12px 25px;
}
a.m-nav__link.nav-link.active.show {
    background: #e6e6e6;
}
 </style>
  <li class="m-nav__item">
    <a class="m-nav__link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false"><i class="m-nav__link-icon fa fa-phone"></i><span class="m-nav__link-title">
			<span class="m-nav__link-wrap">
				<span class="m-nav__link-text"> <?php echo $this->lang->line("Update_Contact"); ?> </span>

			</span>
		</span>
		</a>
  </li>
  <li class="m-nav__item">
    <a class="m-nav__link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false"><i class="m-nav__link-icon fa fa-star"></i><span class="m-nav__link-title">
			<span class="m-nav__link-wrap">
				<span class="m-nav__link-text"><?php echo $this->lang->line("Update_Password"); ?></span>

			</span>
		</span></a>
  </li>
</ul>	
                            <div class="m-portlet__body-separator"></div>

                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-8">
                    <div class="m-portlet m-portlet--full-height m-portlet--tabs  ">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo $this->lang->line("My_Profile"); ?>
                                    </h3>
                                </div>
                            </div>

                        </div>
         
						<div class="tab-content" id="pills-tabContent">
                        <?php   if($_GET['updateprofile']){
                         echo ' <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show danger">Update your profile for add new E-service</div>';
                        } ?>
                            <?php   if($_GET['success']){
                         echo ' <div class="sufee-alert alert with-close alert-success alert-dismissible fade show success">Profile update successfully</div>';
                        } ?>
						  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab"> 
						<?php 
									echo form_open_multipart('front/modify_case', ['class' => 'm-form m-form--fit m-form--label-align-right front-text updateprofile']); 
									if(isset($_GET['mode'])){$mod = $_GET['mode']; } else { $mod =''; }
									if($mod == 'edit'){ 
									echo form_hidden('mode','edit');  $readonly = '';
									} else {
									$readonly = 'readonly';
									}
									?>
									<div class="m-portlet__body">
                                        <div class="form-group m-form__group m--margin-top-10 m--hide">
                                            <div class="alert m-alert m-alert--default" role="alert">
                                                <?php echo $this->lang->line("Some_sample_alert_message"); ?>
                                            </div>
                                        </div>        <?php  $value = set_value('name', $request['name']); ?>

                                        <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("Full_name"); ?></label>
                                            <div class="col-7">
                                           		<?php echo form_input(['name' => 'name', 'class' => 'form-control m-input', 'value' =>$value,$readonly=>'']); ?>
                                            </div>
                                        </div>
                                        	<?php  $value = set_value('id_numbers', $request['id_numbers']); if($request['id_numbers'] != ''){ 	$disabled  = 'disabled '; }?>
	                                <?php  $value = set_value('email', $request['email']); ?>
                                           <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("Email"); ?></label>
                                            <div class="col-7">
                                                <?php echo form_input(['name' => 'email', 'class' => 'form-control m-input', 'value' =>  $value]); ?>
                                            </div>
                                        </div>

                                        <div class="form-group m-form__group row">
                                            <label for="exampleSelect1" class="col-2 col-form-label"><?php echo $this->lang->line("ID_type"); ?></label>
                                            <div class="col-7">
                                                <?php  $value1 = set_value('id_type', $request['id_type']); ?>
                                                <select name="id_type" id="identification_types" class="form-control m-input" style="" required="" <?php echo $disabled; ?>>
                                                    <option value="CR" <?php if($value1 == "CR") echo "selected"; ?>><?php echo $this->lang->line("CR"); ?></option>
                                                    <option value="National Id" <?php if($value1 == "National Id") echo "selected"; ?>><?php echo $this->lang->line("National_ID"); ?></option>
                                                    <option value="Aqama" <?php if($value1 == "Aqama") echo "selected"; ?>><?php echo $this->lang->line("Aqama"); ?></option>
                                                    <option value="Other" <?php if($value1 == "Other") echo "selected"; ?>><?php echo $this->lang->line("Other"); ?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("ID_Number"); ?></label>
                                            <div class="col-7">
                                                     <?php  $value = set_value('id_numbers', $request['id_numbers']); ?>
                                               <?php echo form_input(['name' => 'id_numbers', 'class' => 'form-control m-input', 'value' => $value,$disabled=>'']); ?>
                                            	  		<div class="form-error"><?= form_error('id_numbers'); ?></div>
                                            </div>
                                        </div>
	<?php  $value = set_value('phone', $request['phone']); ?>
                                          <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("Contact_Number"); ?></label>
                                            <div class="col-7">
                                                 <?php echo form_input(['name' => 'phone', 'class' => 'phones form-control m-input', 'value' => $value,$readonly=>'']); ?>
                                            </div>
                                        </div>

	<?php  $value = set_value('city', $request['city']); ?>
                                        <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("City"); ?></label>
                                            <div class="col-7">
                                                <?php echo form_input(['name' => 'city', 'class' => 'form-control m-input', 'value' =>$value,$readonly=>'']); ?>
                                            </div>
                                        </div>
                                        	<?php  $value = set_value('district', $request['district']); ?>
                                        <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("district"); ?></label>
                                            <div class="col-7">
                                               <?php echo form_input(['name' => 'district', 'class' => 'form-control', 'value' => $value ]); ?>
                                            </div>
                                        </div>
                                        	<?php  $value = set_value('address', $request['address']); ?>
                                        <div class="form-group m-form__group row">
                                            <label for="example-text-input" class="col-2 col-form-label"><?php echo $this->lang->line("Address"); ?></label>
                                            <div class="col-7">
                                                <textarea name="address" class="form-control m-input" id="exampleTextarea" rows="3"><?php echo $value;?></textarea>
                                            </div>
                                        </div>
                                     

                                    </div>
                                    <div class="m-portlet__foot m-portlet__foot--fit">
                                        <div class="m-form__actions">
                                            <div class="row">
                                                <div class="col-2">
                                                </div>
                                                <div class="col-7">
                                                    <button type="submit" class="btn btn-accent m-btn m-btn--air m-btn--custom"><?php echo $this->lang->line("Save_changes"); ?></button>&nbsp;&nbsp;
                                                    <a href="<?php echo base_url('dashboard');?>"  class="btn btn-secondary m-btn m-btn--air m-btn--custom"><?php echo $this->lang->line("Cancel"); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
		</div>
		<div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
			<div class="m-portlet__body">
					 <h3 class="m-portlet__head-text"><?php echo $this->lang->line("Update_Mobile_Number"); ?> </h3>    
					 <div class="m-portlet__body-separator"></div>
					 	<div class="erorrphone"></div>
					<?php echo form_open('front/change_mobile', ['class' => 'updatemobile front-text']); ?>
					<div class="form-group">
						<?php echo form_input(['name' => 'update_no','id'=>'update_no','value'=>$request['phone'],'class' => 'form-control m-input']); ?>
					</div>
			<div class="form-group col-sm-4">
			   <div class="next-btn">     
					 <a href="javascript:;" class="btn btn-accent m-btn m-btn--air m-btn--custom" id="clicktoupdate"><?php echo $this->lang->line("Update"); ?></a>
			  </div> 
			</form>
			</div>
			</div>
		</div>
		<div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
			<div class="m-portlet__body">
				<div class="erorr"></div>
				<h3><?php echo $this->lang->line("CHANGE_PASSWORD"); ?></h3>    <div class="m-portlet__body-separator"></div>
				<?php echo form_open('front/change_password', ['id'=>'change_pass','class' => 'm-form m-form--fit m-form--label-align-right front-text']); ?>
				<div class="form-group">
					<?php echo form_password(['name' => 'current_password', 'placeholder' => $this->lang->line('Current_Passsword'), 'class' => 'form-control','required'=>'required']);?> 
					<span style="color:red"> <?php echo form_error('current_password'); ?></span>
					<span style="color:red"> <?php echo isset($_GET['pwd'])?"Incorect Password":''; ?></span>
				</div>
				<div class="form-group">
					<?php echo form_password(['name' => 'new_password','id' => 'new_password', 'placeholder' => $this->lang->line('New_Passsword'), 'class' => 'form-control','required'=>'required']);?> 
					<span style="color:red"> <?php echo form_error('new_password'); ?></span>
					<span style="color:red" id="errPass"></span>
				</div>
					<div class="form-group ">
					<?php echo form_password(['name' => 'confirm_password','id' => 'confirm_password', 'placeholder' => $this->lang->line('Confirm_Passsword'), 'class' => 'form-control','required'=>'required']); ?> 
					<span id ="cpass" style="color:red"><?php echo form_error('confirm_password'); ?></span>
						</div>
					<div class="form-group col-md-3">
				   <div class="next-btn">     
						<?php echo form_submit(['name' => 'submit', 'value' => $this->lang->line('Change'), 'class' => 'btn btn-primary btn-lg']); ?>
				  </div>   
				  </form>
				</div>
			</div>
        </div>
    </div>
</div>
	<div class="modal fade otppopup" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
      
        <div class="modal-body">
          <div class="loginBox ">
		  <h2 align="center"><?php echo $this->lang->line("Enter_OTP"); ?></h2>
<?php echo form_open('front/otp_verify',['class' => 'otpformmu','id'=>'']); ?>
<div class="col-sm-12">
<div class="input-group">
<p> <?php echo $this->lang->line("Enter_OTP_Detail"); ?><span class="otpmo"></span>
<label> <?php echo $this->lang->line("Enter_OTP"); ?> <span class="otpgetm"></span></label>
<?php echo form_input(['name' => 'getotp', 'class' => 'otpsendm form-control']); ?>
<span style="color:red" class="otperrorm"></span>
</div>
 <div class="input-group"  style="text-align:center;    display: block; margin-top:10px;" >
 <a href="javascript:;"class="btn btn-primary btn-lg" id="getmootp"><?php echo $this->lang->line("Submit"); ?></a>
</div>

</div>
<div class="clear"></div>

	</div>
</div>
	
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<?php

include('footer.php');

?>
<script>
 
jQuery('#change_pass').on('submit', function (e) {
e.preventDefault();  
var password = jQuery("#new_password").val();
 var expr = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;

    if (!expr.test(password)) { 
        $('#errPass').text('Enter alphabet, number, special character and Not Less then 6 and more then 8');
		return false;  
    }
    else {  
        $('#errPass').hide();
    }
 
 var  confirm_password= $('#confirm_password').val();

	if(confirm_password != password ){
		$("#cpass").html('Password Not Match');   return false;
	} else { $("#cpass").html(''); }
 
var formData = new FormData(this);
var url="<?= base_url('front/change_password'); ?>"; 

jQuery.ajax({
url:url,
type: 'POST',
data: formData,
success:function(data){
if(data == 'failed'){

	$('.erorr').html('<div class="alert alert-danger">Password Does Not Match</div>');
	
} else {
 	$('.erorr').html('<div class="alert alert-success">Password Updated Successfully</div>');
} 
},
cache: false,
contentType: false,
processData: false
});
});

jQuery('#clicktoupdate').on('click', function (e) {
var phone = $('#update_no').val();

$(".otpmo").html(phone);
var url="<?= base_url('front/update_otp_verify'); ?>"; 
jQuery.ajax({
type:'ajax',
method:'post',
url:url,
data: {'phone':phone},
success:function(data){ //alert(data);
var JSONObject = JSON.parse(data);
$(".otpgetm").html(JSONObject.otp);
var otpsend = $('.otpsendm').val();
$('#myModal2').modal('show');
},
});
});

$('#getmootp').on('click', function (e) {
e.preventDefault();
var getotp = $('.otpsendm').val();
var url="<?= base_url('front/check_otp_verify'); ?>"; 
jQuery.ajax({
type:'ajax',
method:'post',
url:url,
data: {'getotp':getotp},
success:function(data){ //alert(data);
if(data == 'true'){
$(".updatemobile").submit();
$('.erorrphone').html('<div class="alert alert-success">Mobile Number Updated Successfully</div>');
} else {
	$(".otperrorm").html("OTP Not Match");
}

},
});
});
</script>