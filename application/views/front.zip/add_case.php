<?php $nvc = "white-nav sticky shrink modern hover4 radius-drop"; 
if($data){ $pageTitle = "Edit E-Service";	} else { $pageTitle = "Add E-Service"; } 
include('header.php');
?>
<?php 
$user_id = $this->session->userdata('user_id');
$idtype = $this->db->select('*')->where("(id=$user_id)", NULL, FALSE)->get('users')->row_array();
if($idtype['id_type'] =='' OR  $idtype['id_numbers']==""){ 
    //redirect("modify_case?updateprofile=true"); 
}
?>
 </section>
<?php
include('header_welcome.php');
?>
<!-- END: Left Aside -->

    <div class="m-grid__item m-grid__item--fluid m-wrapper">

        <!-- END: Subheader -->
        <div class="m-content">

            <!--begin::Portlet-->
            <div class="m-portlet">
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <h3 class="m-portlet__head-text">
                            <?php   if($data){ echo $this->lang->line("Update_E_Service");	} else { echo $this->lang->line("Create_New_E_Service"); } ?>
                            </h3>
                        </div>
                    </div>
                </div>
  <style>
        .m-form.m-form--group-seperator-dashed .m-form__group {
            border-bottom: 0px dashed #ebedf2;
        }
        .thh h3{
            background: #1F3958;
            color: #fff;
            font-weight: bold;
            font-size: 15px;
            text-transform: uppercase;
            padding: 10px 10px 10px 29px;
            -webkit-border-top-left-radius: 20px !important;
            -webkit-border-top-right-radius: 20px !important;
            -moz-border-radius-topleft: 20px !important;
            -moz-border-radius-topright: 20px !important;
            border-top-left-radius: 20px !important;
            border-top-right-radius: 20px !important;
            margin: 15px 15px 0 15px;
        }
        .in_fo{
            box-shadow: 0px 5px 10px 0px #cccccc !important;
            margin: 0 15px;
            padding-bottom: 20px;
            -webkit-border-bottom-right-radius: 20px;
            -webkit-border-bottom-left-radius: 20px;
            -moz-border-radius-bottomright: 20px;
            -moz-border-radius-bottomleft: 20px;
            border-bottom-right-radius: 20px;
            border-bottom-left-radius: 20px;
        }
        .m-form.m-form--group-seperator-dashed .m-form__group {
            border-bottom: 0px dashed #ebedf2;
            padding-bottom: 0;
            padding-top: 10px;
        }
        .m-portlet .m-form.m-form--fit > .m-portlet__body {
            padding-bottom: 40px !important;
        }
        .nav {
            display: -webkit-box;
        }
        .m-portlet {
            margin-bottom: 0;
        }
        .m-widget4 .m-widget4__item .m-widget4__info {
            width: 97.2%;
        }
		.m-body .m-content {
    padding: 29px 45px;
}
    </style>	<style>
		div#armanage ul.nav.nav-tabs li {
    padding: 10px;
    border: 1px solid #e2e1e1;
    border-bottom: 0px;
    width: 130px;
    text-align: center;
}

		.button{
		display: inline-block;
		vertical-align: middle;
		margin: 0px 5px;
		padding: 5px 12px;
		cursor: pointer;
		outline: none;
		font-size: 13px;
		text-decoration: none !important;
		text-align: center;
		color:#fff;
		background-color: #4D90FE;
		background-image: linear-gradient(top,#4D90FE, #4787ED);
		background-image: -ms-linear-gradient(top,#4D90FE, #4787ED);
		background-image: -o-linear-gradient(top,#4D90FE, #4787ED);
		background-image: linear-gradient(top,#4D90FE, #4787ED);
		border: 1px solid #4787ED;
		box-shadow: 0 1px 3px #BFBFBF;
		}
		a.button{
		color: #fff;
		}
		.button:hover{
		box-shadow: inset 0px 1px 1px #8C8C8C;
		}
		.button.disabled{
		box-shadow:none;
		opacity:0.7;
		}
		canvas{
		display: block;
		}
		
.form-control:disabled, .form-control[readonly] {
    background-color: #f1f1f1;
    opacity: 1;
}
.att-docs {
    height: 100px;
}
.datafiles .fa {
    font-size: 80px;
}
.col-md-2.att-doc {
    text-align: center;
}


.ajax-file-upload-container {
    float: left !important;
}
div#image {
    float: left !important;
}
.ajax-upload-dragdrop {
    height: 300px !important;
    padding-top: 200px !important;
    text-align: center !important;
}
 
.ajax-file-upload-container {
    border: 1px solid rgba(66, 31, 35, 0.47);
    margin-left: 15px !important;
    margin-top: 0 !important;
    height: 300px !important;
    width: 44%;
}
.drage-file {
    margin-top: -85px;
    color: #524a4a !important;
    font-size: 20px !important;
}
.ajax-file-upload-statusbar {
    border: 0 !important;
}
.ajax-file-upload-bar {
    background-color: #546eb2 !important;
}
.ajax-file-upload-progress {

    width: 375px !important;
}
.ajax-file-upload-container {
    overflow-y: scroll;
}
.ajax-file-upload-container:before {
    content: "<?php echo $this->lang->line('Upload_Area');?>";
    background: #1f3958;
    text-align: left;
    color: #fff;
    position: absolute;
    width: 42.6%;
    padding: 10px;
    margin-top: 0px !important;
    font-size: 16px;
}
.ajax-file-upload-statusbar:first-child {
    margin-top: 50px;
}
.next-btn {
    clear: both;
    float: right;
}
.next-btn .btn {
    margin-bottom: 25px;
    padding: 12px 50px;
    border-radius: 2px;
}
.ajax-file-upload {
    padding: 20px !important;
    line-height: 0 !important;
}
.casedata-block {
    overflow: hidden;
    background: rgba(234, 234, 234, 0.7019607843137254);
    padding: 20px;
    margin-top: 30px;
    border-top: 5px solid #546eb2;
    margin-bottom: 30px;
}
.right-panel .breadcrumbs {
    display: flex !important;
    margin-bottom: 15px;
}
.docloopa {
    padding: 13px 0;
    margin: 0;
    border-bottom: 1px solid #b1acac;
}
.docloopa .btn {
    float: right;
    margin: 3px;
    margin-bottom: 0;
    padding: 1px 10px;
}span.empnm {
    color: #5cb85c;
    margin-left: 5px;    font-size: 12px;
}
.clear {
    clear: both;
}.page-loader.bg-white { display: none; }.docloopa {
    height: 70px;width:100%;
}

span.dwndelbtn {
 
}
</style>
                <!--begin::Form--><?php 
		// echo '<pre>';
		// print_r($data);exit;
			
		echo form_open_multipart('front/store_case',['id'=>'customer',"class"=>"m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed"]);
		if($data)
			{
				 $readonly = 'readonly';
				 echo form_hidden('id',$data->id); 
                     $doc_id = $data->doc_id; 
                //echo form_hidden('is_reject',$data->is_reject); 
			}
			else
			{
				$readonly ='';
				echo form_hidden('id',''); 
				$doc_id = "DI".rand();
				echo form_hidden('doc_id',$doc_id); 
			}
			$case_id = isset($data->case_id) ? $data->case_id  :'';
			$case_id1 = isset($data->case_id) ? $data->case_id  :'0';
			echo form_hidden('case_id',$case_id); 
			
		// echo '<pre>'; print_r($data);exit;
		?>

                    <div class="m-portlet__body">

                        <div class="form-group m-form__group row">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Customer_Information');?><br>&nbsp;</h3>
                            </div>
								<div class="form-group col-lg-6">
		  		<label for="identification_number" class=" form-control-label"><?php echo $this->lang->line('ID');?></label>
		  		<?php if($data)
				{
					$value=$data->identification_number;
				}
				else
				{
					$value=set_value('identification_number');
				} 
				$value = $user['id_numbers'];

				?>
		  		<?= form_input(['name'=>'identification_number','class'=>'form-control m-input','value'=>$value,'readonly'=>'readonly']);?>
		  		<div class="form-error"><?= form_error('identification_number'); ?></div>
		  	</div>

		  	<div class="form-group col-lg-6">
		  		<label for="identification_types" class="form-control-label"><?php echo $this->lang->line('identification_types');?></label>
				<?php echo form_input(['name'=>'identification_types','value'=>$user['id_type'],'id'=>'identification_types','class'=>'form-control m-input','readonly'=>'readonly']); ?>
				
		  	</div>

		  	<div class="form-group col-lg-6">
		  		<label for="client_file_number" class="form-control-label"><?php echo $this->lang->line('client_File_number');?></label>
		  		<?php 
				$dbValue = $this->session->userdata('user_id'); 
				$ccn =  $dbValue = "CU".str_pad($dbValue, 6, "0", STR_PAD_LEFT); 
				if($data)
				{
					$value2=$data->client_file_number;
				}
				else
				{
					$value2=set_value('client_file_number',$ccn);
				} 
				//$value2 = "CU".$this->session->userdata('user_id');
				 
				?>
		  		<?= form_input(['name'=>'client_file_number','class'=>'form-control m-input','value'=>$value2,'readonly'=>'readonly']);?>
		  		<div class="form-error"><?= form_error('client_file_number'); ?></div>
		  	</div>

		  	<div class="form-group col-lg-6">
				<label for="client_name" class=" form-control-label"><?php echo $this->lang->line('client_full_name');?></label>
				<?php if($data)
				{
					$value=$data->client_name;
				}
				else
				{
					$value=set_value('client_name');
				} 
				$value = $user['name'];
				?>
				<?= form_input(['name'=>'client_name','class'=>'form-control m-input','value'=>$value,'readonly'=>'readonly']);?>
				<div class="form-error"><?= form_error('client_name'); ?></div>
			</div>
		</div>

	  <div class="form-group m-form__group row">
	
			<div class="col-lg-12">
				<h3><?php echo $this->lang->line('E-Service_Information');?></h3>
			</div>
				<div class="form-group col-lg-6">
			  		<label for="branch" class=" form-control-label"><?php echo $this->lang->line('branch');?></label>
			  		<?php if($data)
					{
						$value=$data->branch;
					}
					else
					{
						$value=set_value('branch');
					} ?>
					<select name="branch" id="branch" class="form-control" required>
					<option value=""><?php echo $this->lang->line('Please_select_branch');?></option>
					<?php foreach(branch() as $branch) { ?>
					<option value="<?= $branch['id']; ?>"<?php if($value==$branch['id']) echo "selected=selected";?>><?= $branch['name']; ?></option>
					<?php } ?></select>
			  		<div class="form-error"><?= form_error('branch'); ?></div>
			  	</div>


				<div class="form-group col-lg-6">
			  		<label for="service_types" class="form-control-label"><?php echo $this->lang->line('Please_Select_E_Service_Name');?></label>
			  		<select name="service_types" id="service_types" class="form-control" required <?php if($data){?>readonly <?php } ?>>
			  			<option value=""><?php echo $this->lang->line('Please_select_Service_Type');?></option>
			  			<?php foreach($service as $service) { 
			  				if($data) { ?>
			  					<option value="<?= $service['id']; ?>"<?php if($data->service_types==$service['id']) echo "selected=selected";?>><?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") { echo $service['name']; }else{ echo $service['name_en']; } ?></option>
			  				<?php } else { ?>
			  					<option value="<?= $service['id']; ?>"><?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") { echo $service['name']; }else{ echo $service['name_en']; } ?></option>
			  				<?php } ?>	
			  			<?php } ?>
			  		 	
					</select>
			  	</div>

			   

				<div class="form-group col-lg-6">
					<label for="case_type" class=" form-control-label"><?php echo $this->lang->line('E_Service_Type');?></label>
					<?php if($data)
					{
						$value=$data->case_type;
					}
					else
					{
						$value=set_value('case_type');
					} ?>
					<select name="case_type" id="case_type" class="form-control"  >
						<?php foreach($case_type as $case_type) { 
						if($value==$case_type['id']) { ?>
								<option value="<?= $case_type['id']; ?>"<?php  echo "selected=selected";?>><?= $case_type['name']; ?></option>
						<?php } } ?>
					</select>
					<div class="form-error"><?= form_error('case_type'); ?></div>
				</div>

				<div class="form-group col-lg-6">
					<label for="case_number" class=" form-control-label"><?php echo $this->lang->line('E_Service_Number');?></label>
					<?php 
					$cnomain = getCaseNumber(0);
					if($data)
					{
						$value=$data->case_number;
					}
					else
					{
						$value=set_value('case_number',$cnomain );
					} 
					
					?>
					<?= form_input(['name'=>'case_number','class'=>'form-control m-input','value'=>$value,'readonly'=>'readonly']);?>
					<div class="form-error"><?= form_error('case_number'); ?></div>
				</div>
 

				<div class="form-group col-lg-6">
					<label for="case_date" class=" form-control-label"><?php echo $this->lang->line('E_Service_Date');?></label>
					<?php if($data)
					{
						$value=$data->case_date;
					}
					else
					{
						$value=set_value('case_date',date('d/m/Y'));
					} 
                            echo form_hidden('case_date',$value);
                            $parts = explode('/', $value);
                         	if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") { 
                                $value = Greg2Hijri($parts[0], $parts[1], $parts[2],true);
                            }
                         
					?>
					<?= form_input(['id'=>'','readonly'=>'readonly','class'=>'form-control date','value'=>$value,$readonly=>'']);?>
					<div class="form-error"><?= form_error('case_date'); ?></div>
				</div>

				<div class="form-group col-lg-6">
					<label for="case_start_date" class=" form-control-label"><?php echo $this->lang->line('E_Service_Start_Date');?></label>
					<?php if($data)
					{
						$value=$data->case_start_date;
					}
					else
					{
						$value=set_value('case_start_date');
					} ?>
					<?= form_input(['name'=>'case_start_date','class'=>'form-control date','id'=>'case_start_date','readonly'=>'readonly','value'=>$value,$readonly=>'']);?>
					<div class="form-error"><?= form_error('case_start_date'); ?></div>
				</div>

				<div class="form-group col-lg-6">
					<label for="contact_number" class=" form-control-label"><?php echo $this->lang->line('Contract_number');?></label>
					<?php if($data)
					{
						$value=$data->contract_number;
					}
					else
					{
						$value=set_value('contract_number',"C".$cnomain);
					} ?>
					<?= form_input(['name'=>'contract_number','class'=>'form-control m-input','value'=>$value,'readonly'=>'readonly']);?>
					<div class="form-error"><?= form_error('contract_number'); ?></div>
				</div>
			</div>
	
	  <div class="form-group m-form__group row">
	
			<div class="col-lg-12">
				<h3><?php echo $this->lang->line('Requirement');?></h3>
			</div>
	  <div class="card-body card-block">
			<?php if($data)
			{
				$value=$data->note;
			}
			else
			{
				$value=set_value('note');
			} ?>
			<?= form_textarea(['name'=>'note','class'=>'form-control m-input', 'rows'=> '3','value'=>$value]);?>
			<div class="form-error"><?= form_error('note'); ?></div>
	  </div>
      
</div>
<br>

				<div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('File_List');?></h3>
                            </div>
                        </div> <div class="in_fo">
                            <div class="form-group m-form__group row"><div   id="armanage" style=" width: 100%; ">	
	<div class="form-group col-sm-12">
		<ul class="nav nav-tabs">
    <li ><a data-toggle="tab" href="#menu1" class="active show"> <?php echo $this->lang->line('Documentation');?></a></li>
    <li><a data-toggle="tab" href="#menu2"><?php echo $this->lang->line('Data');?></a></li>
   	<?php if($data) { ?>    <li><a data-toggle="tab" href="#menu3"><?php echo $this->lang->line('Report');?></a></li>
   <!-- <li><a data-toggle="tab" href="#menu4">Tuning</a></li>-->
 <li><a data-toggle="tab" href="#menu5"><?php echo $this->lang->line('Contract');?></a></li>
	<li><a data-toggle="tab" href="#menu6"><?php echo $this->lang->line('Referrals');?></a></li>
    <li><a data-toggle="tab" href="#menu7"><?php echo $this->lang->line('Procuation');?></a></li> <?php } ?>
  </ul>

  <div class="tab-content">
    <div id="menu1" class="tab-pane fade in active show">

<div class="attced-block case-block">
<div class="upload-block">
	<div id="image"></div> <div class="upload-area"></div><div class="clear"></div>
</div>
</div>
<div class="clear"></div>
<div class="row">
		<div class="form-group col-sm-12">
			<div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Attached_files');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
				<?php 
					$case_id_add = $this->db->select_max('id')
						->get('c_case')
						->row_array();
					$case_id_add = $case_id_add['id'] + 1;
					$cisd = isset($data->id) ? $data->id  : $case_id_add;
					$files = $this->db->select('*')->where("(temp_app_id = '$doc_id'  AND cat_id = 1)", NULL, FALSE)->get('document')->result_array();
					foreach ($files as $files) { ?>
					<div class="docloopa">
						<?php	
						$emp=$this->db->select('*')->where('id',$files['user_id'])->get('users')->row_array();
						
			
						echo "<b>" . $files['name']."</b>";if($emp){ echo "<span class='empnm'>(Upoded By ".$emp['name'].")</span>";} ?>
						<span class="dwndelbtn">
			<a href="<?=base_url('uploads/case_file/' . $files["name"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
			<!--<a href="<?=base_url('front/delete_upload_files/' . $files["name"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span></div>
			<?php }?>
			</div>
		</div>
		
</div>
</div>
 
 
 
	

    </div>
    <div id="menu2" class="tab-pane fade">
<br>
     <div class="">
<div class="upload-block">
	<div id="data" style=" float: left !important; "></div> <div class="upload-area"></div>
</div>
</div>
<div class="clear"></div>

<div class="row">
		<div class="form-group col-sm-12">
		 <div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Attached_files');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
				<?php 
				
					$files = $this->db->select('*')->where("(temp_app_id = '$doc_id'  AND cat_id = 2)", NULL, FALSE)->get('document')->result_array();
					foreach ($files as $files) { ?>
					<div class="docloopa">
						<?php	
						$emp=$this->db->select('*')->where('id',$files['user_id'])->get('users')->row_array();
						
			
						echo "<b>" . $files['name']."</b>";if($emp){ echo "<span class='empnm'>(Upoded By ".$emp['name'].")</span>";} ?>
						<span class="dwndelbtn">
			<a href="<?=base_url('uploads/case_file/' . $files["name"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
			<!--<a href="<?=base_url('front/delete_upload_files/' . $files["name"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span></div>
			<?php }?>
			</div>
		</div>
		
</div>
</div>
    </div>
    <div id="menu3" class="tab-pane fade">
  <!--    <h3>Report</h3><br>
<div class="">
<div class="upload-block">
	<div id="report" style=" float: left !important; "></div> <div class="upload-area"></div>
</div>
</div>-->
<div class="clear"></div>

<div class="row">
		<div class="form-group col-sm-12">
		<div class="form-group col-sm-12">
		 <div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Attached_files');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
				<?php 
 
					$files = $this->db->select('*')->where("(temp_app_id = '$doc_id'  AND cat_id = 4)", NULL, FALSE)->get('document')->result_array();
					foreach ($files as $files) { ?>
					<div class="docloopa">
						<?php	
						$emp=$this->db->select('*')->where('id',$files['user_id'])->get('users')->row_array();
						
			
						echo "<b>" . $files['name']."</b>";if($emp){ echo "<span class='empnm'>(Upoded By ".$emp['name'].")</span>";} ?>
						<span class="dwndelbtn">
			<a href="<?=base_url('uploads/case_file/' . $files["name"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
			<!--<a href="<?=base_url('front/delete_upload_files/' . $files["name"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span></div>
			<?php } ?>
			</div>
		</div>
		</div>
		
</div>
    </div>
    </div>
   
	<div id="menu5" class="tab-pane fade">
<br>
<div class="">
<div class="upload-block">
	<div id="contaract" style=" float: left !important; "></div> <div class="upload-area"></div>
</div>
</div>
<div class="clear"></div>

<div class="row">
		<div class="form-group col-sm-12">
			 <div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Attached_files');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
				<?php 
 
					$files = $this->db->select('*')->where("(temp_app_id = '$doc_id'  AND cat_id = 3)", NULL, FALSE)->get('document')->result_array();
					foreach ($files as $files) { ?>
					<div class="docloopa">
						<?php	
						$emp=$this->db->select('*')->where('id',$files['user_id'])->get('users')->row_array();
						
			
						echo "<b>" . $files['name']."</b>";if($emp){ echo "<span class='empnm'>(Upoded By ".$emp['name'].")</span>";} ?>
						<span class="dwndelbtn">
			<a href="<?=base_url('uploads/case_file/' . $files["name"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
		<!--	<a href="<?=base_url('front/delete_upload_files/' . $files["name"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span></div>
			<?php }?>
			</div>
		</div>
	</div>
	</div>
</div>
<div id="menu7" class="tab-pane fade">
<br>
<div class="">
<div class="upload-block">
	<div id="procuation" style=" float: left !important; "></div> <div class="upload-area"></div>
</div>
</div>
<div class="clear"></div>

<div class="row">
		<div class="form-group col-sm-12">

						<div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('File_List');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
				<?php 
 
					$files = $this->db->select('*')->where("(temp_app_id = '$doc_id'  AND cat_id = 6)", NULL, FALSE)->get('document')->result_array();
					foreach ($files as $files) { ?>
					<div class="docloopa">
						<?php	
						$emp=$this->db->select('*')->where('id',$files['user_id'])->get('users')->row_array();
						
			
						echo "<b>" . $files['name']."</b>";if($emp){ echo "<span class='empnm'>(Upoded By ".$emp['name'].")</span>";} ?>
						<span class="dwndelbtn">
			<a href="<?=base_url('uploads/case_file/' . $files["name"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
		<!--	<a href="<?=base_url('front/delete_upload_files/' . $files["name"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span></div>
			<?php }?>
			</div>
		</div>
	</div>
</div>
</div>
<div id="menu6" class="tab-pane fade">
<br>
<div class="">
<div class="upload-block">
	<div id="referrals" style=" float: left !important; "></div> <div class="upload-area"></div>
</div>
</div>
<div class="clear"></div>

<div class="row">
		<div class="form-group col-sm-12">
			 <div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Attached_files');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
				<?php 
 
					$files = $this->db->select('*')->where("(temp_app_id = '$doc_id' AND cat_id = 7)", NULL, FALSE)->get('document')->result_array();
					foreach ($files as $files) { ?>
					<div class="docloopa">
						<?php	
						$emp=$this->db->select('*')->where('id',$files['user_id'])->get('users')->row_array();
						
			
						echo "<b>" . $files['name']."</b>";if($emp){ echo "<span class='empnm'>(Upoded By ".$emp['name'].")</span>";} ?>
						<span class="dwndelbtn">
			<a href="<?=base_url('uploads/case_file/' . $files["name"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
			<!--<a href="<?=base_url('front/delete_upload_files/' . $files["name"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span></div>
			<?php }?>
			</div>
		</div>
	</div>
</div>
</div>

 
	
<br>
<br>
</div></div></div></div></div>	<div class="row">

		<div class="col-md-6 ">
		 
						<div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Audio_Record');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">		
				<label for="note" class=" form-control-label"><?php echo $this->lang->line('Enter_Audio_File_Name');?></label>
			<?= form_input(['id'=>'audio_name','class'=>'form-control audio_name']);?>	<br><br>	<br> 
				<audio controls id="audio" name="audio"></audio><br><br><br>
			<div style=" width: 100%; ">
			<a class="btn btn-primary btn-sm recordButton" href="javascript:;" id="record"><?php echo $this->lang->line('Record');?></a>
			<a class="btn btn-primary btn-sm disabled one" href="javascript:;" id="pause"><?php echo $this->lang->line('Pause');?></a>
			<a class="btn btn-primary btn-sm disabled one" href="javascript:;" id="stop"><?php echo $this->lang->line('Reset');?></a><br><br>
		</div>  <br/><br> 
	<label for="live">	<input class="" type="checkbox" id="live"/>
		<?php echo $this->lang->line('Live_Output');?></label><br/> 
		<div data-type="wav" style=" width: 100%; ">
			<p><?php echo $this->lang->line('WAV_Controls');?>:</p>
			<a class="btn btn-primary btn-sm disabled one"  href="javascript:;" id="play"><?php echo $this->lang->line('Play');?></a>
			<a class="btn btn-primary btn-sm disabled one"  href="javascript:;" id="download"><?php echo $this->lang->line('Download');?></a>
			<a class="btn btn-primary btn-sm disabled one"  href="javascript:;" id="save"><?php echo $this->lang->line('Upload_to_Audio');?></a>
		</div>
		<br>
		<canvas id="level" height="100" width="350"></canvas>
		</div>
	
	</div>
 	</div>
<?php 
$files = $this->db->select('*')->where('case_number',$cisd)->get('document')->result_array();
?>
<div class="col-md-6">
 	
						<div class="row thh">
                            <div class="col-lg-12">
                                <h3><?php echo $this->lang->line('Audio_Record_List');?></h3>
                            </div>
                        </div>
                        <div class="in_fo">
                            <div class="form-group m-form__group row">
		<?php
		$audio = $this->db->select('audio,id')->where('audioid',$doc_id)->get('uploads')->result_array();
		foreach ($audio as $audio) { ?>
		<div class="docloopa">
			<?php echo "<b>" . $audio['audio']."</b>"; ?>
			<span class="dwndelbtn">
			<a href="<?=base_url('uploads/audio/' . $audio["audio"]);?>" class='btn btn-success btn-sm' download><?php echo $this->lang->line('Download');?></a> 
			<!--<a href="<?=base_url('front/delete_audio_files/' . $audio["audio"].'/'.$cisd);?>" class='btn btn-danger  btn-sm'>Delete</a>-->
			</span>
		</div>
	<?php }?><div class="putaudiores"></div>
	</div>
</div> 
</div>  
</div>

</div>
<div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
	<div class="m-form__actions m-form__actions--solid">
		<div class="row">
			<div class="col-lg-6">
				<button type="submit" class="btn btn-primary btn-lg"><?php echo $this->lang->line('Save');?></button>
				 
			</div>
			
		</div>
	</div>
</div>
</form>
 



</div>
</div>
</div>
 
  </div>
<span class="type" id="case"></span> 
 <span class="sessionid" id="<?php echo $this->session->userdata('user_id'); ?>"></span>
  <span class="audioid" id="<?php echo $doc_id; ?>"></span>
<span class="audioocaseid" id="<?php echo $doc_id; ?>"></span>
<?php if($data) { include "footer.php"; } ?>
<script src="<?=base_url('assets/js/jquery-1.12.3.min.js');?>"></script>
<script src="<?= base_url('assets/js/audio/jquery.js'); ?>"></script>
<script src="<?= base_url('assets/js/audio/app.js'); ?>"></script>
<script src="<?= base_url('assets/js/audio/Fr.voice.js'); ?>"></script>

<script src="<?= base_url('assets/js/audio/libmp3lame.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/audio/mp3Worker.js'); ?>"></script>
<script src="<?= base_url('assets/js/audio/recorder.js'); ?>"></script>
 


<link href=<?php echo base_url('assets/css/uploadfile.css'); ?> rel="stylesheet">
<script src=<?php echo base_url('assets/js/jquery.uploadfile.min.js'); ?>></script> 
<?php 
$case_id_add = $this->db->select_max('id')
	->get('c_case')
	->row_array();
$case_id_add = $case_id_add['id'] + 1;
$cisd = isset($data->id) ? $data->id  : $case_id_add;
?>
<script src="<?= base_url('assets/js/hijri/jquery.calendars.js') ?>"></script>
<script src="<?= base_url('assets/js/hijri/jquery.calendars.plus.min.js') ?>"></script>
<script src="<?= base_url('assets/js/hijri/jquery.plugin.min.js') ?>"></script>
<script src="<?= base_url('assets/js/hijri/jquery.calendars.picker.js') ?>"></script>
<script src="<?= base_url('assets/js/hijri/jquery.calendars.ummalqura.min.js') ?>"></script>
<link href="<?= base_url('assets/js/hijri/jquery.calendars.picker.css') ?>" rel="stylesheet"/>

<script>
/*(function($) {
	'use strict';
	$.calendars.calendars.islamic.prototype.regionalOptions.ar = {
		name: 'Islamic',
		epochs: ['BAM', 'AM'],
		monthNames: 'محرم_صفر_ربيع الأول_ربيع الثاني_جمادى الأول_جمادى الآخر_رجب_شعبان_رمضان_شوال_ذو القعدة_ذو الحجة'.split('_'),
		monthNamesShort: 'محرم_صفر_ربيع1_ربيع2_جمادى1_جمادى2_رجب_شعبان_رمضان_شوال_القعدة_الحجة'.split('_'),
		dayNames: ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
		dayNamesShort: 'أحد_إثنين_ثلاثاء_أربعاء_خميس_جمعة_سبت'.split('_'),
		dayNamesMin: 'ح_ن_ث_ر_خ_ج_س'.split('_'),
		digits: $.calendars.substituteDigits(['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩']),
		dateFormat: 'dd/mm/yyyy',
		firstDay: 1,
		isRTL: true
	};
})(jQuery);*/

 (function ($) {
	'use strict';
	$.calendars.calendars.ummalqura.prototype.regionalOptions.ar = {
		name: 'UmmAlQura', // The calendar name
		epochs: ['BAM', 'AM'],
		monthNames: 'محرم_صفر_ربيع الأول_ربيع الثاني_جمادى الأول_جمادى الآخر_رجب_شعبان_رمضان_شوال_ذو القعدة_ذو الحجة'.split('_'),
		monthNamesShort: 'محرم_صفر_ربيع1_ربيع2_جمادى1_جمادى2_رجب_شعبان_رمضان_شوال_القعدة_الحجة'.split('_'),
		dayNames: ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
		dayNamesShort: 'أحد_إثنين_ثلاثاء_أربعاء_خميس_جمعة_سبت'.split('_'),
		dayNamesMin: 'ح_ن_ث_ر_خ_ج_س'.split('_'),
		digits: $.calendars.substituteDigits(['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩']),
		dateFormat: 'dd/mm/yyyy',
		firstDay: 1,
		isRTL: true
	};
})(jQuery);

$('#case_start_date').calendarsPicker({
  calendar: $.calendars.instance('<?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") echo "ummalqura"; else echo ""; ?>','<?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") echo "ar"; else echo "en"; ?>'),
        showOtherMonths: true, 
        dateFormat: 'dd/mm/yyyy',
        minDate:0, 
       <?php if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="") { ?> 
     //   defaultDate: +1,
        <?php } ?>
        selectDefaultDate:true,
  onSelect: function (date) {
	
  }
});
$(document).ready(function()
{
	
	$("#image").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":1},
    dragdropWidth:420,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
	allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
	showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) { 
			});
		pd.statusbar.hide(); 
	},
	});
	$("#data").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":2},
    dragdropWidth:420,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) { 
			});
		pd.statusbar.hide(); 
	},
	});
	$("#contaract").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":3},
    dragdropWidth:360,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) {
			});
		pd.statusbar.hide(); 
	},
	});
	$("#report").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":4},
    dragdropWidth:360,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) { 
			});
		pd.statusbar.hide(); 
	},
	});
	$("#tuning").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":5},
    dragdropWidth:360,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
   allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
   showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) { 
			});
		pd.statusbar.hide(); 
	},
	});
	$("#procuation").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":6},
    dragdropWidth:360,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
    allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
    showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) { 
			});
		pd.statusbar.hide(); 
	},
	});
	$("#referrals").uploadFile({
	url:"<?=base_url('front/modify_upload_file');?>",
	fileName:"image",
	dragDropStr: "<div class='drage-file'><b><?php echo $this->lang->line('Drag_the_files_here');?></div>",
    abortStr:"Cancel",
    statusBarWidth:300,
	formData: {"fid":'<?php echo $doc_id; ?>',"cat_id":7},
    dragdropWidth:360,
	uploadStr:"<?php echo $this->lang->line('Or_click_here_to_view_the_files');?>",
    allowedTypes:"jpg,jpeg,png,gif,ico,mp3,m4a,ogg,wav,psd,xls,xlsx,odt,ppt,pptx,pps,ppsx,doc,docx,pdf",
    showDelete: true,
	deleteCallback: function (data, pd) {  obj = JSON.parse(data); 
		$.post("<?=base_url('admin/c_case/delete_admin_modify_upload_file');?>", {op: "delete",name: obj.name},
			function (resp,textStatus, jqXHR) { 
			});
		pd.statusbar.hide(); 
	},
	});
});
  $("#court_name").change(function(){  
	var  id = $('#court_name :selected').val();  
	$.ajax({
		 type: 'POST',
		url: "<?php echo base_url('admin/admin/get_court_details'); ?>",  
		cache: false,
		data: {id: id},  
		dataType: 'JSON',  
		success: function(data) {
		$("#court_number").val(data['number']);
		$("#court_address").val(data['address']);
		 
		if(data['number']) { $('#court_number').attr('readonly', true); }
		if(data['address']) { $('#court_address').attr('readonly', true); }
 
		},
		error:function(){
		$('#court_number').attr('readonly', false);
		$('#court_address').attr('readonly', false);
		$("#court_number").val("");
		$("#court_address").val("");
	},
	});
});
</script>
<script type="text/javascript">
$('#service_types').on('change', function() {
var url="<?= base_url('front/ajax_case_type'); ?>"; 
var id = this.value;
$.ajax({
  type:'ajax',
  method:'post',
  url:url,
  data:{"id" : id},
  success:function(data){
 
	$('#case_type').html(data);
  },
});
});
</script>
	<script>
$(document).ready(function() {
	   setInterval(function(){
 
	var url="<?=base_url('front/read_notification_status');?>";
   $.ajax({
		type:'ajax',
		method:'post',
		url:url,
		success:function(data){
		  $('.noticount').html(data);
		}
	});
	}, 1000);
});
</script>
<?php if(!$data) { include "footer.php"; } ?>