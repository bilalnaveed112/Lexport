<?php
$nvc = "white-nav sticky shrink modern hover4 radius-drop";
if($this->session->userdata('site_lang')=="arabic" OR $this->session->userdata('site_lang')=="" )
{
    $title = $data['title_ar'];
    $description = $data['discription_ar'];
}
else
{
    $title = $data['title'];
    $description = $data['discription'];
}
include('header.php');
?>

<style>
    .bg-soft-gradient1:before {
        opacity: 0.9;
        background: #caa457;
        background: -moz-linear-gradient(45deg, #caa457 0%, #e1b763 100%);
        background: -webkit-linear-gradient(45deg, #caa457 0%,#e1b763 100%);
        background: linear-gradient(to 45deg, #caa457 0%,#e1b763 100%);
    }
</style>

    <!-- CONTENT -->
    <section id="home44" class="sm-py white fullwidth  bg-soft-colored bg-soft bg-scroll cover" data-background="content/etna/images/about_01.jpg">
        <!-- Container -->
        <div class="container">
            <div class="row calculate-height">
                <div class="t-left t-center-xs col-sm-12 col-xs-12">
                    <h2><?= $title; ?></h2>
                    <p><i>Published on: <font style="vertical-align: inherit;"><?= $data['date']; ?>
                </div>
            </div>
        </div>
        <!-- End Container -->
    </section>
    <!-- END CONTENT -->
    <section id="team" class="team-type-2 py">

        <!-- Row -->
        <div class="container">

            <div class="row">
<?php  if(isset($data['image'])){  ?>
<img src="<?php echo base_url('uploads/news/'.$data['image']); ?>" style=" max-width: 500px; max-height: 500px; margin: auto; ">
<?php } ?>
    <p>
		<?php echo $description?>
	</p>
        </div>    </div>    </div>
        <!-- End Row -->


    </section>
    <!-- END CONTENTS -->
  
			
	</section>

</div>
<?php include "footer.php"; ?>