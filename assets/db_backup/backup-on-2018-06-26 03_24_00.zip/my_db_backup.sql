#
# TABLE STRUCTURE FOR: c_case
#

DROP TABLE IF EXISTS `c_case`;

CREATE TABLE `c_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_dob` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `case_total_amount` varchar(255) NOT NULL,
  `case_situation` varchar(255) NOT NULL,
  `final_decision` varchar(255) NOT NULL,
  `employee_id` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `power_of_attorney` text NOT NULL,
  `lawyer` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `package_id` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `number_of_judgement` varchar(255) NOT NULL,
  `source_of_judgement` varchar(255) NOT NULL,
  `reasons_of_appeal` text NOT NULL,
  `additional_information` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` int(11) NOT NULL COMMENT '0--in active,1--active',
  `is_delete` int(11) NOT NULL COMMENT '0--not delete,1--delete',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `c_case` (`id`, `customer_id`, `case_number`, `customer_name`, `customer_dob`, `address`, `email`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `is_delete`, `created`, `modified`) VALUES (10, 152, '10', 'priyank vora ', '1900-11-15', 'rajkot mavdi new', 'priyank123@gmail.com', 'Legal Sessions', '5000', '5', '4750', 'priyank is a great person in this crime', 'pending', '142', '5', 'nothing', 'a.b shah', 'dr.mathur delhi vala', 'delhi high court', 'rajkot high court', '3', 'hom savalia', 'sbi jail road mamadev ma temple near', '', '', '', '', '0000-00-00', '0000-00-00', 1, 0, '2018-05-15 16:13:15', '2018-06-14 14:44:41');
INSERT INTO `c_case` (`id`, `customer_id`, `case_number`, `customer_name`, `customer_dob`, `address`, `email`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `is_delete`, `created`, `modified`) VALUES (14, 154, '11', 'shailesh vekariya ', '1900-11-14', 'rajkot ma kai baju', 'vekariyashailesh123@gmail.com', 'Legal Services', '2000', '15', '1700', 'shailo khuni nathi ha bhai sachej', 'pending 6e bhai haji', '145', '4', 'nothing', 'shaila na papa', 'shaila no bhai', 'ghar', 'business', '2', 'shaila no friend', 'atm', '', '', '', '', '0000-00-00', '0000-00-00', 1, 0, '2018-05-29 15:07:00', '2018-06-09 16:07:12');
INSERT INTO `c_case` (`id`, `customer_id`, `case_number`, `customer_name`, `customer_dob`, `address`, `email`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `is_delete`, `created`, `modified`) VALUES (15, 157, '12', 'new customer rajkot valo', '2018-06-20', 'ahiya j rah e6e bhai', 'newcustomer123@gmail.com', 'Legal Sessions', '5000', '10', '4500', 'haji to new customer 6e', 'haji bhai aa new customer 6e', '145', '7', 'okk', 'nkki nathi', 'new che', 'gujarat high court', 'rajkot high court', '3', 'me', 'new', '', '', '', '', '0000-00-00', '0000-00-00', 1, 0, '2018-06-03 16:10:18', '2018-06-14 14:44:45');
INSERT INTO `c_case` (`id`, `customer_id`, `case_number`, `customer_name`, `customer_dob`, `address`, `email`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `is_delete`, `created`, `modified`) VALUES (16, 152, '13', 'priyank vora ', '1900-11-15', 'rajkot mavdi new', 'priyank123@gmail.com', 'Legal Services', '2000', '25', '1500', 'seriously', 'waiting', '142', '4', 'ok', 'me', 'you', 'delhi', 'rajkot', '2', 'ok', 'sbi', '', '', '', '', '0000-00-00', '0000-00-00', 1, 1, '2018-06-09 11:43:02', '2018-06-20 03:36:31');
INSERT INTO `c_case` (`id`, `customer_id`, `case_number`, `customer_name`, `customer_dob`, `address`, `email`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `is_delete`, `created`, `modified`) VALUES (17, 154, '14', 'shailesh vekariya ', '1900-11-14', 'rajkot ma kai baju', 'vekariyashailesh123@gmail.com', 'Legal Consultant', '2000', '10', '1800', 'dtjh', 'dtth', '144', '2', 'rtth', 'dth', 'th', 'eth', 'rdth', '2', 'tth', 'dth', '', '', '', '', '0000-00-00', '0000-00-00', 1, 0, '2018-06-09 12:23:44', '2018-06-14 14:44:51');
INSERT INTO `c_case` (`id`, `customer_id`, `case_number`, `customer_name`, `customer_dob`, `address`, `email`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `is_delete`, `created`, `modified`) VALUES (30, 173, '16', 'paras bhai gondal vala', '', 'gondal', 'paras164@gmail.com', 'Legal writing', '', '', '', '', '', '', '', '', '', '', '', '', '2', '', '', '100', 'nothing', 'judge are decided', '', '0000-00-00', '0000-00-00', 0, 0, '2018-06-23 12:51:45', '2018-06-25 12:53:02');


#
# TABLE STRUCTURE FOR: case_temp
#

DROP TABLE IF EXISTS `case_temp`;

CREATE TABLE `case_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `case_total_amount` varchar(255) NOT NULL,
  `case_situation` varchar(255) NOT NULL,
  `final_decision` varchar(255) NOT NULL,
  `employee_id` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `power_of_attorney` varchar(255) NOT NULL,
  `lawyer` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `package_id` varchar(255) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `number_of_judgement` varchar(255) NOT NULL,
  `source_of_judgement` varchar(255) NOT NULL,
  `reasons_of_appeal` text NOT NULL,
  `additional_information` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `add_edit` int(11) NOT NULL COMMENT '0--add,1--edit',
  `is_delete` int(11) NOT NULL COMMENT '0--not delete,1--delete',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `case_temp` (`id`, `case_id`, `customer_id`, `case_number`, `service_type`, `amount`, `discount`, `case_total_amount`, `case_situation`, `final_decision`, `employee_id`, `department_id`, `power_of_attorney`, `lawyer`, `judge_name`, `court_name`, `reference`, `package_id`, `agent`, `branch`, `number_of_judgement`, `source_of_judgement`, `reasons_of_appeal`, `additional_information`, `start_date`, `end_date`, `status`, `add_edit`, `is_delete`, `created`) VALUES (21, 20, 173, '16', 'Legal writing', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '100', 'nothing', 'judge are decided', '', '0000-00-00', '0000-00-00', 0, 0, 0, '2018-06-23 12:54:58');


#
# TABLE STRUCTURE FOR: contact_us
#

DROP TABLE IF EXISTS `contact_us`;

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: customer_temp
#

DROP TABLE IF EXISTS `customer_temp`;

CREATE TABLE `customer_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `add_edit` int(11) NOT NULL DEFAULT '0' COMMENT '0--add,1--edit',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: department
#

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `d_name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (1, 'Secretarial', '2018-05-06 11:43:43');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (2, 'Lawyers', '2018-05-06 11:43:43');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (3, 'Consultants', '2018-05-06 11:44:01');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (4, 'Partners', '2018-05-06 11:44:01');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (5, 'Management', '2018-05-06 11:44:15');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (6, 'director', '2018-05-06 11:44:15');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (7, 'finance', '2018-05-06 11:44:34');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (8, 'Administration', '2018-05-06 11:44:34');


#
# TABLE STRUCTURE FOR: document
#

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `case_number` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=latin1;

INSERT INTO `document` (`id`, `name`, `customer_id`, `case_number`, `created`) VALUES (15, 'aa1.jpg', 154, 11, '2018-05-31 17:04:04');
INSERT INTO `document` (`id`, `name`, `customer_id`, `case_number`, `created`) VALUES (16, 'aa2.jpg', 152, 10, '2018-05-31 17:03:41');
INSERT INTO `document` (`id`, `name`, `customer_id`, `case_number`, `created`) VALUES (17, 'aa3.jpg', 154, 11, '2018-05-31 17:04:08');
INSERT INTO `document` (`id`, `name`, `customer_id`, `case_number`, `created`) VALUES (18, 'aa1.jpg', 154, 11, '2018-05-31 17:02:58');
INSERT INTO `document` (`id`, `name`, `customer_id`, `case_number`, `created`) VALUES (19, 'aa2.jpg', 152, 10, '2018-05-31 17:03:02');
INSERT INTO `document` (`id`, `name`, `customer_id`, `case_number`, `created`) VALUES (20, 'aa3.jpg', 150, 12, '2018-05-31 17:03:05');


#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `bank_accounts` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `monthly_salary` varchar(255) NOT NULL,
  `contract_file` varchar(255) NOT NULL,
  `governmental_id_file` varchar(255) NOT NULL,
  `certificate_file` varchar(255) NOT NULL,
  `employees_photo` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (39, 144, '12000', 'longterm', '1', 'bob', '1234567890', 'bob ', '32000', 'ab7.jpg', 'baps3.jpg', 'b2.jpg', 'IMG_0543.JPG', '2018-06-18 06:51:33', '2018-06-18 06:51:33');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (40, 145, '2500', 'longterm', '8', 'bob', '5738/93', 'bob', '10200', '', '', '', 'IMG_0530.JPG', '2018-06-18 06:51:28', '2018-06-18 06:51:28');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (41, 156, '100000', 'temporary', '3', 'dena', '1234567890', 'sbi', '10200', 'b2.jpg', 'c1.jpg', 'baps1.png', 'c1.jpg', '2018-06-04 12:10:21', '2018-06-04 18:45:17');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (42, 159, 'ewrg', 'temporary', '2', 'rg', 'erh', 'serrg', 'wrg', '', '', '', 'IMG_0521.JPG', '2018-06-18 07:04:43', '2018-06-18 07:04:43');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (43, 175, '10200', 'longterm', '2', 'sbi', '265454645485', 'sbi', '10200', '', '', '', 'b8.jpg', '2018-06-25 10:43:26', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: employee_temp
#

DROP TABLE IF EXISTS `employee_temp`;

CREATE TABLE `employee_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `bank_accounts` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `monthly_salary` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `contract_file` varchar(255) NOT NULL,
  `governmental_id_file` varchar(255) NOT NULL,
  `certificate_file` varchar(255) NOT NULL,
  `employees_photo` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0--in active,1--active',
  `add_edit` int(11) NOT NULL COMMENT '0--add,1--edit',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: packages
#

DROP TABLE IF EXISTS `packages`;

CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `service_id` int(11) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (1, 'Schedule an internal meeting', 'basic', 1, '1 month', '1000', '2018-06-22 19:01:03', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (2, 'Schedule an external meeting', 'this is a medium package', 1, '1 month', '2000', '2018-06-22 19:01:29', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (3, 'Requesting paper legal writings', 'this is a high package', 1, '3 month', '5000', '2018-06-22 19:01:33', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (4, 'Schedule an internal meeting', 'this is a golden package', 2, '1 month', '10500', '2018-06-22 19:01:39', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (5, 'Schedule an external meeting', 'this is a silver package', 2, '10 month', '2500', '2018-06-22 19:01:50', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (6, 'Request to attend court session', 'Request to attend court session', 2, '1 year', '2000\r\n', '2018-06-22 19:03:05', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (7, 'Schedule an internal meeting', 'Schedule an internal meeting', 3, '1 month', '1200', '2018-06-22 19:04:07', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (8, 'Schedule an external meeting', 'Schedule an external meeting', 3, '1 year', '1500', '2018-06-22 19:04:24', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (9, 'Request a voice consultation', 'Request a voice consultation', 3, '2 month', '3000', '2018-06-22 19:04:43', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (10, 'Request written consultation', 'Request written consultation', 3, '3 month', '2500', '2018-06-22 19:05:02', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (11, 'Request for audio and written consultation', 'Request for audio and written consultation', 3, '2 month', '3000', '2018-06-22 19:05:21', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `name`, `created`) VALUES (1, 'admin', '2018-05-02 21:02:21');
INSERT INTO `roles` (`id`, `name`, `created`) VALUES (2, 'employee', '2018-05-02 21:02:21');
INSERT INTO `roles` (`id`, `name`, `created`) VALUES (3, 'customer', '2018-05-02 22:55:26');


#
# TABLE STRUCTURE FOR: services
#

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `services` (`id`, `name`, `description`, `created`, `modified`) VALUES (1, 'Legal writing', 'Legal writing', '2018-06-22 12:20:00', '2018-06-01 15:34:48');
INSERT INTO `services` (`id`, `name`, `description`, `created`, `modified`) VALUES (2, 'Legal Sessions', 'Legal Sessions', '2018-06-22 12:19:40', '2018-05-26 13:42:30');
INSERT INTO `services` (`id`, `name`, `description`, `created`, `modified`) VALUES (3, 'Legal Consultant', 'Legal Consultant', '2018-06-22 12:19:40', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: task
#

DROP TABLE IF EXISTS `task`;

CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `task` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `key_token` varchar(255) NOT NULL COMMENT 'Forgot password in used ',
  `device_type` int(11) NOT NULL COMMENT '1- android, 2- iphone',
  `device_token` varchar(255) NOT NULL,
  `verification_token` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0- in active , 1- active',
  `is_delete` int(11) NOT NULL DEFAULT '0' COMMENT '0- not delete, 1 - delete',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (142, 'Raiyani paras', '1998-05-09', 'bhojrajpara', '9724081113', 'raiyaniparas164@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1, '', 0, '', '', 1, 0, '2018-06-23 13:03:10', '2018-06-23 13:03:10');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (144, 'savan aasodariya', '1901-01-17', 'rajkot rto', '1234567890', 'savan123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 2, '', 0, '', '', 1, 0, '2018-06-20 22:35:02', '2018-06-20 22:35:02');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (145, 'hom savaliya ', '1900-11-29', 'kolithad', '9624222022', 'hom123@gmail.com', '223d7ff84b85cb76f226799bc0e653fa', 2, '', 0, '', '', 1, 0, '2018-06-23 12:50:30', '2018-06-23 12:50:30');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (152, 'priyank vora ', '1900-11-15', 'rajkot mavdi new', '8866443122', 'priyank123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 3, '', 0, '', '', 1, 0, '2018-06-19 00:13:21', '2018-06-19 00:13:21');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (154, 'shailesh vekariya ', '1900-11-14', 'rajkot ma kai baju', '2222222222', 'vekariyashailesh123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 3, '', 0, '', '', 1, 0, '2018-06-19 00:13:16', '2018-06-19 00:13:16');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (156, 'new employee', '1900-11-14', 'gondal', '6546546546', 'newemployee@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 2, '', 0, '', '', 1, 0, '2018-06-19 00:13:10', '2018-06-19 00:13:10');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (157, 'new customer rajkot valo', '2018-06-20', 'ahiya j rah e6e bhai', '9724081113', 'newcustomer123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 3, '', 0, '', '', 1, 0, '2018-06-19 00:13:06', '2018-06-19 00:13:06');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (158, 'sagar kothiya', '2018-06-09', 'mavdi chokdi', '7896541230', 'sagar123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 3, '', 0, '', '', 1, 0, '2018-06-19 00:13:01', '2018-06-19 00:13:01');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (173, 'paras bhai gondal vala', '0000-00-00', 'gondal', '9876543210', 'raiyaniparas164@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 3, '', 0, '', '', 1, 0, '2018-06-26 19:38:56', '2018-06-26 19:38:56');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (174, 'new admin', '2018-06-22', 'rajkot', '1234567890', 'admin123@gmail.com', 'b6974067030e5d0377e9bb99f276368c', 1, '', 0, '', '', 1, 0, '2018-06-25 10:38:24', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `phone`, `email`, `password`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `status`, `is_delete`, `created`, `modified`) VALUES (175, 'new employee', '2018-06-14', 'rajkot', '1234567896', 'employee123@gmail.com', '3e5b4e62f633478cac4b813c8017b933', 2, '', 0, '', '', 1, 0, '2018-06-25 10:45:21', '2018-06-25 10:45:21');


