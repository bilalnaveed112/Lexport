#
# TABLE STRUCTURE FOR: action_log
#

DROP TABLE IF EXISTS `action_log`;

CREATE TABLE `action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `action_type` varchar(255) NOT NULL,
  `status_type` varchar(255) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=latin1;

INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (1, 0, 0, 323, 0, 0, '0', '0', '2018-10-15 05:15:42', '2018-10-15 05:15:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (2, 0, 0, 324, 0, 0, '0', '0', '2018-10-15 05:24:27', '2018-10-15 05:24:27');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (3, 0, 0, 325, 0, 0, 'register', '', '2018-10-15 05:28:13', '2018-10-15 05:28:13');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (4, 0, 0, 306, 0, 0, 'login', '', '2018-10-15 05:34:12', '2018-10-15 05:34:12');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (5, 0, 0, 306, 0, 0, 'otp_verify', 'faild', '2018-10-16 23:58:26', '2018-10-16 23:58:26');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (6, 0, 0, 306, 0, 0, 'login', 'customer', '2018-10-16 23:58:33', '2018-10-16 23:58:33');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (7, 0, 0, 306, 0, 0, 'otp_verify', 'success', '2018-10-16 23:58:58', '2018-10-16 23:58:58');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (8, 0, 0, 306, 0, 0, 'logout', 'customer', '2018-10-17 00:06:39', '2018-10-17 00:06:39');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (9, 0, 0, 306, 0, 0, 'login', 'customer', '2018-10-17 00:06:50', '2018-10-17 00:06:50');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (10, 0, 0, 306, 0, 0, 'logout', 'customer', '2018-10-17 00:07:14', '2018-10-17 00:07:14');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (11, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-17 08:36:50', '2018-10-17 08:36:50');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (12, 142, 0, 0, 0, 1, 'session_appoinment', 'add_view', '2018-10-17 08:36:53', '2018-10-17 08:36:53');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (13, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-17 08:56:55', '2018-10-17 08:56:55');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (14, 0, 0, 306, 0, 3, 'logout', 'customer', '2018-10-17 08:57:29', '2018-10-17 08:57:29');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (15, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-17 08:57:43', '2018-10-17 08:57:43');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (16, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-17 22:52:21', '2018-10-17 22:52:21');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (17, 0, 0, 306, 0, 3, 'logout', 'customer', '2018-10-17 22:52:51', '2018-10-17 22:52:51');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (18, 0, 0, 332, 0, 3, 'register', '', '2018-10-18 05:58:31', '2018-10-18 05:58:31');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (19, 0, 0, 332, 0, 3, 'otp_verify', 'success', '2018-10-18 05:58:42', '2018-10-18 05:58:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (20, 0, 0, 332, 0, 3, 'otp_verify', 'faild', '2018-10-18 05:58:50', '2018-10-18 05:58:50');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (21, 0, 0, 332, 0, 3, 'otp_verify', 'faild', '2018-10-18 05:58:57', '2018-10-18 05:58:57');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (22, 0, 0, 332, 0, 3, 'otp_verify', 'faild', '2018-10-18 05:59:17', '2018-10-18 05:59:17');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (23, 0, 0, 332, 0, 3, 'otp_verify', 'faild', '2018-10-18 05:59:28', '2018-10-18 05:59:28');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (24, 0, 0, 332, 0, 3, 'logout', 'customer', '2018-10-18 05:59:35', '2018-10-18 05:59:35');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (25, 0, 0, 333, 0, 3, 'register', '', '2018-10-18 06:00:10', '2018-10-18 06:00:10');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (26, 0, 0, 333, 0, 3, 'otp_verify', 'success', '2018-10-18 06:00:25', '2018-10-18 06:00:25');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (27, 0, 0, 333, 0, 3, 'logout', 'customer', '2018-10-18 06:00:50', '2018-10-18 06:00:50');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (28, 0, 0, 334, 0, 3, 'register', '', '2018-10-18 06:06:28', '2018-10-18 06:06:28');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (29, 0, 0, 334, 0, 3, 'otp_verify', 'success', '2018-10-18 06:06:42', '2018-10-18 06:06:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (30, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 06:31:14', '2018-10-18 06:31:14');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (31, 142, 0, 0, 1, 1, 'session_appoinment', 'edit_view', '2018-10-18 06:32:57', '2018-10-18 06:32:57');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (32, 142, 0, 0, 0, 1, 'session_appoinment', 'edit_view', '2018-10-18 06:32:58', '2018-10-18 06:32:58');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (33, 142, 0, 0, 7, 1, 'session_appoinment', 'add', '2018-10-18 06:33:04', '2018-10-18 06:33:04');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (34, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 06:33:05', '2018-10-18 06:33:05');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (35, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 06:37:46', '2018-10-18 06:37:46');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (36, 142, 0, 0, 0, 1, 'writings_appoinment', 'list', '2018-10-18 06:39:58', '2018-10-18 06:39:58');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (37, 142, 0, 0, 0, 1, 'consultation_appoinment', 'list', '2018-10-18 06:42:14', '2018-10-18 06:42:14');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (38, 142, 0, 0, 0, 1, 'consultation_appoinment', 'list', '2018-10-18 06:46:57', '2018-10-18 06:46:57');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (39, 142, 0, 0, 0, 1, 'visiting_appoinment', 'list', '2018-10-18 07:02:42', '2018-10-18 07:02:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (40, 142, 0, 0, 0, 1, 'consultation_appoinment', 'list', '2018-10-18 07:02:56', '2018-10-18 07:02:56');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (41, 142, 0, 0, 1, 1, 'consultation_appoinment', 'edit_view', '2018-10-18 07:02:59', '2018-10-18 07:02:59');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (42, 142, 0, 0, 0, 1, 'consultation_appoinment', 'edit_view', '2018-10-18 07:03:00', '2018-10-18 07:03:00');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (43, 142, 0, 0, 0, 1, 'visiting_appoinment', 'list', '2018-10-18 07:05:02', '2018-10-18 07:05:02');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (44, 142, 0, 0, 0, 1, 'consultation_appoinment', 'list', '2018-10-18 07:05:35', '2018-10-18 07:05:35');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (45, 142, 0, 0, 0, 1, 'visiting_appoinment', 'list', '2018-10-18 07:06:15', '2018-10-18 07:06:15');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (46, 142, 0, 0, 0, 1, 'visiting_appoinment', 'list', '2018-10-18 07:06:23', '2018-10-18 07:06:23');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (47, 142, 0, 0, 0, 1, 'visiting_appoinment', 'add_view', '2018-10-18 07:06:26', '2018-10-18 07:06:26');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (48, 142, 0, 0, 0, 1, 'visiting_appoinment', 'list', '2018-10-18 07:09:34', '2018-10-18 07:09:34');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (49, 142, 0, 0, 0, 1, 'judge', 'list', '2018-10-18 07:10:13', '2018-10-18 07:10:13');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (50, 142, 0, 0, 0, 1, 'judge', 'list', '2018-10-18 07:10:56', '2018-10-18 07:10:56');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (51, 0, 0, 335, 0, 3, 'register', '', '2018-10-18 08:22:21', '2018-10-18 08:22:21');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (52, 142, 0, 0, 0, 1, 'judge', 'list', '2018-10-18 10:40:19', '2018-10-18 10:40:19');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (53, 142, 0, 0, 0, 1, 'writings_appoinment', 'list', '2018-10-18 10:51:21', '2018-10-18 10:51:21');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (54, 142, 0, 0, 0, 1, 'writings_appoinment', 'add_view', '2018-10-18 10:51:23', '2018-10-18 10:51:23');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (55, 142, 0, 0, 0, 1, 'writings_appoinment', 'add_view', '2018-10-18 11:04:55', '2018-10-18 11:04:55');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (56, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 13:10:13', '2018-10-18 13:10:13');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (57, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 14:02:42', '2018-10-18 14:02:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (58, 142, 0, 0, 0, 1, 'session_appoinment', 'add_view', '2018-10-18 14:04:19', '2018-10-18 14:04:19');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (59, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 14:04:37', '2018-10-18 14:04:37');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (60, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-18 14:04:40', '2018-10-18 14:04:40');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (61, 142, 0, 0, 0, 1, 'session_appoinment', 'add_view', '2018-10-18 14:06:47', '2018-10-18 14:06:47');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (62, 142, 0, 0, 0, 1, 'writings_appoinment', 'list', '2018-10-18 14:08:52', '2018-10-18 14:08:52');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (63, 142, 0, 0, 0, 1, 'writings_appoinment', 'add_view', '2018-10-18 14:10:05', '2018-10-18 14:10:05');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (64, 142, 0, 0, 0, 1, 'writings_appoinment', 'add_view', '2018-10-18 14:18:00', '2018-10-18 14:18:00');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (65, 142, 0, 0, 0, 1, 'session_appoinment', 'add_view', '2018-10-18 15:39:37', '2018-10-18 15:39:37');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (66, 0, 0, 336, 0, 3, 'register', '', '2018-10-19 00:17:25', '2018-10-19 00:17:25');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (67, 0, 0, 337, 0, 3, 'register', '', '2018-10-19 00:18:47', '2018-10-19 00:18:47');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (68, 0, 0, 338, 0, 3, 'register', '', '2018-10-19 00:19:24', '2018-10-19 00:19:24');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (69, 0, 0, 337, 0, 3, 'logout', 'customer', '2018-10-19 00:19:41', '2018-10-19 00:19:41');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (70, 0, 0, 339, 0, 3, 'register', '', '2018-10-19 00:19:51', '2018-10-19 00:19:51');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (71, 0, 0, 339, 0, 3, 'otp_verify', 'faild', '2018-10-19 00:19:57', '2018-10-19 00:19:57');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (72, 0, 0, 339, 0, 3, 'otp_verify', 'success', '2018-10-19 00:20:00', '2018-10-19 00:20:00');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (73, 0, 0, 340, 0, 3, 'register', '', '2018-10-19 00:20:31', '2018-10-19 00:20:31');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (74, 0, 0, 341, 0, 3, 'register', '', '2018-10-19 00:21:25', '2018-10-19 00:21:25');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (75, 0, 0, 342, 0, 3, 'register', '', '2018-10-19 00:21:40', '2018-10-19 00:21:40');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (76, 0, 0, 343, 0, 3, 'register', '', '2018-10-19 00:22:10', '2018-10-19 00:22:10');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (77, 0, 0, 339, 0, 3, 'logout', 'customer', '2018-10-19 00:22:46', '2018-10-19 00:22:46');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (78, 0, 0, 338, 0, 3, 'login', 'customer', '2018-10-19 00:22:55', '2018-10-19 00:22:55');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (79, 0, 0, 344, 0, 3, 'register', '', '2018-10-19 00:23:01', '2018-10-19 00:23:01');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (80, 0, 0, 344, 0, 3, 'logout', 'customer', '2018-10-19 00:23:09', '2018-10-19 00:23:09');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (81, 0, 0, 338, 0, 3, 'login', 'customer', '2018-10-19 00:23:21', '2018-10-19 00:23:21');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (82, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 00:24:02', '2018-10-19 00:24:02');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (83, 0, 0, 306, 0, 3, 'logout', 'customer', '2018-10-19 00:24:25', '2018-10-19 00:24:25');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (84, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 00:27:19', '2018-10-19 00:27:19');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (85, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 01:03:25', '2018-10-19 01:03:25');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (86, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 01:17:46', '2018-10-19 01:17:46');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (87, 0, 0, 306, 0, 3, 'otp_verify', 'faild', '2018-10-19 01:19:14', '2018-10-19 01:19:14');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (88, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 02:06:40', '2018-10-19 02:06:40');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (89, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 02:06:51', '2018-10-19 02:06:51');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (90, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 02:07:02', '2018-10-19 02:07:02');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (91, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 02:07:32', '2018-10-19 02:07:32');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (92, 0, 0, 306, 0, 3, 'otp_verify', 'success', '2018-10-19 02:07:43', '2018-10-19 02:07:43');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (93, 0, 0, 345, 0, 3, 'register', '', '2018-10-19 02:25:26', '2018-10-19 02:25:26');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (94, 0, 0, 345, 0, 3, 'logout', 'customer', '2018-10-19 02:26:05', '2018-10-19 02:26:05');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (95, 0, 0, 346, 0, 3, 'register', '', '2018-10-19 02:26:29', '2018-10-19 02:26:29');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (96, 0, 0, 346, 0, 3, 'logout', 'customer', '2018-10-19 02:27:28', '2018-10-19 02:27:28');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (97, 0, 0, 347, 0, 3, 'register', '', '2018-10-19 02:27:44', '2018-10-19 02:27:44');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (98, 0, 0, 348, 0, 3, 'register', '', '2018-10-19 02:39:13', '2018-10-19 02:39:13');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (99, 0, 0, 348, 0, 3, 'otp_verify', 'success', '2018-10-19 02:39:18', '2018-10-19 02:39:18');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (100, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 03:04:55', '2018-10-19 03:04:55');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (101, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 03:05:46', '2018-10-19 03:05:46');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (102, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 03:07:15', '2018-10-19 03:07:15');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (103, 0, 0, 348, 0, 3, 'logout', 'customer', '2018-10-19 03:29:52', '2018-10-19 03:29:52');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (104, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 03:30:07', '2018-10-19 03:30:07');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (105, 0, 0, 306, 0, 3, 'otp_verify', 'success', '2018-10-19 03:30:13', '2018-10-19 03:30:13');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (106, 0, 0, 306, 0, 3, 'change_password', 'customer', '2018-10-19 03:30:30', '2018-10-19 03:30:30');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (107, 0, 0, 306, 0, 3, 'logout', 'customer', '2018-10-19 03:30:31', '2018-10-19 03:30:31');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (108, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:17:38', '2018-10-19 07:17:38');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (109, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:41:01', '2018-10-19 07:41:01');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (110, 0, 0, 349, 0, 3, 'register', '', '2018-10-19 07:50:26', '2018-10-19 07:50:26');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (111, 0, 0, 350, 0, 3, 'register', '', '2018-10-19 07:50:59', '2018-10-19 07:50:59');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (112, 0, 0, 351, 0, 3, 'register', '', '2018-10-19 07:51:01', '2018-10-19 07:51:01');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (113, 0, 0, 352, 0, 3, 'register', '', '2018-10-19 07:51:55', '2018-10-19 07:51:55');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (114, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:52:09', '2018-10-19 07:52:09');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (115, 0, 0, 353, 0, 3, 'register', '', '2018-10-19 07:52:42', '2018-10-19 07:52:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (116, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:19', '2018-10-19 07:53:19');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (117, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:24', '2018-10-19 07:53:24');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (118, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:25', '2018-10-19 07:53:25');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (119, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:26', '2018-10-19 07:53:26');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (120, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:35', '2018-10-19 07:53:35');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (121, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:35', '2018-10-19 07:53:35');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (122, 0, 0, 306, 0, 3, 'login', 'customer', '2018-10-19 07:53:36', '2018-10-19 07:53:36');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (123, 142, 0, 0, 0, 1, 'visiting_appoinment', 'list', '2018-10-19 08:35:04', '2018-10-19 08:35:04');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (124, 142, 0, 0, 0, 1, 'archive', 'add_view', '2018-10-19 10:56:21', '2018-10-19 10:56:21');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (125, 142, 0, 0, 0, 1, 'consultation_appoinment', 'list', '2018-10-19 12:35:24', '2018-10-19 12:35:24');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (126, 142, 0, 0, 1, 1, 'consultation_appoinment', 'view', '2018-10-19 12:35:42', '2018-10-19 12:35:42');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (127, 142, 0, 0, 0, 1, 'consultation_appoinment', 'view', '2018-10-19 12:35:44', '2018-10-19 12:35:44');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (128, 142, 0, 0, 0, 1, 'consultation_appoinment', 'list', '2018-10-19 12:35:49', '2018-10-19 12:35:49');
INSERT INTO `action_log` (`id`, `admin_id`, `user_id`, `customer_id`, `action_id`, `role`, `action_type`, `status_type`, `update_date`, `create_date`) VALUES (129, 142, 0, 0, 0, 1, 'session_appoinment', 'list', '2018-10-21 00:11:01', '2018-10-21 00:11:01');


#
# TABLE STRUCTURE FOR: activity
#

DROP TABLE IF EXISTS `activity`;

CREATE TABLE `activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=300 DEFAULT CHARSET=latin1;

INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (1, '2018-07-25 23:12:58', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (2, '2018-07-26 00:49:03', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (3, '2018-07-26 05:01:13', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (4, '2018-07-26 05:02:19', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (5, '2018-07-26 06:08:50', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (6, '2018-07-31 09:08:14', '0000-00-00 00:00:00', 142, '123.201.176.143');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (7, '2018-08-03 06:41:40', '2018-08-03 06:49:03', 142, '123.201.230.226');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (8, '2018-08-03 06:49:30', '0000-00-00 00:00:00', 142, '123.201.230.226');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (9, '2018-08-03 22:17:44', '0000-00-00 00:00:00', 142, '51.36.110.215');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (10, '2018-08-03 22:18:10', '0000-00-00 00:00:00', 142, '51.36.110.215');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (11, '2018-08-05 00:07:32', '0000-00-00 00:00:00', 142, '31.166.98.16');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (12, '2018-08-05 21:42:01', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (13, '2018-08-06 02:45:22', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (14, '2018-08-06 04:58:34', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (15, '2018-08-13 21:32:03', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (16, '2018-08-17 02:49:20', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (17, '2018-08-17 21:50:47', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (18, '2018-08-17 23:03:08', '2018-08-18 02:45:36', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (19, '2018-08-18 02:45:38', '2018-08-18 02:48:27', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (20, '2018-08-18 02:48:29', '2018-08-18 02:48:54', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (21, '2018-08-18 02:48:57', '2018-08-18 02:50:31', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (22, '2018-08-18 02:50:33', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (23, '2018-08-18 22:59:55', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (24, '2018-08-19 00:11:41', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (25, '2018-08-19 03:23:41', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (26, '2018-08-19 04:54:51', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (27, '2018-08-19 21:43:11', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (28, '2018-08-23 04:50:04', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (29, '2018-08-23 04:52:09', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (30, '2018-08-24 02:01:49', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (31, '2018-08-24 06:34:43', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (32, '2018-08-24 06:35:04', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (33, '2018-08-25 02:12:25', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (34, '2018-08-25 04:38:39', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (35, '2018-08-27 02:45:26', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (36, '2018-08-27 03:29:08', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (37, '2018-08-27 21:35:40', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (38, '2018-08-28 03:55:34', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (39, '2018-08-29 01:47:05', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (40, '2018-08-29 05:29:40', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (41, '2018-08-29 07:54:05', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (42, '2018-08-29 08:00:44', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (43, '2018-08-30 00:28:06', '0000-00-00 00:00:00', 142, '51.36.111.192');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (44, '2018-08-30 08:14:22', '0000-00-00 00:00:00', 142, '203.109.114.121');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (45, '2018-08-30 08:27:31', '0000-00-00 00:00:00', 142, '51.36.70.92');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (46, '2018-08-30 11:52:30', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (47, '2018-08-31 01:06:45', '0000-00-00 00:00:00', 142, '123.201.70.202');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (48, '2018-08-31 03:12:44', '0000-00-00 00:00:00', 142, '123.201.67.43');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (49, '2018-08-31 04:02:18', '0000-00-00 00:00:00', 142, '123.201.70.202');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (50, '2018-08-31 05:33:20', '0000-00-00 00:00:00', 142, '51.39.123.50');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (51, '2018-08-31 06:23:36', '0000-00-00 00:00:00', 142, '123.201.67.149');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (52, '2018-08-31 09:32:48', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (53, '2018-08-31 09:34:07', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (54, '2018-08-31 09:34:15', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (55, '2018-08-31 09:35:57', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (56, '2018-08-31 09:35:57', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (57, '2018-08-31 09:37:35', '2018-08-31 09:38:18', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (58, '2018-08-31 09:38:27', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (59, '2018-08-31 10:45:44', '0000-00-00 00:00:00', 142, '51.39.123.50');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (60, '2018-08-31 23:39:14', '0000-00-00 00:00:00', 142, '219.91.190.188');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (61, '2018-09-01 03:53:10', '0000-00-00 00:00:00', 142, '51.39.223.148');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (62, '2018-09-02 07:42:51', '0000-00-00 00:00:00', 142, '49.34.178.57');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (63, '2018-09-02 23:34:17', '0000-00-00 00:00:00', 142, '49.34.180.177');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (64, '2018-09-03 02:13:50', '0000-00-00 00:00:00', 142, '49.34.180.177');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (65, '2018-09-03 02:42:02', '0000-00-00 00:00:00', 142, '51.36.35.205');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (66, '2018-09-03 04:18:13', '0000-00-00 00:00:00', 142, '5.108.197.144');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (67, '2018-09-04 00:59:10', '0000-00-00 00:00:00', 142, '51.39.7.237');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (68, '2018-09-04 01:00:30', '0000-00-00 00:00:00', 142, '51.39.7.237');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (69, '2018-09-04 01:03:16', '0000-00-00 00:00:00', 142, '51.39.7.237');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (70, '2018-09-04 03:57:42', '0000-00-00 00:00:00', 142, '31.166.100.34');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (71, '2018-09-04 04:00:03', '0000-00-00 00:00:00', 142, '2.88.160.46');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (72, '2018-09-04 04:01:37', '0000-00-00 00:00:00', 142, '31.166.100.34');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (73, '2018-09-04 04:09:34', '0000-00-00 00:00:00', 142, '51.36.123.197');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (74, '2018-09-04 06:05:48', '0000-00-00 00:00:00', 142, '49.34.187.251');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (75, '2018-09-04 10:28:15', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (76, '2018-09-05 02:24:38', '0000-00-00 00:00:00', 142, '94.99.77.57');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (77, '2018-09-05 08:32:18', '2018-09-05 09:26:48', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (78, '2018-09-05 09:27:49', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (79, '2018-09-05 22:45:19', '0000-00-00 00:00:00', 142, '123.201.68.111');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (80, '2018-09-05 23:43:39', '0000-00-00 00:00:00', 142, '94.99.77.57');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (81, '2018-09-06 09:26:19', '2018-09-06 09:27:19', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (82, '2018-09-06 09:27:27', '2018-09-06 09:30:55', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (83, '2018-09-06 09:31:06', '2018-09-06 09:44:24', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (84, '2018-09-06 09:45:32', '2018-09-06 09:45:48', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (85, '2018-09-06 09:48:49', '2018-09-06 09:51:37', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (86, '2018-09-06 09:51:45', '2018-09-06 09:54:07', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (87, '2018-09-06 09:54:15', '2018-09-06 09:54:22', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (88, '2018-09-06 09:54:32', '2018-09-06 09:58:56', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (89, '2018-09-06 09:59:04', '2018-09-06 09:59:14', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (90, '2018-09-06 09:59:30', '0000-00-00 00:00:00', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (91, '2018-09-06 10:40:56', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (92, '2018-09-06 20:50:32', '0000-00-00 00:00:00', 142, '157.32.170.77');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (93, '2018-09-06 22:22:25', '0000-00-00 00:00:00', 145, '157.32.170.77');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (94, '2018-09-06 23:30:11', '0000-00-00 00:00:00', 142, '157.32.170.77');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (95, '2018-09-07 08:31:05', '2018-09-07 09:53:45', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (96, '2018-09-07 09:53:56', '0000-00-00 00:00:00', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (97, '2018-09-07 21:48:40', '0000-00-00 00:00:00', 142, '157.32.138.109');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (98, '2018-09-08 06:10:16', '0000-00-00 00:00:00', 142, '157.32.154.94');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (99, '2018-09-08 06:10:18', '0000-00-00 00:00:00', 142, '157.32.154.94');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (100, '2018-09-08 06:34:44', '0000-00-00 00:00:00', 142, '157.32.154.94');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (101, '2018-09-08 06:50:16', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (102, '2018-09-08 08:15:38', '0000-00-00 00:00:00', 142, '157.32.154.94');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (103, '2018-09-09 08:11:56', '0000-00-00 00:00:00', 142, '31.166.100.34');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (104, '2018-09-09 08:17:50', '0000-00-00 00:00:00', 142, '31.166.100.34');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (105, '2018-09-09 22:10:27', '0000-00-00 00:00:00', 142, '94.99.77.57');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (106, '2018-09-09 22:26:40', '0000-00-00 00:00:00', 142, '123.201.70.71');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (107, '2018-09-09 23:03:21', '0000-00-00 00:00:00', 142, '123.201.70.71');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (108, '2018-09-10 01:21:57', '0000-00-00 00:00:00', 142, '94.99.78.120');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (109, '2018-09-10 03:21:26', '0000-00-00 00:00:00', 142, '51.36.37.154');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (110, '2018-09-10 22:10:40', '2018-09-10 22:10:46', 142, '203.109.114.227');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (111, '2018-09-10 23:03:11', '0000-00-00 00:00:00', 142, '203.109.114.227');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (112, '2018-09-11 20:14:52', '0000-00-00 00:00:00', 142, '51.36.44.166');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (113, '2018-09-12 10:27:15', '0000-00-00 00:00:00', 142, '51.36.57.181');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (114, '2018-09-13 09:27:05', '0000-00-00 00:00:00', 142, '123.201.70.63');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (115, '2018-09-13 11:36:54', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (116, '2018-09-13 11:40:46', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (117, '2018-09-13 22:28:29', '0000-00-00 00:00:00', 142, '219.91.196.87');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (118, '2018-09-14 03:45:54', '0000-00-00 00:00:00', 142, '219.91.196.87');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (119, '2018-09-14 07:42:50', '0000-00-00 00:00:00', 142, '123.201.67.5');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (120, '2018-09-15 03:22:57', '0000-00-00 00:00:00', 142, '51.39.46.228');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (121, '2018-09-16 11:34:12', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (122, '2018-09-16 11:34:50', '0000-00-00 00:00:00', 145, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (123, '2018-09-16 22:06:43', '2018-09-16 22:13:31', 142, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (124, '2018-09-16 22:13:37', '2018-09-16 22:24:03', 145, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (125, '2018-09-16 22:24:08', '0000-00-00 00:00:00', 142, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (126, '2018-09-16 22:24:08', '0000-00-00 00:00:00', 142, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (127, '2018-09-16 22:27:06', '2018-09-16 22:59:38', 142, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (128, '2018-09-16 22:59:48', '2018-09-16 23:24:41', 145, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (129, '2018-09-16 23:04:06', '0000-00-00 00:00:00', 142, '94.96.103.41');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (130, '2018-09-16 23:24:46', '2018-09-16 23:45:37', 142, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (131, '2018-09-16 23:45:47', '0000-00-00 00:00:00', 145, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (132, '2018-09-16 23:49:19', '0000-00-00 00:00:00', 142, '219.91.190.240');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (133, '2018-09-17 00:57:04', '0000-00-00 00:00:00', 142, '94.96.103.41');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (134, '2018-09-17 01:05:15', '0000-00-00 00:00:00', 145, '94.96.103.41');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (135, '2018-09-17 02:03:55', '0000-00-00 00:00:00', 145, '94.96.103.41');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (136, '2018-09-17 08:35:32', '0000-00-00 00:00:00', 142, '31.166.100.34');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (137, '2018-09-17 08:39:57', '0000-00-00 00:00:00', 142, '123.201.70.55');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (138, '2018-09-18 07:51:33', '0000-00-00 00:00:00', 142, '51.36.60.150');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (139, '2018-09-18 07:52:18', '0000-00-00 00:00:00', 142, '51.36.60.150');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (140, '2018-09-18 11:20:51', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (141, '2018-09-19 00:29:53', '0000-00-00 00:00:00', 142, '123.201.65.38');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (142, '2018-09-19 00:29:54', '0000-00-00 00:00:00', 142, '123.201.65.38');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (143, '2018-09-20 02:17:22', '0000-00-00 00:00:00', 142, '51.39.16.135');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (144, '2018-09-20 07:02:28', '0000-00-00 00:00:00', 142, '219.91.190.13');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (145, '2018-09-20 07:23:36', '0000-00-00 00:00:00', 142, '219.91.190.13');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (146, '2018-09-20 11:17:01', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (147, '2018-09-20 17:06:11', '0000-00-00 00:00:00', 142, '51.36.208.115');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (148, '2018-09-22 05:42:09', '0000-00-00 00:00:00', 142, '157.32.161.212');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (149, '2018-09-22 06:14:48', '0000-00-00 00:00:00', 142, '157.32.161.212');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (150, '2018-09-22 07:37:32', '2018-09-22 07:40:54', 142, '123.201.67.201');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (151, '2018-09-22 07:40:59', '2018-09-22 07:41:56', 145, '123.201.67.201');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (152, '2018-09-22 07:45:19', '0000-00-00 00:00:00', 142, '123.201.67.201');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (153, '2018-09-22 07:45:20', '0000-00-00 00:00:00', 142, '123.201.67.201');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (154, '2018-09-23 03:27:53', '2018-09-23 03:38:10', 142, '203.109.114.108');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (155, '2018-09-23 03:38:13', '0000-00-00 00:00:00', 142, '203.109.114.108');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (156, '2018-09-23 05:48:30', '0000-00-00 00:00:00', 142, '203.109.114.108');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (157, '2018-09-23 09:45:36', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (158, '2018-09-23 10:10:12', '0000-00-00 00:00:00', 142, '51.36.222.181');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (159, '2018-09-23 10:14:07', '0000-00-00 00:00:00', 145, '51.36.222.181');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (160, '2018-09-23 23:06:19', '0000-00-00 00:00:00', 142, '43.241.146.118');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (161, '2018-09-24 06:41:05', '0000-00-00 00:00:00', 142, '51.39.126.46');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (162, '2018-09-24 12:16:48', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (163, '2018-09-24 12:17:07', '2018-09-24 12:20:09', 227, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (164, '2018-09-24 12:20:19', '2018-09-24 12:30:21', 227, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (165, '2018-09-24 12:30:31', '0000-00-00 00:00:00', 227, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (166, '2018-09-25 04:09:15', '0000-00-00 00:00:00', 142, '219.91.190.31');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (167, '2018-09-25 06:51:05', '0000-00-00 00:00:00', 142, '94.96.43.121');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (168, '2018-09-25 09:03:51', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (169, '2018-09-25 09:59:51', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (170, '2018-09-25 10:46:52', '2018-09-25 10:49:20', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (171, '2018-09-25 10:49:27', '0000-00-00 00:00:00', 156, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (172, '2018-09-25 21:34:36', '0000-00-00 00:00:00', 142, '123.201.70.17');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (173, '2018-09-25 22:24:52', '0000-00-00 00:00:00', 142, '94.96.59.77');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (174, '2018-09-26 06:17:22', '0000-00-00 00:00:00', 142, '123.201.65.245');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (175, '2018-09-26 10:52:22', '0000-00-00 00:00:00', 142, '103.226.185.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (176, '2018-09-26 21:05:15', '0000-00-00 00:00:00', 142, '123.201.67.180');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (177, '2018-09-26 22:19:58', '0000-00-00 00:00:00', 142, '188.52.99.228');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (178, '2018-09-26 23:27:01', '0000-00-00 00:00:00', 142, '188.52.99.228');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (179, '2018-09-26 23:34:56', '0000-00-00 00:00:00', 142, '188.52.99.228');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (180, '2018-09-26 23:55:04', '0000-00-00 00:00:00', 142, '123.201.67.180');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (181, '2018-09-26 23:56:23', '0000-00-00 00:00:00', 142, '123.201.67.180');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (182, '2018-09-27 04:22:25', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (183, '2018-09-27 07:26:05', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (184, '2018-09-27 21:12:58', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (185, '2018-09-27 22:11:14', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (186, '2018-09-28 05:20:23', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (187, '2018-10-01 06:43:23', '0000-00-00 00:00:00', 142, '219.91.191.138');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (188, '2018-10-01 21:02:53', '0000-00-00 00:00:00', 142, '123.201.70.28');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (189, '2018-10-01 21:08:26', '0000-00-00 00:00:00', 142, '123.201.70.28');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (190, '2018-10-02 00:11:34', '0000-00-00 00:00:00', 142, '123.201.70.28');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (191, '2018-10-02 01:03:10', '0000-00-00 00:00:00', 142, '123.201.70.28');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (192, '2018-10-02 04:28:33', '0000-00-00 00:00:00', 142, '123.201.70.28');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (193, '2018-10-02 04:28:33', '0000-00-00 00:00:00', 142, '123.201.70.28');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (194, '2018-10-02 08:12:04', '0000-00-00 00:00:00', 142, '123.201.70.154');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (195, '2018-10-02 08:29:02', '2018-10-02 20:59:41', 142, '123.201.70.154');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (196, '2018-10-02 10:41:42', '2018-10-08 23:21:33', 142, '103.226.185.188');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (197, '2018-10-02 11:07:37', '0000-00-00 00:00:00', 142, '103.226.185.188');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (198, '2018-10-02 12:44:18', '0000-00-00 00:00:00', 142, '103.226.185.188');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (199, '2018-10-02 21:20:50', '2018-10-03 10:51:29', 142, '123.201.70.103');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (200, '2018-10-03 03:11:33', '2018-10-03 17:01:22', 142, '123.201.70.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (201, '2018-10-03 04:31:31', '0000-00-00 00:00:00', 145, '123.201.70.187');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (202, '2018-10-03 05:03:02', '0000-00-00 00:00:00', 142, '176.19.205.200');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (203, '2018-10-03 08:34:55', '2018-10-03 21:05:36', 142, '103.226.185.188');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (204, '2018-10-03 08:35:45', '2018-10-03 21:06:31', 145, '103.226.185.188');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (205, '2018-10-03 08:49:28', '0000-00-00 00:00:00', 142, '176.19.205.200');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (206, '2018-10-03 08:52:00', '0000-00-00 00:00:00', 142, '176.19.205.200');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (207, '2018-10-03 10:03:02', '0000-00-00 00:00:00', 145, '128.234.30.59');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (208, '2018-10-03 10:04:30', '0000-00-00 00:00:00', 145, '128.234.30.59');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (209, '2018-10-03 10:54:09', '0000-00-00 00:00:00', 145, '128.234.0.66');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (210, '2018-10-03 11:10:25', '2018-10-04 04:17:16', 145, '128.234.0.66');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (211, '2018-10-03 21:24:43', '2018-10-04 11:15:16', 142, '219.91.196.68');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (212, '2018-10-03 22:20:42', '0000-00-00 00:00:00', 142, '178.86.187.171');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (213, '2018-10-03 22:45:28', '0000-00-00 00:00:00', 142, '219.91.196.68');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (214, '2018-10-03 23:05:05', '0000-00-00 00:00:00', 142, '178.86.187.171');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (215, '2018-10-04 01:05:09', '0000-00-00 00:00:00', 142, '128.234.0.66');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (216, '2018-10-05 09:17:35', '0000-00-00 00:00:00', 142, '51.252.137.53');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (217, '2018-10-06 23:10:09', '0000-00-00 00:00:00', 142, '203.109.114.106');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (218, '2018-10-06 23:43:00', '2018-10-07 14:53:32', 142, '43.241.146.142');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (219, '2018-10-07 02:23:45', '0000-00-00 00:00:00', 142, '203.109.114.106');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (220, '2018-10-07 11:05:01', '0000-00-00 00:00:00', 142, '128.234.71.169');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (221, '2018-10-08 03:39:07', '0000-00-00 00:00:00', 142, '128.234.0.66');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (222, '2018-10-08 05:22:35', '0000-00-00 00:00:00', 142, '188.52.77.167');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (223, '2018-10-08 23:21:38', '2018-10-08 23:23:12', 313, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (224, '2018-10-08 23:23:20', '2018-10-08 23:32:25', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (225, '2018-10-08 23:33:07', '2018-10-09 00:46:39', 313, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (226, '2018-10-09 00:46:45', '2018-10-09 02:05:30', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (227, '2018-10-09 02:05:36', '2018-10-09 02:06:01', 313, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (228, '2018-10-09 02:06:06', '2018-10-09 02:06:30', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (229, '2018-10-09 02:06:39', '2018-10-09 02:07:18', 313, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (230, '2018-10-09 02:07:24', '2018-10-09 02:10:13', 313, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (231, '2018-10-09 02:10:18', '2018-10-09 02:25:08', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (232, '2018-10-09 02:25:14', '0000-00-00 00:00:00', 313, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (233, '2018-10-09 02:48:39', '0000-00-00 00:00:00', 142, '::1');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (234, '2018-10-09 03:40:40', '0000-00-00 00:00:00', 142, '219.91.191.205');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (235, '2018-10-09 06:02:43', '0000-00-00 00:00:00', 142, '123.201.65.152');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (236, '2018-10-09 07:22:34', '0000-00-00 00:00:00', 142, '77.30.3.36');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (237, '2018-10-09 08:14:58', '0000-00-00 00:00:00', 142, '77.30.3.36');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (238, '2018-10-10 06:58:18', '2018-10-10 19:29:46', 142, '203.109.114.183');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (239, '2018-10-10 07:47:02', '2018-10-10 20:17:09', 142, '203.109.114.183');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (240, '2018-10-10 07:47:19', '2018-10-10 20:17:47', 313, '203.109.114.183');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (241, '2018-10-10 07:47:51', '0000-00-00 00:00:00', 142, '203.109.114.183');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (242, '2018-10-11 02:22:31', '0000-00-00 00:00:00', 142, '51.36.240.153');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (243, '2018-10-11 02:48:03', '0000-00-00 00:00:00', 142, '219.91.196.168');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (244, '2018-10-11 03:53:02', '0000-00-00 00:00:00', 142, '219.91.196.168');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (245, '2018-10-11 03:58:24', '2018-10-11 16:33:59', 313, '51.36.240.153');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (246, '2018-10-11 04:04:43', '0000-00-00 00:00:00', 142, '51.36.240.153');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (247, '2018-10-11 05:21:18', '0000-00-00 00:00:00', 142, '188.49.42.88');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (248, '2018-10-13 01:57:53', '0000-00-00 00:00:00', 142, '176.47.120.210');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (249, '2018-10-13 02:43:01', '0000-00-00 00:00:00', 142, '90.148.202.119');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (250, '2018-10-13 04:09:26', '2018-10-13 18:20:43', 142, '5.244.69.105');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (251, '2018-10-13 05:12:14', '0000-00-00 00:00:00', 142, '90.148.202.119');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (252, '2018-10-13 07:20:53', '0000-00-00 00:00:00', 142, '188.49.42.88');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (253, '2018-10-13 08:10:25', '0000-00-00 00:00:00', 142, '188.49.42.88');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (254, '2018-10-13 08:12:33', '0000-00-00 00:00:00', 142, '188.49.42.88');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (255, '2018-10-13 08:50:52', '0000-00-00 00:00:00', 142, '5.244.69.105');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (256, '2018-10-13 08:59:20', '0000-00-00 00:00:00', 142, '5.108.46.235');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (257, '2018-10-13 09:12:44', '0000-00-00 00:00:00', 142, '188.49.42.88');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (258, '2018-10-13 11:02:30', '0000-00-00 00:00:00', 142, '188.49.42.88');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (259, '2018-10-13 11:26:08', '0000-00-00 00:00:00', 142, '5.108.46.235');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (260, '2018-10-14 02:42:42', '0000-00-00 00:00:00', 142, '128.234.56.153');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (261, '2018-10-14 02:55:24', '2018-10-14 17:57:33', 142, '128.234.56.153');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (262, '2018-10-14 05:27:47', '2018-10-14 19:00:00', 324, '128.234.36.40');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (263, '2018-10-14 06:30:19', '2018-10-14 19:12:16', 142, '128.234.22.144');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (264, '2018-10-14 07:06:59', '2018-10-14 19:41:55', 142, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (265, '2018-10-14 07:09:46', '2018-10-14 19:45:43', 142, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (266, '2018-10-14 07:13:43', '2018-10-14 21:14:03', 142, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (267, '2018-10-14 07:13:46', '0000-00-00 00:00:00', 320, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (268, '2018-10-14 07:14:01', '0000-00-00 00:00:00', 323, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (269, '2018-10-14 07:15:52', '2018-10-14 19:47:06', 324, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (270, '2018-10-14 07:17:10', '0000-00-00 00:00:00', 142, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (271, '2018-10-14 07:19:14', '0000-00-00 00:00:00', 142, '128.234.4.190');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (272, '2018-10-15 05:12:26', '0000-00-00 00:00:00', 320, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (273, '2018-10-15 05:13:06', '2018-10-15 19:15:54', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (274, '2018-10-15 05:13:21', '2018-10-15 19:26:08', 323, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (275, '2018-10-15 05:21:25', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (276, '2018-10-15 06:45:56', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (277, '2018-10-15 06:56:25', '0000-00-00 00:00:00', 323, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (278, '2018-10-15 07:55:15', '0000-00-00 00:00:00', 142, '176.18.66.186');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (279, '2018-10-16 00:09:41', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (280, '2018-10-16 00:42:03', '0000-00-00 00:00:00', 142, '176.18.66.186');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (281, '2018-10-16 03:03:17', '0000-00-00 00:00:00', 320, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (282, '2018-10-16 03:23:39', '0000-00-00 00:00:00', 142, '203.109.114.82');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (283, '2018-10-16 03:29:10', '0000-00-00 00:00:00', 323, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (284, '2018-10-16 03:33:50', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (285, '2018-10-16 04:47:39', '0000-00-00 00:00:00', 142, '176.18.66.186');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (286, '2018-10-16 04:55:38', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (287, '2018-10-16 11:16:54', '0000-00-00 00:00:00', 142, '128.234.49.222');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (288, '2018-10-16 22:58:48', '0000-00-00 00:00:00', 142, '123.201.65.62');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (289, '2018-10-17 03:15:48', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (290, '2018-10-17 08:36:45', '0000-00-00 00:00:00', 142, '219.91.191.102');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (291, '2018-10-17 08:39:37', '0000-00-00 00:00:00', 142, '219.91.191.102');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (292, '2018-10-17 23:07:55', '0000-00-00 00:00:00', 142, '176.18.66.186');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (293, '2018-10-18 04:30:45', '0000-00-00 00:00:00', 142, '188.49.25.79');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (294, '2018-10-18 10:40:07', '0000-00-00 00:00:00', 142, '128.234.49.222');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (295, '2018-10-19 07:13:11', '0000-00-00 00:00:00', 142, '5.244.65.112');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (296, '2018-10-19 08:30:14', '2018-10-19 23:19:52', 142, '51.39.65.239');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (297, '2018-10-19 10:39:06', '0000-00-00 00:00:00', 142, '159.0.219.174');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (298, '2018-10-19 10:51:58', '0000-00-00 00:00:00', 142, '51.36.64.168');
INSERT INTO `activity` (`id`, `login_time`, `logout_time`, `user_id`, `ip_address`) VALUES (299, '2018-10-21 00:09:34', '0000-00-00 00:00:00', 142, '128.234.63.142');


#
# TABLE STRUCTURE FOR: add_convert_project
#

DROP TABLE IF EXISTS `add_convert_project`;

CREATE TABLE `add_convert_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_number` varchar(255) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_number` varchar(255) NOT NULL,
  `current_achievement_ratio` varchar(255) NOT NULL,
  `designated_employee_name` varchar(255) NOT NULL,
  `expected_completion_rate` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `case` varchar(255) NOT NULL,
  `task_status` varchar(10) NOT NULL,
  `starting_date` varchar(255) NOT NULL,
  `ending_date` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `ending_time` varchar(255) NOT NULL,
  `reminder_and_alerts` varchar(255) NOT NULL,
  `reminder_and_alerts_type` varchar(255) NOT NULL,
  `list_of_tasks` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `add_convert_project` (`id`, `user_id`, `project_number`, `employee_name`, `employee_number`, `current_achievement_ratio`, `designated_employee_name`, `expected_completion_rate`, `department`, `branch`, `case`, `task_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_tasks`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 0, '9', '999', '8', '8', '8', '88', '8', '8', '', '', '8', '88', '8', '8', '88', '8', '8', '8', '8', '8', '', '2018-09-18 08:31:14', '2018-09-18 08:31:14');
INSERT INTO `add_convert_project` (`id`, `user_id`, `project_number`, `employee_name`, `employee_number`, `current_achievement_ratio`, `designated_employee_name`, `expected_completion_rate`, `department`, `branch`, `case`, `task_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_tasks`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (3, 145, 'hkjhkjhkh', 'kjhkjh', 'hkjhkjhkjhjkh', 'khkjhkjhkjhkjhkjhkjh', 'huhuh', 'uhuihuihuihihi', 'uuihi', 'hiuhui', '', 'active', 'hhuihuih', 'uhihui', 'huihuih', 'iuhiuhuihui', 'huihuihui', 'huihuihui', 'hiuhiuhui', 'huihuih', 'uihuihuihui', 'huihuih', '', '2018-09-18 08:31:14', '2018-09-18 08:31:14');


#
# TABLE STRUCTURE FOR: add_convert_task
#

DROP TABLE IF EXISTS `add_convert_task`;

CREATE TABLE `add_convert_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `case` varchar(255) NOT NULL,
  `task_number` varchar(255) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_number` varchar(255) NOT NULL,
  `current_achievement_ratio` varchar(255) NOT NULL,
  `designated_employee_name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `task_status` varchar(255) NOT NULL,
  `starting_date` varchar(255) NOT NULL,
  `ending_date` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `ending_time` varchar(255) NOT NULL,
  `reminder_and_alerts` varchar(255) NOT NULL,
  `reminder_and_alerts_type` varchar(255) NOT NULL,
  `list_of_tasks` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `expected_completion_rate` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `add_convert_task` (`id`, `user_id`, `case`, `task_number`, `employee_name`, `employee_number`, `current_achievement_ratio`, `designated_employee_name`, `department`, `branch`, `task_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_tasks`, `responsible_employee`, `follow_up_employee`, `expected_completion_rate`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 323, 'active', '500', 'Raya', '5', '70%', 'Sara', 'Legal Writing', 'Makkah', '', '2018-10-16', '2018-10-24', '09:45 pm', '03:30 am', '5', 'Alert', '12345', '2000', '1', '100%', 'SS', '', '2018-10-14 07:42:16', '2018-10-14 07:42:16');


#
# TABLE STRUCTURE FOR: add_project
#

DROP TABLE IF EXISTS `add_project`;

CREATE TABLE `add_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_type` varchar(255) NOT NULL,
  `project_relation` varchar(255) NOT NULL,
  `client` varchar(255) NOT NULL,
  `case` varchar(255) NOT NULL,
  `project` varchar(255) NOT NULL,
  `other` varchar(255) NOT NULL,
  `numbers_of_team_members` varchar(255) NOT NULL,
  `add_group` varchar(255) NOT NULL,
  `project_team_manager` varchar(255) NOT NULL,
  `expected_completion_rate` varchar(255) NOT NULL,
  `current_achievement_ratio` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `project_number` varchar(255) NOT NULL,
  `project_status` varchar(255) NOT NULL,
  `starting_date` varchar(255) NOT NULL,
  `ending_date` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `ending_time` varchar(255) NOT NULL,
  `reminder_and_alerts` varchar(255) NOT NULL,
  `reminder_and_alerts_type` varchar(255) NOT NULL,
  `list_of_project_note` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `session_code` varchar(255) NOT NULL,
  `session_number` varchar(255) NOT NULL,
  `writing_code` varchar(255) NOT NULL,
  `writing_number` varchar(255) NOT NULL,
  `consultation_code` varchar(255) NOT NULL,
  `consultation_number` varchar(255) NOT NULL,
  `visiting_code` varchar(255) NOT NULL,
  `visiting_number` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `add_project` (`id`, `user_id`, `project_name`, `project_type`, `project_relation`, `client`, `case`, `project`, `other`, `numbers_of_team_members`, `add_group`, `project_team_manager`, `expected_completion_rate`, `current_achievement_ratio`, `branch`, `project_number`, `project_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_project_note`, `responsible_employee`, `department`, `follow_up_employee`, `note`, `client_file_number`, `client_name`, `case_code`, `case_number`, `session_code`, `session_number`, `writing_code`, `writing_number`, `consultation_code`, `consultation_number`, `visiting_code`, `visiting_number`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, '56', '6', '654', '6', '', '654', '456', '465', '46', '46', '46', '46', '46', '64', '', '2018-10-11', '2018-10-17', '08:15 am', '03:30 pm', '46', '46', '46', '46', '46', '46', '46', '464', '64', '61', '4', '1313', 'fsdf', '13', '132', '132', '132', '132', '13', '', '2018-10-07 04:56:16', '2018-10-07 04:56:16');


#
# TABLE STRUCTURE FOR: add_task
#

DROP TABLE IF EXISTS `add_task`;

CREATE TABLE `add_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_number` varchar(255) NOT NULL,
  `position_name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `task_type` varchar(255) NOT NULL,
  `task_relation` varchar(255) NOT NULL,
  `client` varchar(255) NOT NULL,
  `case_name` varchar(255) NOT NULL,
  `project` varchar(255) NOT NULL,
  `other` varchar(255) NOT NULL,
  `task_title` varchar(255) NOT NULL,
  `task_number` varchar(255) NOT NULL,
  `task_status` varchar(255) NOT NULL,
  `starting_date` date NOT NULL,
  `ending_date` date NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `ending_time` varchar(255) NOT NULL,
  `reminder_and_alerts` varchar(255) NOT NULL,
  `reminder_and_alerts_type` varchar(255) NOT NULL,
  `list_of_tasks` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `expected_completion_rate` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `session_code` varchar(255) NOT NULL,
  `session_number` varchar(255) NOT NULL,
  `writing_code` varchar(255) NOT NULL,
  `writing_number` varchar(255) NOT NULL,
  `consultation_code` varchar(255) NOT NULL,
  `consultation_number` varchar(255) NOT NULL,
  `visiting_code` varchar(255) NOT NULL,
  `visiting_number` varchar(255) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_number` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `add_task` (`id`, `user_id`, `employee_name`, `employee_number`, `position_name`, `department`, `branch`, `task_type`, `task_relation`, `client`, `case_name`, `project`, `other`, `task_title`, `task_number`, `task_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_tasks`, `responsible_employee`, `follow_up_employee`, `expected_completion_rate`, `note`, `client_file_number`, `client_name`, `case_code`, `case_number`, `session_code`, `session_number`, `writing_code`, `writing_number`, `consultation_code`, `consultation_number`, `visiting_code`, `visiting_number`, `project_name`, `project_number`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 322, 'fs456', '132', 'sdfsdf', '112', '3', '12', '123', '123', '', '123', '132', '123', '132', '', '2018-10-08', '2018-10-31', '04:45 am', '08:15 pm', '132', '132', '312', '312', '132', '132', '132', '132', '132', '132123', '13', '12', '132', '123', '13', '2132', '1', '321', '32', '132', '132', '', '2018-10-14 07:39:34', '2018-10-07 04:56:03');
INSERT INTO `add_task` (`id`, `user_id`, `employee_name`, `employee_number`, `position_name`, `department`, `branch`, `task_type`, `task_relation`, `client`, `case_name`, `project`, `other`, `task_title`, `task_number`, `task_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_tasks`, `responsible_employee`, `follow_up_employee`, `expected_completion_rate`, `note`, `client_file_number`, `client_name`, `case_code`, `case_number`, `session_code`, `session_number`, `writing_code`, `writing_number`, `consultation_code`, `consultation_number`, `visiting_code`, `visiting_number`, `project_name`, `project_number`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 320, 'knjn', 'knjk', 'jkn', 'jnkjn', 'njk', 'njnk', 'jnk', 'kn', 'session_appoinment', 'jndenw', '&#039;;,;,l', ',;,;l,', 'oko', 'active', '2018-10-23', '2018-10-16', '03:45 am', '01:15 am', ';lm', 'l;l;,l;', ',l;,l;,', 'l,gvv', 'vtvg', 'gffg', 'fvf', '202020', 'lkmjkij', 'ijiji', 'mmknj', 'njnjn', 'njnj', 'jibhb', 'bhbyu', 'bhbb', 'hbhb', 'hbhbh', 'hbh', 'iuhuih', '12', '', '2018-10-14 07:40:54', '2018-10-14 07:40:41');
INSERT INTO `add_task` (`id`, `user_id`, `employee_name`, `employee_number`, `position_name`, `department`, `branch`, `task_type`, `task_relation`, `client`, `case_name`, `project`, `other`, `task_title`, `task_number`, `task_status`, `starting_date`, `ending_date`, `start_time`, `ending_time`, `reminder_and_alerts`, `reminder_and_alerts_type`, `list_of_tasks`, `responsible_employee`, `follow_up_employee`, `expected_completion_rate`, `note`, `client_file_number`, `client_name`, `case_code`, `case_number`, `session_code`, `session_number`, `writing_code`, `writing_number`, `consultation_code`, `consultation_number`, `visiting_code`, `visiting_number`, `project_name`, `project_number`, `upload_file`, `updatedate`, `createdate`) VALUES (3, 142, 'mohamed seri', '1248', 'lawer', '112', '3', '12', '123', '123', 'session_appoinment', '123', '132', '123', '132', 'inactive', '2018-10-08', '2018-10-31', '04:45 am', '08:15 pm', '132', '132', '312', '312', '132', '132', '132', '132', '132', '132123', '13', '12', '132', '123', '13', '2132', '1', '321', '32', '132', '132', '', '2018-10-14 08:03:49', '2018-10-14 08:03:49');


#
# TABLE STRUCTURE FOR: appoinment
#

DROP TABLE IF EXISTS `appoinment`;

CREATE TABLE `appoinment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `consenting_type` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `appoinment` (`id`, `name`, `email`, `phone`, `consenting_type`, `date`) VALUES (2, 'hom', 'hom123@gmail.com', 'zddzfgbd', 'paras', '2018-06-14');


#
# TABLE STRUCTURE FOR: archives
#

DROP TABLE IF EXISTS `archives`;

CREATE TABLE `archives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `file_type` bigint(255) NOT NULL,
  `clients` varchar(255) NOT NULL,
  `cases` varchar(255) NOT NULL,
  `procuration` varchar(255) NOT NULL,
  `service_types` varchar(255) NOT NULL,
  `contract` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `project` varchar(255) NOT NULL,
  `task` varchar(255) NOT NULL,
  `others` varchar(255) NOT NULL,
  `file_status` varchar(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_note` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `archives` (`id`, `user_id`, `file_type`, `clients`, `cases`, `procuration`, `service_types`, `contract`, `notes`, `project`, `task`, `others`, `file_status`, `file_title`, `file_note`, `responsible_employee`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, '0', 'Select Clients', 'Select Cases', 'Select Procuration', 'Contracts & Agreements', 'Select Contract Number', 'sdfg', 'Select Project Number', 'Select Task Number', 'fdgh', 'inactive', 'sdf', 'dfggh', 'sdfg', '', '2018-10-07 01:19:41', '2018-10-07 01:19:41');
INSERT INTO `archives` (`id`, `user_id`, `file_type`, `clients`, `cases`, `procuration`, `service_types`, `contract`, `notes`, `project`, `task`, `others`, `file_status`, `file_title`, `file_note`, `responsible_employee`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 142, '0', '260', '1', '2', 'Litigation', 'Select Contract Number', 'fsdf', '1', '1', 'fsdf', '', 'fsdf', 'fsdf', 'fsdf', '?-.-?????-????-???????.doc', '2018-10-19 11:03:10', '2018-10-07 05:04:17');
INSERT INTO `archives` (`id`, `user_id`, `file_type`, `clients`, `cases`, `procuration`, `service_types`, `contract`, `notes`, `project`, `task`, `others`, `file_status`, `file_title`, `file_note`, `responsible_employee`, `upload_file`, `updatedate`, `createdate`) VALUES (3, 142, '0', '259', '1', '2', '', '1', '????????????? ', '1', '1', '?????????', 'inactive', '??????????', '???????', '???????????', '', '2018-10-19 11:01:33', '2018-10-19 11:01:33');


#
# TABLE STRUCTURE FOR: audio
#

DROP TABLE IF EXISTS `audio`;

CREATE TABLE `audio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `audio_id` int(11) NOT NULL,
  `audio_name` varchar(255) NOT NULL,
  `path` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: c_case
#

DROP TABLE IF EXISTS `c_case`;

CREATE TABLE `c_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `total_of_case_number` varchar(255) NOT NULL,
  `service_types` varchar(255) NOT NULL,
  `other_service_types` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` int(11) NOT NULL,
  `case_number` int(11) NOT NULL,
  `case_title` varchar(255) NOT NULL,
  `case_date` date NOT NULL,
  `case_start_date` date NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `opponent_full_name` varchar(255) NOT NULL,
  `opponent_note` text NOT NULL,
  `opponent_phone` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `court_number` varchar(255) NOT NULL,
  `court_address` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `opponent_lawyer` varchar(255) NOT NULL,
  `referral_number` varchar(255) NOT NULL,
  `referral_title` varchar(255) NOT NULL,
  `referral_date` date NOT NULL,
  `verdict_number` varchar(255) NOT NULL,
  `verdict_date` varchar(255) NOT NULL,
  `objection_number` varchar(255) NOT NULL,
  `objection_date` date NOT NULL,
  `case_status` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `upload_file` varchar(255) DEFAULT NULL,
  `active_inactive` int(11) NOT NULL COMMENT '0-active,1-inactive',
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (1, 0, 319, '132783', 'CR', '', '13123', 'albarakati officc', 'aldamam', '213', '', '', '12', 1, 321, '231', '2018-10-10', '2018-10-25', '1321', '32', '1321', '32', '132', '132', '123', '112', '31', '32', '13', '2018-10-11', 'test', '2018-10-31', '321', '2018-10-19', 'active', '3212', '', 0, '2018-10-18 10:50:41', '2018-10-17 06:44:29');
INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (2, 306, 0, 'new', 'CR', '', '22', 'new  ceg', 'klhj', 'h', 'Contracts & Agreements', '', 'ljkh', 0, 0, 'cti', '0000-00-00', '0000-00-00', 'jhj', 'j', 'kgh', 'jkhg', 'hkg', 'hj', 'gjh', 'j', 'g', 'kgjkghk', 'jhhg', '0000-00-00', 'gkgj', '0000-00-00', 'gjk', '0000-00-00', 'inactive', 'g', ' ', 0, '2018-10-10 07:04:01', '2018-10-10 07:04:01');
INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (3, 0, 323, '505050', 'National_id', '', 'E123', 'Mazen Salman', 'makkah', 'efwe', '', '', 'wefwa', 0, 0, 'afe', '2018-10-16', '2018-10-16', 'awef', 'aefae', 'aefaef', 'awefa', 'awefe', 'awefa', 'faewfa', 'awefw', 'awef', 'awef', 'aefae', '2018-10-17', 'awefa', '2018-10-18', 'awef', '2018-10-24', 'active', 'eawfaw', '', 0, '2018-10-14 07:29:52', '2018-10-14 05:25:39');
INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (4, 0, 323, 'bhbhHB', 'CR', '', 'kjnjn', 'nnjjn', 'nnjjn', 'jnjn', 'other', 'bnhjb', 'hbhjb', 0, 0, 'bjhbhj', '2018-10-20', '2018-10-17', '4567890-', 'mjn', 'jinknj', 'kjnkjn', 'jnkjnk', 'jknkjn', 'jkjnk', 'jknknj', 'knjk', 'jnkn', 'jknknj', '2018-10-17', 'k', '2018-10-18', 'kmkjn', '2018-10-17', 'inactive', 'kmdlkmdk', '', 0, '2018-10-14 08:27:43', '2018-10-14 08:26:30');
INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (5, 0, 142, '132783', 'National_id', '', '789', 'albarakati offic', 'aldamam', '123', 'Contracts & Agreements', '', '242435', 234, 678, '098', '2018-10-17', '2018-10-15', '097', 'dd', 'we', 'yu', 'gh', 'oi', 'qw', 'er', 'as', 'df', 'hjk', '2018-10-15', 'hj', '2018-10-15', 'ds', '2018-10-15', 'inactive', 'dffgg', '', 0, '2018-10-14 08:30:35', '2018-10-14 08:30:35');
INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (6, 0, 142, 'bbb', 'National_id', '', 'bbb', 'bbbbbbbbb', 'bbb', 'bbb', '', '', 'bbbb', 0, 0, 'bbb', '2018-10-17', '2018-10-23', 'bbb', 'bbbb', 'bb', '??????', 'bbbb', 'bbbb', 'bbbb', 'bbbb', 'bbbb', 'bbbb', 'bbb', '2018-10-22', 'bbbb', '2018-10-22', 'bbbb', '2018-10-22', 'active', 'bbbbbbb', '', 0, '2018-10-15 06:19:07', '2018-10-15 06:19:07');
INSERT INTO `c_case` (`id`, `customers_id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_case_number`, `service_types`, `other_service_types`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer`, `referral_number`, `referral_title`, `referral_date`, `verdict_number`, `verdict_date`, `objection_number`, `objection_date`, `case_status`, `note`, `upload_file`, `active_inactive`, `updatedate`, `createdate`) VALUES (7, 0, 142, 'new', 'CR', '', '22', 'new  ceg', 'klhj', 'h', 'Contracts & Agreements', '', 'ljkh', 0, 0, 'cti', '0000-00-00', '0000-00-00', 'jhj', 'j', 'kgh', 'jkhg', 'hkg', 'hj', 'gjh', 'j', 'g', 'kgjkghk', 'jhhg', '0000-00-00', 'gkgj', '0000-00-00', 'gjk', '0000-00-00', 'reactivated', 'g', '', 0, '2018-10-18 06:27:53', '2018-10-18 06:27:53');


#
# TABLE STRUCTURE FOR: case_temp
#

DROP TABLE IF EXISTS `case_temp`;

CREATE TABLE `case_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `other_service_types` varchar(255) NOT NULL,
  `other_identification_types` text NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `total_of_case_number` varchar(255) NOT NULL,
  `service_types` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `case_number` int(99) NOT NULL,
  `case_title` varchar(255) NOT NULL,
  `case_date` date NOT NULL,
  `case_start_date` date NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `opponent_full_name` varchar(255) NOT NULL,
  `opponent_note` text NOT NULL,
  `opponent_phone` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `court_number` varchar(255) NOT NULL,
  `court_address` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `opponent_lawyer` varchar(255) NOT NULL,
  `referral_number` varchar(255) NOT NULL,
  `referral_title` varchar(255) NOT NULL,
  `referral_date` date NOT NULL,
  `verdict_number` varchar(255) NOT NULL,
  `verdict_date` date NOT NULL,
  `objection_number` varchar(255) NOT NULL,
  `objection_date` date NOT NULL,
  `case_status` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `add_edit` int(11) NOT NULL COMMENT '0-add,1-edit',
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `discription` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`id`, `user_id`, `title`, `discription`, `image`) VALUES (3, 0, 'Lackmann', 'Lorem Ipsum is simply dummy text ', 'p1.jpg');
INSERT INTO `clients` (`id`, `user_id`, `title`, `discription`, `image`) VALUES (4, 0, 'Elibrary', 'Lorem Ipsum is simply dummy text', 'p2.jpg');
INSERT INTO `clients` (`id`, `user_id`, `title`, `discription`, `image`) VALUES (5, 0, 'Bloobseven', 'Lorem Ipsum is simply dummy text', 'p3.jpg');
INSERT INTO `clients` (`id`, `user_id`, `title`, `discription`, `image`) VALUES (6, 0, 'Name', 'Lorem Ipsum is simply dummy text', 'p4.jpg');


#
# TABLE STRUCTURE FOR: consultation_appoinment
#

DROP TABLE IF EXISTS `consultation_appoinment`;

CREATE TABLE `consultation_appoinment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `total_of_consultation_number` varchar(255) NOT NULL,
  `consultation_number` varchar(255) NOT NULL,
  `consultation_date` date NOT NULL,
  `consultation_time` varchar(255) NOT NULL,
  `consultation_code` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `case_title` varchar(255) NOT NULL,
  `case_date` date NOT NULL,
  `case_start_date` date NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `opponent_full_name` varchar(255) NOT NULL,
  `opponent_note` text NOT NULL,
  `opponent_phone` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `court_number` varchar(255) NOT NULL,
  `court_address` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `opponent_lawyer_name` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `consultation_appoinment` (`id`, `user_id`, `identification_number`, `other_identification_types`, `identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_consultation_number`, `consultation_number`, `consultation_date`, `consultation_time`, `consultation_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, 'sdfsd', '', 'Aqama', '2', '0.', '213', '132', '132', '2018-10-17', '09:30 am', '1321', '1', '231', '2313', '2132', '2018-10-18', '2018-10-18', '132', '123', '123', '123', '123', '123', '1', '123', '123', '315', '316', '123', '', '2018-10-16 05:44:32', '2018-10-16 05:44:32');
INSERT INTO `consultation_appoinment` (`id`, `user_id`, `identification_number`, `other_identification_types`, `identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_consultation_number`, `consultation_number`, `consultation_date`, `consultation_time`, `consultation_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 142, 'sdfsd', '', 'Aqama', '2', '0.', '213', '132', '132', '2018-10-17', '09:30 am', '1321', '1', '231', '2313', '2132', '2018-10-18', '2018-10-18', '132', '123', '123', '123', '123', '123', '1', '123', '123', '315', '316', '123', '', '2018-10-16 05:46:06', '2018-10-16 05:46:06');
INSERT INTO `consultation_appoinment` (`id`, `user_id`, `identification_number`, `other_identification_types`, `identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_consultation_number`, `consultation_number`, `consultation_date`, `consultation_time`, `consultation_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (3, 142, 'sdfsd', '', 'Aqama', '2', '0.', '213', '132', '132', '2018-10-17', '09:30 am', '1321', '1', '231', '2313', '2132', '2018-10-18', '2018-10-18', '132', '123', '123', '123', '123', '123', '1', '123', '123', '315', '316', '123', '', '2018-10-16 05:46:34', '2018-10-16 05:46:34');
INSERT INTO `consultation_appoinment` (`id`, `user_id`, `identification_number`, `other_identification_types`, `identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_consultation_number`, `consultation_number`, `consultation_date`, `consultation_time`, `consultation_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (4, 142, 'sdfsd', '', 'Aqama', '2', '0.', '213', '132', '132', '2018-10-17', '09:30 am', '1321', '1', '231', '2313', '2132', '2018-10-18', '2018-10-18', '132', '123', '123', '123', '123', '123', '1', '123', '123', '315', '316', '123', '', '2018-10-16 05:48:24', '2018-10-16 05:48:24');
INSERT INTO `consultation_appoinment` (`id`, `user_id`, `identification_number`, `other_identification_types`, `identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_consultation_number`, `consultation_number`, `consultation_date`, `consultation_time`, `consultation_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (5, 142, '1', '', 'CR', '2', '011', '32', '123', '132', '2018-10-18', '04:30 pm', '312', '132', '123', '123', '123', '2018-10-24', '2018-11-07', '132', '132', '12', '213', '123', '132', '123', '213', '123', '317', '315', '123', '', '2018-10-16 05:50:41', '2018-10-16 05:50:41');
INSERT INTO `consultation_appoinment` (`id`, `user_id`, `identification_number`, `other_identification_types`, `identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_consultation_number`, `consultation_number`, `consultation_date`, `consultation_time`, `consultation_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (6, 142, '111', '', 'CR', '2', '2', '2', '2', '2', '2018-11-01', '02:30 pm', '2', '2', '2', '2', '2', '2018-10-18', '2018-10-26', '22', '2', '2', '2', '2', '2323', '22', '2', '2', '316', '316', '2', '', '2018-10-16 06:09:53', '2018-10-16 06:09:53');


#
# TABLE STRUCTURE FOR: contact_us
#

DROP TABLE IF EXISTS `contact_us`;

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `subject`, `message`, `created`) VALUES (1, 'paras', 'raiyani123@gmail.com', '6543219875', 'nothiung', 'okkk', '2018-06-29 21:53:24');
INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `subject`, `message`, `created`) VALUES (2, 'test', 'modhavadiya55@gmail.com', '4234234', 'adsas', 'dasdas', '2018-09-18 03:37:55');
INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `subject`, `message`, `created`) VALUES (3, '', 'dsa@asdda', '', '', '', '2018-09-18 03:47:17');
INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `subject`, `message`, `created`) VALUES (4, '????? ', 'bashayer.alshanbari@gmail.com', '0563112797', '????', '????????', '2018-10-02 02:19:34');


#
# TABLE STRUCTURE FOR: contract
#

DROP TABLE IF EXISTS `contract`;

CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_start_date` varchar(20) NOT NULL,
  `ending_contract_date` varchar(20) NOT NULL,
  `contract_number` varchar(255) NOT NULL,
  `contract_type` varchar(255) NOT NULL,
  `service_types` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `other_service_types` varchar(255) NOT NULL,
  `number_of_cases` varchar(255) NOT NULL,
  `legal_consultation` varchar(255) NOT NULL,
  `contract_price` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `case_status` varchar(50) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `contract_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `contract` (`id`, `contract_start_date`, `ending_contract_date`, `contract_number`, `contract_type`, `service_types`, `client_name`, `client_file_number`, `identification_number`, `identification_types`, `other_identification_types`, `other_service_types`, `number_of_cases`, `legal_consultation`, `contract_price`, `notes`, `responsible_employee`, `case_status`, `file_type`, `file_title`, `contract_file`, `updatedate`, `createdate`) VALUES (1, 'h', 'jtgj', 'jghj', 'jghj', 'Contracts & Agreements', 'jghjj', 'jghjgj', 'jghjg', 'National_id', '', '', 'jghj', 'ghjghj', 'jghj', 'gjgj', 'jgh', 'inactive', 'jghj', 'jghj', '', '2018-10-07 00:14:05', '2018-10-07 00:14:05');
INSERT INTO `contract` (`id`, `contract_start_date`, `ending_contract_date`, `contract_number`, `contract_type`, `service_types`, `client_name`, `client_file_number`, `identification_number`, `identification_types`, `other_identification_types`, `other_service_types`, `number_of_cases`, `legal_consultation`, `contract_price`, `notes`, `responsible_employee`, `case_status`, `file_type`, `file_title`, `contract_file`, `updatedate`, `createdate`) VALUES (2, '2018-10-19', '2019-11-28', '50005', 'SSC', 'Contracts & Agreements', 'Saleh Salman', 'B123', '202020', 'National_id', '', '', '7', '8', '4000', 'CONTRACT OF S', '201', 'active', '', '', '', '2018-10-13 09:40:30', '2018-10-13 09:40:30');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `customers_id` varchar(255) NOT NULL,
  `type_of_customer` varchar(255) NOT NULL,
  `other_type_of_customer` varchar(255) NOT NULL,
  `client_status` varchar(255) NOT NULL,
  `other_client_status` varchar(255) NOT NULL,
  `service_types` varchar(255) NOT NULL,
  `other_service_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `number_of_customer` varchar(255) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `employeer_name` varchar(255) NOT NULL,
  `work_address` varchar(255) NOT NULL,
  `full_work_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street_name` varchar(255) NOT NULL,
  `building_number` varchar(255) NOT NULL,
  `full_client_address` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `po_box` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `unit_number` varchar(255) NOT NULL,
  `extra_number` varchar(255) NOT NULL,
  `contact_type` varchar(255) NOT NULL,
  `other_contact_type` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `customer_image` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (7, 318, '309', '', '', '', '', 'Contracts & Agreements', '', '', '', '', '', '', '', '', '', 'omar alshareef', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018-10-19 10:48:23', '2018-10-09 01:00:57');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (11, 142, '', 'Individuals', '', 'active', '', 'Contracts & Agreements', '', 'A123', 'Makkah', 'raya alharbi', '1', '27', '101010', 'National_id', '', 'Khalid Salman', 'Saudi', 'Male', 'engineer', 'KS', 'Al-Awail', 'Makkah-Alawali', 'Makkah', 'Al-awali', '205', '205 Alawali Makkah ', 'Makkah', 'Saudi Arabia', 'SPO', '1000', '205-A', '2055', 'Mobile', '', '50505050', '', 'The information of KS', '2018-10-15 06:46:02', '2018-10-13 05:14:20');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (12, 319, '', 'a_company', '', 'active', '', 'Consultancy & Legal Studies', '', 'B123', 'Makkah', '201', '1', '28', '202020', 'CR', '', 'Saleh Salman', 'Saudi', 'Male', 'Manager', 'SS', 'Al-Awali', 'Makkah-Alawali', 'Makkah', 'Al-awali', '206', 'Alawali-Makkah', 'Makkah', 'Saudi Arabia', 'SPO', '2020', '206-A', '2050', 'Mobile', '', '50505060', '', 'The information of SS', '2018-10-14 07:29:17', '2018-10-13 05:23:45');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (13, 323, '', 'Establishment', '', 'inactive', '', 'Commercial Business', '', 'C123', 'Jeddah', '202', '1', '29', '303030', 'CR', '', 'Ahmad Salman', 'Saudi', 'Male', 'accountant', 'AS', 'Al-Awali', 'Alawali-Jeddah', 'Jeddah', 'Alawali', '207', 'Alawali-Jeddah', 'Makkah', 'Saudi Arabia', 'SPO', '5000', '207-A', '2060', 'Mobile', '', '50505070', '', 'The information of AS', '2018-10-14 07:21:40', '2018-10-13 05:30:06');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (14, 323, '', 'Governments', '', 'active', '', 'Commercial Business', '', 'D123', 'Riyadh', '203', '1', '30', '404040', 'National_id', '', 'Fahad Salman', 'Saudi', 'Male', 'engineer', 'FS', 'Al-Awali', 'Alawali-Riyadh', 'Riyadh', 'Alawali', '208', 'Alawali-Riyadh', 'Al-Riyadh', 'Saudi Arabia', 'SPO', '3000', '208-A', '2070', 'Mobile', '', '50505080', '', 'The information of FS', '2018-10-15 06:14:34', '2018-10-13 05:42:37');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (15, 142, '', 'organization', '', 'active', '', 'Litigation', '', 'E123', 'Jeddah', '200', '2', '31', '505050', 'National_id', '', 'Mazen Salman', 'Saudi', '', 'Supervisor', 'MS', 'Alawali', 'Alawali-Jeddah', 'Jeddah', 'Alawali', '209', 'Alawali-Jeddah', 'Makkah', 'Saudi Arabia', 'SPO', '4000', '209-A', '2080', 'Home_Phone', '', '50505090', '', 'The information of MS', '2018-10-13 05:50:16', '2018-10-13 05:50:16');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (16, 322, '', 'a_company', '', 'active', '', 'Litigation', '', '20', 'Makkah', 'hatem mubarak albarakati', 'hatem mubarak albarakati', '1', '4031090600', 'CR', '', 'Trans-Kingdom National Development Co. Ltd.', 'Saudi Arabia', 'Female', 'General Contractor', 'Trans Kingdom Company', 'Makkah', 'Alnasim Al Abbas Street', 'Makkah', 'Alnasim Al Abbas Street', '7388', 'Alnasim Al Abbas Street', 'South of Makkah', 'Makkah', '24245', '7388', '33', '24245', 'Business_Phone', '', '0125566660', 'Image 2018-10-13 at 6.44.24 PM.jpeg', 'Test', '2018-10-14 07:41:01', '2018-10-13 10:50:04');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (18, 323, '', 'Individuals', '', 'active', '', 'Litigation', '', '21', 'makkah', 'hatm mubarak albarakati', 'hatm mubarak albarakati', '1', '1099869863', 'National_id', '', 'mahmoud karim bernawi', 'saudi', 'Male', 'municipal controller', 'ministry of municipality and rural ', 'municipality of umrah sub', 'municipality of umrah sub', 'makkah', 'the medina road', '2207', 'Makkah,the medina road,', 'north', 'makkah', '24215', '10607', '5026', '24215', 'Mobile', '', '056999018', '', 'test', '2018-10-14 07:17:57', '2018-10-13 11:29:15');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (19, 323, '0', '', '', '', '', '', '', 'E123', 'makkah', '', '', '', '505050', 'National_id', '', 'Mazen Salman', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'awef', '', '', '2018-10-14 07:19:06', '2018-10-14 05:25:47');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (20, 323, '', 'Individuals', '', 'active', '', 'Commercial Business', '', '1', 'Makkah', '203', '2', '29', '202020', 'CR', '', 'SALEM', 'Saudi', 'Male', 'engineer', 'TT', 'MAKKAH', 'ALAWALI', 'MAKKAH', 'ALAWALI', '3333', 'MAKKAH', 'Makkah', 'SAUDI ARABIA', 'SPO', '4444', '206-A', '2060', 'Mobile', '', '5050506050505060', '', 'TTTTT', '2018-10-15 05:55:10', '2018-10-15 05:55:10');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (21, 323, '', 'organization', '', 'inactive', '', 'Consultancy & Legal Studies', '', 'D123', 'Makkah', '202', '2', '29', '303030', 'National_id', '', 'ALI', 'Saudi', 'Male', 'Supervisor', 'RS', 'MAKKAH', 'MAKKAH-ALAWALI', 'MAKKAH', 'ALAWALI', '209', 'MAKKAH-SAUDI', 'MAKKAH', 'SAUDI', 'SPO', '3333', '208-A', '4', 'Business_Phone', '', '50505080', '', 'RRRR', '2018-10-15 05:59:15', '2018-10-15 05:59:15');
INSERT INTO `customers` (`id`, `user_id`, `customers_id`, `type_of_customer`, `other_type_of_customer`, `client_status`, `other_client_status`, `service_types`, `other_service_types`, `client_file_number`, `branch`, `responsible_employee`, `follow_up_employee`, `number_of_customer`, `identification_number`, `identification_types`, `other_identification_types`, `client_name`, `nationality`, `gender`, `occupation`, `employeer_name`, `work_address`, `full_work_address`, `city`, `street_name`, `building_number`, `full_client_address`, `district`, `country`, `po_box`, `postal_code`, `unit_number`, `extra_number`, `contact_type`, `other_contact_type`, `contact_number`, `customer_image`, `notes`, `updatedate`, `createdate`) VALUES (22, 142, '', 'a_company', '', 'inactive', '', 'Contracts & Agreements', '', 'BA', 'Makkah', '  b', '  b', 'b', 'b', 'CR', '', '     b', 'b', 'Male', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b    ', 'b', 'b', 'b', 'b', 'b', 'b', 'Business_Phone', '', 'bbbb', '', '     bbb', '2018-10-16 11:46:30', '2018-10-16 11:46:30');


#
# TABLE STRUCTURE FOR: customers_temp
#

DROP TABLE IF EXISTS `customers_temp`;

CREATE TABLE `customers_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `type_of_customer` varchar(255) NOT NULL,
  `client_status` varchar(255) NOT NULL,
  `service_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `number_of_customer` varchar(255) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `employeer_name` varchar(255) NOT NULL,
  `work_address` varchar(255) NOT NULL,
  `full_work_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street_name` varchar(255) NOT NULL,
  `building_number` varchar(255) NOT NULL,
  `full_client_address` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `po_box` varchar(255) NOT NULL,
  `other_client_status` varchar(255) NOT NULL,
  `other_service_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `other_contact_type` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `other_type_of_customer` varchar(255) NOT NULL,
  `unit_number` varchar(255) NOT NULL,
  `extra_number` varchar(255) NOT NULL,
  `contact_type` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `customer_image` varchar(255) NOT NULL,
  `add_edit` int(11) NOT NULL COMMENT '0-add,1-edit',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: department
#

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `d_name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (1, 'Secretarial', '2018-05-05 23:13:43');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (2, 'Lawyers', '2018-05-05 23:13:43');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (3, 'Consultants', '2018-05-05 23:14:01');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (4, 'Partners', '2018-05-05 23:14:01');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (5, 'Management', '2018-05-05 23:14:15');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (6, 'director', '2018-05-05 23:14:15');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (7, 'finance', '2018-05-05 23:14:34');
INSERT INTO `department` (`id`, `d_name`, `created`) VALUES (8, 'Administration', '2018-05-05 23:14:34');


#
# TABLE STRUCTURE FOR: document
#

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `case_number` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (1, '2Q7Lv.jpg', 263, 0, 1, '2018-10-03 23:38:15');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (2, 'hFzeR.jpg', 306, 0, 1, '2018-10-04 04:44:26');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (3, '5rWEn.jpg', 307, 0, 4, '2018-10-06 23:11:37');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (4, 'M1bhs.pdf', 0, 142, 4, '2018-10-14 08:26:27');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (5, 'TYcPG.rar', 0, 142, 4, '2018-10-14 08:26:27');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (6, '3wkZr.png', 306, 0, 6, '2018-10-15 06:01:02');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (7, 'FxlhX.png', 306, 0, 6, '2018-10-15 06:13:45');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (8, 'APFyH.png', 306, 0, 6, '2018-10-15 06:14:01');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (9, 'iAs3E.png', 306, 0, 6, '2018-10-15 06:14:19');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (10, 'UpxrO.png', 306, 0, 6, '2018-10-15 06:15:29');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (11, 'rIGD5.pdf', 0, 142, 6, '2018-10-15 06:18:23');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (12, '15BVE.pdf', 0, 142, 6, '2018-10-15 06:18:58');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (13, 'WKtF3.exe', 0, 142, 6, '2018-10-15 06:46:35');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (14, 'OGLxa.pdf', 0, 142, 7, '2018-10-15 06:47:24');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (15, 'KtsA4.pdf', 0, 142, 7, '2018-10-15 06:47:28');
INSERT INTO `document` (`id`, `name`, `customer_id`, `user_id`, `case_number`, `created`) VALUES (16, 'VAGzT.pdf', 0, 142, 7, '2018-10-15 06:47:33');


#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `other_employee_type` varchar(255) NOT NULL,
  `other_department_id` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `bank_accounts` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `monthly_salary` varchar(255) NOT NULL,
  `contract_file` varchar(255) NOT NULL,
  `governmental_id_file` varchar(255) NOT NULL,
  `certificate_file` varchar(255) NOT NULL,
  `employees_photo` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (1, 313, '3123123', 'temporary', '1', '', '', 'test', 'ffsdf', 'dsf', '121', '', '', '', '', '2018-10-08 23:21:27', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (2, 315, '3000', 'longterm', '1', '', '', 'makkah', '68202004308000', 'alinma', '3000', '???????.pdf', '???????.pdf', '???????.pdf', '???????.pdf', '2018-10-13 09:45:24', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (3, 316, 'SR', 'longterm', '5', '', '', 'Mecca', 'SA1234567898765432112345', 'Al Rajhi', '25000', '', '', '', '', '2018-10-13 09:54:00', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (4, 317, '3000', 'longterm', '1', '', '', 'Jeddah', '13347104006103', 'alahli', '3000', 'hamed.pdf', 'hamed.pdf', 'hamed.pdf', 'hamed.pdf', '2018-10-13 10:03:54', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (5, 318, 'SR', 'longterm', '5', '', '', 'jadda', 'SA1234567898765439865413', 'Al Rajhi', '20000', '', '', '', '', '2018-10-13 10:10:46', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (6, 319, 'SR', 'longterm', '5', '', '', 'Riyadh', 'SA987654321876543986541398765', 'Al Ahly', '15000', '', '', '', '', '2018-10-13 10:16:26', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (7, 320, 'SR', 'longterm', '6', '', '', 'Mecca', 'SA1234567898766666112345', 'Alinma', '10000', '', '', '', 'CHMT7947.JPG', '2018-10-13 10:22:37', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (8, 321, '3000', 'temporary', '1', '', '', 'Riyadh', '68202004308000', 'alinma', '3000', 'Image 2018-10-13 at 8.19.25 PM.jpeg', 'Image 2018-10-13 at 8.19.25 PM.jpeg', 'Image 2018-10-13 at 8.19.25 PM.jpeg', 'Image 2018-10-13 at 8.19.25 PM.jpeg', '2018-10-13 10:38:31', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (9, 322, 'SR', 'longterm', '2', '', '', 'Mecca', 'SA1234567898765439869993', 'Al Rajhi', '5000', '', '', '', '', '2018-10-13 10:42:27', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (10, 323, '100', 'longterm', '2', '', '', 'makkah', '51515', 'ahli', '2000', '?????? ?????? ?????? ??????.jpeg', '?????? ?????? ?????? ??????.jpeg', '?????? ?????? ?????? ??????.jpeg', '?????? ?????? ?????? ??????.jpeg', '2018-10-14 03:58:50', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (11, 324, '200', 'temporary', '3', '', '', 'makkah', '7578587528787', 'ahli', '2000', '2.png', '3?????????.JPG', '4.png', '3?????????.JPG', '2018-10-14 04:03:14', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (12, 325, '100', 'longterm', '3', '', '', 'makkah', '1465165111', 'ahli', '2000', '', '', '', '', '2018-10-14 04:06:10', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (13, 326, '100', 'temporary', '3', '', '', 'makkah', '7578587528787', 'ahli', '2000', '', '', '', '', '2018-10-14 04:14:24', '0000-00-00 00:00:00');
INSERT INTO `employee` (`id`, `user_id`, `amount`, `employee_type`, `department_id`, `other_employee_type`, `other_department_id`, `branch`, `bank_accounts`, `bank_name`, `monthly_salary`, `contract_file`, `governmental_id_file`, `certificate_file`, `employees_photo`, `created`, `modified`) VALUES (14, 327, '100', 'longterm', '3', '', '', 'Cairo', '7578587528787', 'ahli', '2000', 'attar11.jpg', 'alhussam9.png', 'alhussam9.png', 'attar11.jpg', '2018-10-14 04:16:53', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: employee_temp
#

DROP TABLE IF EXISTS `employee_temp`;

CREATE TABLE `employee_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `bank_accounts` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `contract_date` varchar(255) NOT NULL,
  `other_employee_type` varchar(255) NOT NULL,
  `other_department_id` varchar(255) NOT NULL,
  `monthly_salary` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `contract_file` varchar(255) NOT NULL,
  `governmental_id_file` varchar(255) NOT NULL,
  `certificate_file` varchar(255) NOT NULL,
  `employees_photo` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0--in active,1--active',
  `add_edit` int(11) NOT NULL COMMENT '0--add,1--edit',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: hr
#

DROP TABLE IF EXISTS `hr`;

CREATE TABLE `hr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `client_full_name` varchar(255) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `main_mobile_number` varchar(255) NOT NULL,
  `other_mobile_number` varchar(255) NOT NULL,
  `employee_bank_name` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `monthly_salary` varchar(255) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `other_employee_type` varchar(255) NOT NULL,
  `employee_positions` varchar(255) NOT NULL,
  `job_position_name` varchar(255) NOT NULL,
  `contract_number` varchar(255) NOT NULL,
  `case_status` varchar(255) NOT NULL,
  `date_of_starting_work` varchar(255) NOT NULL,
  `contract_ending_date` varchar(11) NOT NULL,
  `employee_fail_number` varchar(11) NOT NULL,
  `department` varchar(11) NOT NULL,
  `branch` varchar(11) NOT NULL,
  `number_of_annual_vacation_date` varchar(11) NOT NULL,
  `expiations_date` varchar(11) NOT NULL,
  `number_of_working_days` varchar(11) NOT NULL,
  `number_of_sick_live_days` varchar(11) NOT NULL,
  `number_of_emergence_days` varchar(11) NOT NULL,
  `file_type` varchar(11) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `hr` (`id`, `userid`, `client_full_name`, `identification_number`, `identification_types`, `other_identification_types`, `dob`, `address`, `main_mobile_number`, `other_mobile_number`, `employee_bank_name`, `iban`, `monthly_salary`, `employee_type`, `other_employee_type`, `employee_positions`, `job_position_name`, `contract_number`, `case_status`, `date_of_starting_work`, `contract_ending_date`, `employee_fail_number`, `department`, `branch`, `number_of_annual_vacation_date`, `expiations_date`, `number_of_working_days`, `number_of_sick_live_days`, `number_of_emergence_days`, `file_type`, `file_title`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, 'dfsf', '', 'CR', '', '', '', '', '', '', '', '', 'temporary', '', '', '', '', 'active', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018-10-07 04:41:12', '2018-10-07 04:41:12');


#
# TABLE STRUCTURE FOR: job
#

DROP TABLE IF EXISTS `job`;

CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `job` (`id`, `title`, `description`, `image`, `createdate`) VALUES (1, 'job 1', 'rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been thevrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the\r\nrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been thevrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the\r\nrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been thevrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the\r\nrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been thevrem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the\r\n', 'Lighthouse.jpg', '2018-10-01 04:14:12');


#
# TABLE STRUCTURE FOR: judge_master
#

DROP TABLE IF EXISTS `judge_master`;

CREATE TABLE `judge_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judge_name` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `place` varchar(2555) NOT NULL,
  `city` varchar(255) NOT NULL,
  `branch_office` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `added_id` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL COMMENT '0-not delete,1-delete',
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `judge_master` (`id`, `judge_name`, `court_name`, `place`, `city`, `branch_office`, `note`, `added_id`, `is_delete`, `updatedate`, `createdate`) VALUES (3, 'paras', 'kai nahi', 'e to', 'em j', '', '', 142, 0, '2018-08-18 01:42:06', '2018-08-18 01:42:06');
INSERT INTO `judge_master` (`id`, `judge_name`, `court_name`, `place`, `city`, `branch_office`, `note`, `added_id`, `is_delete`, `updatedate`, `createdate`) VALUES (4, 'hom me', 'high court', 'mvdi', 'rjy', '', '', 145, 0, '2018-08-18 01:42:06', '2018-08-18 01:42:06');
INSERT INTO `judge_master` (`id`, `judge_name`, `court_name`, `place`, `city`, `branch_office`, `note`, `added_id`, `is_delete`, `updatedate`, `createdate`) VALUES (5, 'test', 'test', 'tst', 'rtt', '', '232', 142, 0, '2018-08-27 21:54:48', '2018-08-27 21:54:48');
INSERT INTO `judge_master` (`id`, `judge_name`, `court_name`, `place`, `city`, `branch_office`, `note`, `added_id`, `is_delete`, `updatedate`, `createdate`) VALUES (6, '123', '123', '31231', '312', '31', '312313', 142, 0, '2018-08-27 21:59:30', '2018-08-27 21:59:30');
INSERT INTO `judge_master` (`id`, `judge_name`, `court_name`, `place`, `city`, `branch_office`, `note`, `added_id`, `is_delete`, `updatedate`, `createdate`) VALUES (7, 'gdfgg', 'ggfgg', 'sgfs', 'gfd', 'gdfgfd', 'gdfgdf', 142, 0, '2018-10-07 00:03:36', '2018-10-07 00:03:26');
INSERT INTO `judge_master` (`id`, `judge_name`, `court_name`, `place`, `city`, `branch_office`, `note`, `added_id`, `is_delete`, `updatedate`, `createdate`) VALUES (8, 'Majed', '', '', '', '', '', 142, 1, '2018-10-07 00:19:54', '2018-10-07 00:04:19');


#
# TABLE STRUCTURE FOR: news
#

DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `discription` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `news` (`id`, `title`, `discription`, `image`, `date`) VALUES (8, 'Lorem Ipsum is simply dummy text', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'launch.png', '2018-07-24');
INSERT INTO `news` (`id`, `title`, `discription`, `image`, `date`) VALUES (9, 'Lorem Ipsum is simply dummy text', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'launch.png', '2018-08-31');
INSERT INTO `news` (`id`, `title`, `discription`, `image`, `date`) VALUES (10, 'test test', 'ggggcndf,mvmdcfbxfgvjtbmyjh', 'gavel-3577258__480.jpg', '0000-00-00');


#
# TABLE STRUCTURE FOR: note
#

DROP TABLE IF EXISTS `note`;

CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `note_id` int(11) NOT NULL,
  `added_id` int(11) NOT NULL,
  `discription` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `note` (`id`, `user_id`, `name`, `note_id`, `added_id`, `discription`, `date`) VALUES (2, 142, 'Mohamed Daoud', 2, 142, 'okk', '2018-07-11');
INSERT INTO `note` (`id`, `user_id`, `name`, `note_id`, `added_id`, `discription`, `date`) VALUES (3, 142, 'Raiyani paras', 31, 142, 'nothing 123', '2018-07-12');
INSERT INTO `note` (`id`, `user_id`, `name`, `note_id`, `added_id`, `discription`, `date`) VALUES (6, 154, 'shailesh vekariya ', 4, 142, 'hii friens', '2018-07-11');
INSERT INTO `note` (`id`, `user_id`, `name`, `note_id`, `added_id`, `discription`, `date`) VALUES (7, 2, 'aaa', 7, 142, '121323', '2018-08-14');
INSERT INTO `note` (`id`, `user_id`, `name`, `note_id`, `added_id`, `discription`, `date`) VALUES (8, 35, '1', 8, 142, 'q434', '0000-00-00');
INSERT INTO `note` (`id`, `user_id`, `name`, `note_id`, `added_id`, `discription`, `date`) VALUES (10, 0, 'sara', 9, 320, '', '2018-10-14');


#
# TABLE STRUCTURE FOR: notification
#

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `notification_type` varchar(255) NOT NULL,
  `status_type` varchar(255) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (1, 306, 0, 2, 0, 'case', 'add', '2018-10-10 07:04:00');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (2, 0, 0, 1, 0, 'case', 'approve', '2018-10-11 02:23:52');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (3, 0, 313, 1, 0, 'case', 'assign', '2018-10-11 02:46:27');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (4, 263, 313, 1, 0, 'customer', 'assign', '2018-10-11 03:52:40');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (5, 306, 0, 2, 0, 'case', 'approve', '2018-10-11 03:54:31');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (6, 0, 313, 1, 0, 'case', 'assign', '2018-10-11 03:57:10');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (7, 263, 313, 1, 0, 'customer', 'assign', '2018-10-11 05:25:42');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (8, 0, 313, 11, 0, 'customer', 'assign', '2018-10-13 08:59:03');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (9, 0, 319, 11, 0, 'customer', 'assign', '2018-10-14 02:47:36');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (10, 0, 0, 3, 0, 'case', 'add', '2018-10-14 05:25:39');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (11, 0, 0, 3, 0, 'case', 'approve', '2018-10-14 05:25:47');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (12, 0, 324, 3, 0, 'case', 'assign', '2018-10-14 05:28:31');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (13, 0, 322, 19, 0, 'customer', 'assign', '2018-10-14 07:17:53');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (14, 0, 323, 18, 0, 'customer', 'assign', '2018-10-14 07:17:57');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (15, 0, 323, 19, 0, 'customer', 'assign', '2018-10-14 07:19:06');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (16, 309, 320, 7, 0, 'customer', 'assign', '2018-10-14 07:20:39');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (17, 0, 323, 13, 0, 'customer', 'assign', '2018-10-14 07:21:40');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (18, 309, 322, 7, 0, 'customer', 'assign', '2018-10-14 07:22:58');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (19, 309, 323, 7, 0, 'customer', 'assign', '2018-10-14 07:23:07');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (20, 0, 322, 11, 0, 'customer', 'assign', '2018-10-14 07:25:25');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (21, 0, 323, 11, 0, 'customer', 'assign', '2018-10-14 07:25:34');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (22, 0, 320, 3, 0, 'case', 'assign', '2018-10-14 07:27:25');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (23, 0, 321, 11, 0, 'customer', 'assign', '2018-10-14 07:27:59');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (24, 0, 319, 12, 0, 'customer', 'assign', '2018-10-14 07:29:17');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (25, 0, 323, 3, 0, 'case', 'assign', '2018-10-14 07:29:52');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (26, 0, 0, 1, 0, 'case', 'change-approve ', '2018-10-14 07:34:23');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (27, 0, 322, 16, 0, 'customer', 'assign', '2018-10-14 07:41:01');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (28, 0, 0, 4, 0, 'case', 'add', '2018-10-14 08:26:30');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (29, 0, 0, 4, 0, 'case', 'approve', '2018-10-14 08:26:38');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (30, 0, 323, 4, 0, 'case', 'assign', '2018-10-14 08:27:43');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (31, 0, 0, 5, 0, 'case', 'add', '2018-10-14 08:30:34');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (32, 0, 0, 5, 0, 'case', 'approve', '2018-10-14 08:31:07');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (33, 306, 0, 6, 0, 'case', 'file', '2018-10-15 06:01:02');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (34, 0, 323, 11, 0, 'customer', 'assign', '2018-10-15 06:12:52');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (35, 306, 0, 6, 0, 'case', 'file', '2018-10-15 06:13:45');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (36, 306, 0, 6, 0, 'case', 'file', '2018-10-15 06:14:01');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (37, 306, 0, 6, 0, 'case', 'file', '2018-10-15 06:14:19');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (38, 0, 323, 14, 0, 'customer', 'assign', '2018-10-15 06:14:34');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (39, 306, 0, 6, 0, 'case', 'file', '2018-10-15 06:15:29');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (40, 0, 0, 6, 0, 'case', 'add', '2018-10-15 06:19:06');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (41, 0, 0, 6, 0, 'case', 'approve', '2018-10-15 06:20:07');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (42, 0, 142, 6, 0, 'case', 'file', '2018-10-15 06:46:35');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (43, 306, 0, 2, 0, 'writings_appoinment', 'add', '2018-10-16 03:24:34');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (44, 309, 316, 7, 0, 'customer', 'assign', '2018-10-16 05:04:48');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (45, 309, 316, 7, 0, 'customer', 'assign', '2018-10-16 05:15:24');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (46, 306, 0, 2, 0, 'session_appoinment', 'add', '2018-10-16 05:20:38');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (47, 306, 0, 2, 4, 'visiting_appoinment', 'add', '2018-10-16 06:19:33');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (48, 0, 0, 1, 0, 'case', 'change-approve ', '2018-10-17 06:44:54');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (49, 0, 0, 7, 0, 'case', 'add', '2018-10-18 06:27:53');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (50, 0, 0, 7, 0, 'case', 'approve', '2018-10-18 07:20:09');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (51, 0, 319, 1, 0, 'case', 'assign', '2018-10-18 10:50:40');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (52, 309, 0, 7, 0, 'customer', 'assign', '2018-10-19 08:43:54');
INSERT INTO `notification` (`id`, `customer_id`, `user_id`, `case_id`, `appointment_id`, `notification_type`, `status_type`, `create_date`) VALUES (53, 309, 318, 7, 0, 'customer', 'assign', '2018-10-19 10:48:23');


#
# TABLE STRUCTURE FOR: packages
#

DROP TABLE IF EXISTS `packages`;

CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `service_id` int(11) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (1, 'Schedule an internal meeting', 'basic', 1, '1 month', '1000', '2018-06-22 06:31:03', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (2, 'Schedule an external meeting', 'this is a medium package', 1, '1 month', '2000', '2018-06-22 06:31:29', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (3, 'Requesting paper legal writings', 'this is a high package', 1, '3 month', '5000', '2018-06-22 06:31:33', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (4, 'Schedule an internal meeting', 'this is a golden package', 2, '1 month', '10500', '2018-06-22 06:31:39', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (5, 'Schedule an external meeting', 'this is a silver package', 2, '10 month', '2500', '2018-06-22 06:31:50', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (6, 'Request to attend court session', 'Request to attend court session', 2, '1 year', '2000\r\n', '2018-06-22 06:33:05', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (7, 'Schedule an internal meeting', 'Schedule an internal meeting', 3, '1 month', '1200', '2018-06-22 06:34:07', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (8, 'Schedule an external meeting', 'Schedule an external meeting', 3, '1 year', '1500', '2018-06-22 06:34:24', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (9, 'Request a voice consultation ', 'Request a voice consultation  ', 3, '1 year', '3000', '2018-06-23 03:07:11', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (10, 'Request written consultation', 'Request written consultation', 3, '3 month', '2500', '2018-06-22 06:35:02', '0000-00-00 00:00:00');
INSERT INTO `packages` (`id`, `package_name`, `description`, `service_id`, `duration`, `amount`, `created`, `modified`) VALUES (11, 'Request for audio and written consultation', 'Request for audio and written consultation', 3, '2 month', '3000', '2018-06-22 06:35:21', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: permissions_module
#

DROP TABLE IF EXISTS `permissions_module`;

CREATE TABLE `permissions_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (1, 'Clients', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (2, 'Cases', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (3, 'Sessions', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (4, 'Writings', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (5, 'Consultation', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (6, 'Visiting ', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (7, 'Procuration', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (8, 'Registration of document', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (9, 'Tasks', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (10, 'Project planning', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (11, 'Client meting notes ', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (12, 'Referrals', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (13, 'Archives', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (14, 'HR', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (15, 'Permissions', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (16, 'Fain', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (17, 'Expense', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (18, 'Finances', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (19, 'Evaluations', '0000-00-00 00:00:00');
INSERT INTO `permissions_module` (`id`, `name`, `created`) VALUES (20, 'Report', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: permissions_settings
#

DROP TABLE IF EXISTS `permissions_settings`;

CREATE TABLE `permissions_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `data` text NOT NULL,
  `create` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (1, 145, '{\"3\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1}}', '2018-08-30 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (2, 142, '{\"1\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"2\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"3\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"4\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"5\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"6\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"7\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"8\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"9\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"10\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"11\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"12\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"13\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"14\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"15\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"16\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"17\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"18\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"19\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"20\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1}}', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (3, 226, '{\"1\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"2\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"4\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"5\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"6\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"7\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"8\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0}}', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (4, 227, '{\"1\":{\"1\":1,\"2\":0,\"3\":1,\"4\":0,\"5\":1,\"6\":0,\"7\":0,\"8\":0},\"2\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"3\":{\"1\":0,\"2\":1,\"3\":1,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"4\":{\"1\":0,\"2\":1,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"5\":{\"1\":1,\"2\":1,\"3\":1,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"6\":{\"1\":0,\"2\":1,\"3\":1,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"7\":{\"1\":1,\"2\":1,\"3\":1,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"8\":{\"1\":1,\"2\":1,\"3\":1,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":0},\"15\":{\"1\":1,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0,\"7\":0,\"8\":1}}', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (5, 313, '{\"1\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"2\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"3\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"4\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"5\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"6\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"7\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"8\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"9\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"10\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"11\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"12\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"13\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"14\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"15\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"16\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"17\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"18\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"19\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"20\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0}}', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (6, 314, 'null', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (7, 316, '{\"1\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"2\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"3\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"4\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"5\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"6\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"7\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"8\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"9\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"10\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"11\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"12\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"13\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"14\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"15\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"16\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"17\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"18\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"19\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"20\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0}}', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (8, 323, '{\"1\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"2\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":0,\"6\":1,\"7\":1,\"8\":0},\"3\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"4\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"5\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"6\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"7\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"8\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"9\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"10\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"11\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"12\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"13\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"14\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"15\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"16\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"17\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"18\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"19\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"20\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0}}', '0000-00-00 00:00:00');
INSERT INTO `permissions_settings` (`id`, `user_id`, `data`, `create`) VALUES (9, 318, '{\"1\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"2\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"3\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"4\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"5\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"6\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"7\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"8\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"9\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"10\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"11\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"12\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"13\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"14\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"15\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"16\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"17\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"18\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":1},\"19\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0},\"20\":{\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":1,\"7\":1,\"8\":0}}', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: procuration
#

DROP TABLE IF EXISTS `procuration`;

CREATE TABLE `procuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `procuration_title` varchar(255) NOT NULL,
  `procuration_code` varchar(255) NOT NULL,
  `procuration_type` varchar(255) NOT NULL,
  `procuration_number` varchar(255) NOT NULL,
  `total_of_procuration_number` varchar(255) NOT NULL,
  `procuration_date` date NOT NULL,
  `procuration_status` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `procuration` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `case_code`, `case_type`, `case_number`, `contact_number`, `procuration_title`, `procuration_code`, `procuration_type`, `procuration_number`, `total_of_procuration_number`, `procuration_date`, `procuration_status`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`) VALUES (2, 142, 'fdsf', 'CR', '', '12', '123', '213', '312', '132', '132', '312', '123', '123', '123', '132', '132', '2018-10-23', '132', '132', '132', '13', '');


#
# TABLE STRUCTURE FOR: reg_of_doc
#

DROP TABLE IF EXISTS `reg_of_doc`;

CREATE TABLE `reg_of_doc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `document_title` varchar(255) NOT NULL,
  `document_code` varchar(255) NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `document_number` varchar(255) NOT NULL,
  `total_of_procuration_number` varchar(255) NOT NULL,
  `procuration_date` date NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `name`, `created`) VALUES (1, 'admin', '2018-05-02 08:32:21');
INSERT INTO `roles` (`id`, `name`, `created`) VALUES (2, 'employee', '2018-05-02 08:32:21');
INSERT INTO `roles` (`id`, `name`, `created`) VALUES (3, 'customer', '2018-05-02 10:25:26');


#
# TABLE STRUCTURE FOR: services
#

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (1, 'Contracts & Agreements', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2000, '2018-07-03 01:57:28', '2018-06-01 15:34:48');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (2, 'Consultancy & Legal Studies', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 1500, '2018-07-03 01:57:03', '2018-05-26 13:42:30');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (3, 'Commercial Business', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 1000, '2018-07-03 01:56:36', '0000-00-00 00:00:00');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (37, 'Litigation', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2500, '2018-07-03 01:57:47', '0000-00-00 00:00:00');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (38, 'Execution of judgments & collection of debts', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 3000, '2018-07-03 01:58:00', '0000-00-00 00:00:00');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (39, 'Liquidation of inheritance & management of endowments', 'Lorem Ipsum is simply dummy text.', 3500, '2018-07-03 01:58:19', '0000-00-00 00:00:00');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (40, 'Authentication', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 4000, '2018-07-03 01:58:37', '0000-00-00 00:00:00');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (41, 'Arbitration & Mediation', '	Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 4500, '2018-07-03 01:58:56', '0000-00-00 00:00:00');
INSERT INTO `services` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES (42, 'Executions ', '????? ???????', 0, '2018-10-11 06:16:50', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: session_appoinment
#

DROP TABLE IF EXISTS `session_appoinment`;

CREATE TABLE `session_appoinment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `total_of_session_number` varchar(255) NOT NULL,
  `session_number` varchar(255) NOT NULL,
  `session_date` date NOT NULL,
  `session_time` varchar(255) NOT NULL,
  `session_code` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `case_title` varchar(255) NOT NULL,
  `case_date` date NOT NULL,
  `case_start_date` date NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `opponent_full_name` varchar(255) NOT NULL,
  `opponent_note` text NOT NULL,
  `opponent_phone` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `court_number` varchar(255) NOT NULL,
  `court_address` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `opponent_lawyer_name` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, '1031999137', 'National_id', '', '324', 'omar alshareef', '234', 'sdf', 'asdf', '2018-10-11', '04:45 pm', 'reactivated', '234', '23', '23', 'test', '2018-10-16', '2018-10-10', '9998', 'Jasmin', 'adsf', '9998', 'asdf', 'asdf', 'sdf', 'Majed', 'asdf', '323', '323', 'asdf', 'asdf', '', '2018-10-14 07:54:18', '2018-10-07 01:27:50');
INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 142, 'trfd', 'National_id', '', 'oimm', 'sharaf abdullah', 'ijiuj', 'jiuuuh', 'uihiu', '2018-10-17', '08:30 am', 'active', '87y', 'bhjb', 'bhbhb', 'hgbhb', '2018-10-16', '2018-10-17', 'jjjio', 'jioji', 'joijio', 'joijoi', 'ojoiji', 'ojoij', 'jojioj', 'joijoi', 'oji', '323', '320', 'lkmlmj', 'mkmjk', '???? ????? ???? ?? ???? ???????.png', '2018-10-14 07:50:49', '2018-10-14 07:50:49');
INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (3, 142, 'trfd', 'National_id', '', 'oimm', 'sharaf abdullah', 'ijiuj', 'jiuuuh', 'uihiu', '2018-10-17', '08:30 am', 'active', '87y', 'bhjb', 'bhbhb', 'hgbhb', '2018-10-16', '2018-10-17', 'jjjio', 'jioji', 'joijio', 'joijoi', 'ojoiji', 'ojoij', 'jojioj', 'joijoi', 'oji', '323', '323', 'lkmlmj', 'mkmjk', '', '2018-10-14 07:53:30', '2018-10-14 07:53:30');
INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (4, 142, 'trfd', 'National_id', '', 'oimm', 'sharaf abdullah', 'ijiuj', 'jiuuuh', 'uihiu', '2018-10-17', '08:30 am', 'active', '87y', 'bhjb', 'bhbhb', 'hgbhb', '2018-10-16', '2018-10-17', 'jjjio', 'jioji', 'joijio', 'joijoi', 'ojoiji', 'ojoij', 'jojioj', 'joijoi', 'oji', '323', '323', 'lkmlmj', 'mkmjk', '', '2018-10-14 07:54:44', '2018-10-14 07:54:44');
INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (5, 142, 'trfd', 'National_id', '', 'oimm', 'sharaf abdullah', 'ijiuj', 'jiuuuh', 'uihiu', '2018-10-17', '08:30 am', 'active', '87y', 'bhjb', 'bhbhb', 'hgbhb', '2018-10-16', '2018-10-17', 'jjjio', 'jioji', 'joijio', 'joijoi', 'ojoiji', 'ojoij', 'jojioj', 'joijoi', 'oji', '323', '320', 'lkmlmj', 'mkmjk', '', '2018-10-14 07:54:52', '2018-10-14 07:54:52');
INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (6, 142, '111', 'National_id', '', '22', 'test sas', '321211', '231231', '32', '2018-10-17', '10:30 am', 'active', '132', '132', '2131', '312', '2018-10-17', '2018-10-25', '132', 'test sas', '123', '4234234', '12', '123', '123', '213', '123', '315', '323', '231', '132', '', '2018-10-16 05:20:38', '2018-10-16 05:20:38');
INSERT INTO `session_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_session_number`, `session_number`, `session_date`, `session_time`, `session_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `department`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (7, 142, '1031999137', 'National_id', '', '324', 'omar alshareef', '234', 'sdf', 'asdf', '2018-10-11', '04:45 pm', 'reactivated', '234', '23', '23', 'test', '2018-10-16', '2018-10-10', '9998', 'Jasmin', 'adsf', '9998', 'asdf', 'asdf', 'sdf', 'Majed', 'asdf', '323', '323', 'asdf', 'asdf', '', '2018-10-18 06:33:04', '2018-10-18 06:33:04');


#
# TABLE STRUCTURE FOR: task
#

DROP TABLE IF EXISTS `task`;

CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `task` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: team_members
#

DROP TABLE IF EXISTS `team_members`;

CREATE TABLE `team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `discription` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (10, 'Lawyer Nasr Mubarak Al Barakati', 'General Director', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'team-1.jpg');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (11, 'Former judge Majed Hamad al-Freih', 'Founding partner', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'team-2.jpg');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (12, 'Naeem Mubarak Al Barakati', 'Executive manager', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'team-3.jpg');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (13, 'Saad Abed Hashem Al-Shareef', 'lawyer', '', '');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (14, 'Hattem Mubarak Al Barakati', 'lawyer', '', '???? ????????.jpg');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (15, 'Mohammad Ibrahem Al-Saadi', 'Employee', '', '');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (16, 'Sulafa Abdullatef Zaini', 'lawyer', '', 'IMG-0004.PNG');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (17, 'Bashayer Abdullah Al_Shareef', 'lawyer', '', '???? ?????.jpg');
INSERT INTO `team_members` (`id`, `name`, `designation`, `discription`, `image`) VALUES (18, '1', '2', 'sa', '');


#
# TABLE STRUCTURE FOR: uploads
#

DROP TABLE IF EXISTS `uploads`;

CREATE TABLE `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `audio` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `uploads` (`id`, `user_id`, `case_id`, `audio`) VALUES (4, 262, 4, '9F6iQ.bin');
INSERT INTO `uploads` (`id`, `user_id`, `case_id`, `audio`) VALUES (5, 262, 4, 'CL7UG.bin');


#
# TABLE STRUCTURE FOR: user_temp
#

DROP TABLE IF EXISTS `user_temp`;

CREATE TABLE `user_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `id_type` varchar(255) NOT NULL,
  `id_numbers` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `add_edit` int(11) NOT NULL DEFAULT '0' COMMENT '0--add,1--edit',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;

INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (9, 168, 'shailesh vekariya   123', 'shaileshvekariya123@gmail.com', '2018-07-18', 'gonda', '', '', '', '+649846541', '', 'e10adc3949ba59abbe56e057f20f883e', 142, 0, '2018-07-13 04:35:05');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (10, 170, 'test fdsf', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 00:32:45');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (11, 171, 'test asd', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 00:34:11');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (12, 172, 'test asd', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 00:36:20');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (13, 173, 'test asd', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 00:36:24');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (14, 174, 'test asd', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 00:36:47');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (15, 175, 'test asd', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-06 00:39:09');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (16, 176, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 02:31:43');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (17, 177, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 03:19:46');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (18, 178, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 03:20:16');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (19, 179, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 03:21:31');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (20, 180, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 03:22:29');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (21, 181, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 03:22:33');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (22, 182, 'test 11', 'admin1@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 03:23:26');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (23, 183, 'q q', 'adminq@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-06 03:24:32');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (24, 184, 'test dswed', 'admin@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '', 0, 0, '2018-09-06 20:56:58');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (25, 185, '123123 fdsf', 'admin@gmail.com', '0000-00-00', 'dasd', '', '', '', '4234234', '', '', 0, 0, '2018-09-07 06:29:56');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (26, 186, 'Jasmin Kanani', 'jasminkanani07@gmail.com', '0000-00-00', 'Rajkot', '', '', '', '9998', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-07 06:30:30');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (27, 187, 'test 11', 'admin11@gmail.com', '0000-00-00', 'rtt', '', '', '', '4234234', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-07 08:08:16');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (28, 188, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', 'nn', '', '', '', '0595557384', '', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-10 01:18:11');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (29, 189, 'dd dd', 'alshareefof@gmail.com', '0000-00-00', 'ddd', '', '', '', 'dd', '', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-13 01:40:54');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (30, 190, 'Jasmin Kanani', 'jasminkanani07@gmail.com', '0000-00-00', 'Ahmedabad', '', '', '', '9998', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-17 07:43:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (31, 191, 'sp ', 'lawfire@yopmail.com', '0000-00-00', 'ahmedabad ', '123456', '123456', '123456', '123456', '', '', 0, 0, '2018-09-17 09:37:53');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (32, 192, 'sp', 'lawfire@yopmail.com', '0000-00-00', 'ahmedabad ', '123456', '123456', '123456', '123456', '', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-17 09:41:35');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (33, 193, 'piyush', 'peels@gmail.com', '0000-00-00', 'rji ', 'rjt', '123', '123', '123', '', '', 0, 0, '2018-09-17 21:05:36');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (34, 194, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', '123', '1111', '4234234', '', '', 0, 0, '2018-09-17 21:39:35');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (35, 195, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', '1234', '1234', '4234234', '', '', 0, 0, '2018-09-17 21:42:48');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (36, 196, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', '1234', '1234', '4234234', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-17 21:45:06');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (37, 198, 'Tes', '252@gmail.com', '0000-00-00', ' 5252', '5252', '5252', '5252', '5252', '', '5553cfaf751a4b14960b7581a20bc142', 0, 0, '2018-09-17 21:54:43');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (38, 199, '6363', '6363@g.c', '0000-00-00', ' 6363', '6363', '6363', '6363', '6363', '', '075b051ec3d22dac7b33f788da631fd4', 0, 0, '2018-09-17 21:56:58');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (39, 200, '2525', '2525@gmail.com', '0000-00-00', '2525 ', '2525', '2525', '2525', '2525', '', '9407c826d8e3c07ad37cb2d13d1cb641', 0, 0, '2018-09-18 00:11:53');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (40, 201, '2323', '2323@gmail.cokm', '0000-00-00', ' ', '2323', '2323', '2323', '2323', '', '149815eb972b3c370dee3b89d645ae14', 0, 0, '2018-09-18 00:12:57');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (41, 202, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:16:14');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (42, 203, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:16:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (43, 204, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:17:11');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (44, 205, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:17:24');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (45, 206, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:18:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (46, 207, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:18:47');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (47, 208, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:20:15');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (48, 209, 'test', 'testemp@gmail.com', '0000-00-00', 'tst', 'rtt', 'a', 'qew', '4234234', '', '', 0, 0, '2018-09-18 00:20:58');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (49, 212, '1', '1@ss.s', '0000-00-00', '1 ', '1', '1', '1', '1', 'latterhead.jpg', '', 0, 0, '2018-09-18 01:23:28');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (50, 213, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'sdad', 'asd', '4234234', 'latterhead.jpg', '', 0, 0, '2018-09-18 01:27:55');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (51, 214, '11', 'admin@gmail.com', '0000-00-00', ' fsf', 'sfds', 'ws', 'dfsdf', 'dfsfsd', 'latterhead.jpg', '', 0, 0, '2018-09-18 01:55:02');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (52, 215, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'wasd', 'sdasd', '4234234', 'latterhead.jpg', '', 0, 0, '2018-09-18 01:56:32');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (53, 216, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'wasd', 'sdasd', '4234234', 'latterhead.jpg', '', 0, 0, '2018-09-18 01:57:10');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (54, 217, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'wasd', 'sdasd', '4234234', 'latterhead.jpg', '', 0, 0, '2018-09-18 01:57:19');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (55, 218, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'sfsdf', 'fsdf', '4234234', 'Albarakati Law.png', '', 0, 0, '2018-09-18 02:06:50');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (56, 219, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'dasd', 'sad', '4234234', 'bitcoin-icon-for-internet-money-crypto-currency-vector-17847947.jpg', '', 0, 0, '2018-09-18 02:07:37');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (57, 220, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'dasd', 'das', '4234234', 'Albarakati Law.png', '', 0, 0, '2018-09-18 02:12:16');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (58, 221, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'dasd', 'das', '4234234', 'Albarakati Law.png', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-18 02:13:44');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (59, 222, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'dsad', 'asdasd', '4234234', '', 'b59c67bf196a4758191e42f76670ceba', 0, 0, '2018-09-18 02:17:42');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (60, 223, 'sp', 'time4ssss@yopmail.com', '0000-00-00', '121212 ', '1212', '1212', '1212', '1212', 'Eea2M.jpg', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-18 11:13:14');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (61, 224, 'omar', 'alshareefof@gmail.com', '0000-00-00', ' ', 'yyyyyyyyyy', '11111111111111111111111', '1111111111111111111111', '1111111111', 'Gyod4.', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-18 23:08:29');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (62, 225, 'test 12121', 'alshareefof@gmail.com', '0000-00-00', ' ', 'nn', '11111111111111', '1111111111', '1111111111', 'Tcq0j.', 'fcea920f7412b5da7be0cf42b8c93759', 0, 0, '2018-09-20 02:50:51');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (63, 228, 'test', 'pulpysaoft@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', 'qIZms.jpg', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-23 22:45:14');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (64, 229, 'test', 'admian@gmail.com', '0000-00-00', 'tst', 'rtt', 'Aqama', 'AA11', '4234234', 'BT0nl.jpg', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-23 22:53:44');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (65, 230, ' ??? ???? ??????', 'alshareefof@gmail.com', '0000-00-00', ' ??? ??????? ???? ??? 2 ', '???', 'National Id', '123123123123', '0595557384', 'YZO0m.jpg', '5527fa25dca946e6d5a616e4314ba353', 0, 0, '2018-09-25 22:38:19');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (66, 231, 'bgfgmfuvobk,', 'alshareefof@gmail.com', '0000-00-00', '  bgtdhfjgn', 'gdnfyk', 'CR', '1231234123123', '0555555555', 'agHIB.JPG', '733d7be2196ff70efaf6913fc8bdcabf', 0, 0, '2018-09-26 09:50:49');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (67, 232, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' jedah, jeddah ', 'jeedah', 'CR', '1031999137', '0595557384', 'Ggv50.jpg', '', 0, 0, '2018-09-26 22:48:58');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (68, 233, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' jedah, jeddah ', 'jeedah', 'CR', '1031999137', '0595557384', 'gBkYf.jpg', '', 0, 0, '2018-09-26 22:49:53');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (69, 234, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' jedah, jeddah ', 'jeedah', 'CR', '1031999137', '0595557384', 'zfEbv.jpg', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-26 22:52:04');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (70, 235, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' test test test', 'jeedah', 'National Id', '1031999137', '0595557384', 'OMegn.jpg', '', 0, 0, '2018-09-26 23:15:26');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (71, 236, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' test test test', 'jeedah', 'National Id', '1031999137', '0595557384', '2S4ys.jpg', '4297f44b13955235245b2497399d7a93', 0, 0, '2018-09-26 23:19:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (72, 237, 'New', 'new@gmail.com', '0000-00-00', '123 ', '123', 'CR', '123', '123', 'KmR6v.jpg', '', 0, 0, '2018-09-26 23:50:22');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (73, 238, 'New', 'new1@gmail.com', '0000-00-00', '123 ', '123', 'CR', '123', '123', 'x8wo7.jpg', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-27 00:01:33');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (74, 240, 'test', 'pulpysofat@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'asdasd', '4234234', 'dJc4I.jpg', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-27 02:18:40');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (75, 241, 'test', 'modhavadiwerrya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'rewrwe', '4234234', 'CPuOq.jpg', '', 0, 0, '2018-09-27 02:19:56');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (76, 242, 'test', 'modhavadiwerrya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'rewrwe', '4234234', 'KetiE.jpg', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-09-27 02:21:55');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (77, 243, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dfssdf', '4234234', '067rz.jpg', '', 0, 0, '2018-09-27 02:27:49');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (78, 244, 'test', 'sadasdas@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', '123456', '4234234', 'ThMLJ.jpg', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-09-27 02:31:33');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (79, 245, 'test', 'admiqn@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', '1111', '4234234', 'iIE1C.jpg', 'b59c67bf196a4758191e42f76670ceba', 0, 0, '2018-09-27 02:37:10');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (80, 246, 'test', '2222@2222.com', '0000-00-00', 'tst', 'rtt', 'CR', '2222', '4234234', 'Hx5gu.jpg', '934b535800b1cba8f96a5d72f72f1611', 0, 0, '2018-09-27 02:59:39');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (81, 248, '?????', 'bashayer.alshanbari@gmail.com', '0000-00-00', ' ???????', '???', 'National Id', '142425434', '920002916', '5ajYv.JPG', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-02 01:49:54');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (82, 249, '?????', 'bashayer.alshanbari@gmail.com', '0000-00-00', ' ????', '???', 'Aqama', '545275', '0563112797', 'tT2go.JPG', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-02 02:12:09');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (83, 250, '????', 'sulafa@albarakatilaw.com', '0000-00-00', ' ??????? - ????????? ????', '???', 'National Id', '1083005791', '0543974484', 'DYJtM.pdf', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-02 02:47:47');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (84, 251, 'test', 'adminqq@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', 'MY03a.jpg', '', 0, 0, '2018-10-02 03:33:44');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (85, 252, 'test', 'adminqq@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', 'tVpeQ.jpg', '', 0, 0, '2018-10-02 03:38:22');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (86, 253, '???', 'homasdz123@gmail.com', '0000-00-00', '???? ', '???', 'National Id', '12312', '213', 'TLdyF.pdf', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-02 04:36:56');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (87, 254, 'test', 'admin@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', 'lLkzY.jpg', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-02 08:34:49');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (88, 255, 'peels', 'modhavadiya55@gmail.com', '0000-00-00', '4141 ', '4141', 'CR', '4141', '4141', 'LzfNu.jpg', '5eb13cb69b6e20dd7a42030f5936a9dc', 0, 0, '2018-10-02 23:55:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (89, 257, '????', 'lnef@mkfji.com', '0000-00-00', '??????? ', '??????????', 'CR', '985626', '95626', 'rjfVS.JPG', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-03 04:29:59');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (90, 259, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' ', 'jeedah', 'CR', '1031999137', '0595557384', 'yiCQ3.jpg', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-10-03 22:15:56');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (91, 260, 'omar alshareef', 'alshareefof@gmail.com', '0000-00-00', ' ', 'jeedah', 'CR', '1031999137', '0595557384', 'uWQYe.jpg', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-10-03 23:03:13');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (92, 261, 'Jasmin', 'jasminkanani07@gmail.com', '0000-00-00', 'This is a test address', 'Ahmedabad', 'CR', '123', '9998', 'PfUjb.png', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '2018-10-03 23:08:38');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (93, 262, 'Toxcore', 'toxcoresolutions@gmail.com', '0000-00-00', 'This is my full address ', 'My City', 'National Id', '1234567890', '1234567890', 'Gos4W.png', '96e79218965eb72c92a549dd5a330112', 0, 0, '2018-10-03 23:15:11');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (94, 263, 'peels', 'modhavadiya55@gmail.com', '0000-00-00', 'dsad ', 'pbr', 'CR', '123456', '123456', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-03 23:28:33');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (95, 265, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-03 23:58:50');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (96, 266, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dsfd', '4234234', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-04 00:30:47');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (97, 267, 'gfhgf', 'modhavadiya55@gmail.com', '0000-00-00', ' ', 'hfhfhfh', 'CR', 'hfhf', 'hfghfg', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-04 00:40:30');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (98, 268, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dsaf', '4234234', '', '', 0, 0, '2018-10-04 00:46:26');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (99, 269, 'gfg', '', '0000-00-00', ' dfgdfgd', 'dfg', 'CR', 'gdfgdf', 'gdfg', '', '', 0, 0, '2018-10-04 01:24:16');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (100, 270, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sd', '4234234', '', '', 0, 0, '2018-10-04 02:40:08');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (101, 271, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sad', '4234234', '', '', 0, 0, '2018-10-04 02:41:35');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (102, 272, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'fghfh', '4234234', '', '', 0, 0, '2018-10-04 02:48:39');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (103, 273, 'test', 'modhavadiya51@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'fghfh', '4234234', '', '', 0, 0, '2018-10-04 02:48:43');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (104, 274, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sf', '4234234', '', '', 0, 0, '2018-10-04 02:49:19');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (105, 275, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 02:52:49');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (106, 276, 'test', 'modhavadiya551@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 02:52:53');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (107, 277, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'asd', '4234234', '', '', 0, 0, '2018-10-04 02:55:32');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (108, 278, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 's', '4234234', '', '', 0, 0, '2018-10-04 03:04:35');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (109, 279, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dsad', '4234234', '', '', 0, 0, '2018-10-04 03:13:33');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (110, 280, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sad', '4234234', '', '', 0, 0, '2018-10-04 03:14:58');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (111, 281, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sad', '4234234', '', '', 0, 0, '2018-10-04 03:15:03');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (112, 282, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 's', '4234234', '', '', 0, 0, '2018-10-04 03:17:35');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (113, 283, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 's', '4234234', '', '', 0, 0, '2018-10-04 03:17:38');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (114, 284, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'd', '4234234', '', '', 0, 0, '2018-10-04 03:19:05');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (115, 285, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'd', '4234234', '', '', 0, 0, '2018-10-04 03:19:08');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (116, 286, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'hf', '4234234', '', '', 0, 0, '2018-10-04 03:24:35');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (117, 287, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sad', '4234234', '', '', 0, 0, '2018-10-04 03:28:25');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (118, 288, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sdd', '4234234', '', '', 0, 0, '2018-10-04 03:29:25');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (119, 289, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', '123', '4234234', '', '', 0, 0, '2018-10-04 03:32:55');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (120, 290, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', '123', '4234234', '', '', 0, 0, '2018-10-04 04:08:14');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (121, 291, 'fsdf', 'modhavadiya55@gmail.comd', '0000-00-00', ' sfddsf', '$(\'#sendf\').on(\'click\', function() {     var valid = true,         message = \'\';          if(!$(\'#answers\').val()) {             valid = true;         }          if(!valid) {         alert(message);     } });', 'CR', 'fdsf', 'fdsfs', '', '', 0, 0, '2018-10-04 04:26:10');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (122, 292, 'fsdf', 'modhavadiya55@gmail.com', '0000-00-00', ' sfddsf', '$(\'#sendf\').on(\'click\', function() {     var valid = true,         message = \'\';          if(!$(\'#answers\').val()) {             valid = true;         }          if(!valid) {         alert(message);     } });', 'CR', 'fdsf', 'fdsfs', '', '', 0, 0, '2018-10-04 04:26:22');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (123, 293, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dsf', '4234234', '', '', 0, 0, '2018-10-04 04:27:12');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (124, 294, 'test', 'modhavaqadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dsf', '4234234', '', '', 0, 0, '2018-10-04 04:27:16');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (125, 295, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 04:27:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (126, 296, 'test', 'modhavadiya55@gmail.coma', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 04:27:49');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (127, 297, 'test', 'modhavadiya55@gmail.coma', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 04:28:21');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (128, 298, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 04:28:29');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (129, 299, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'ASDAD4324', '4234234', '', '', 0, 0, '2018-10-04 04:29:56');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (130, 300, 'dsad', 'modhavadiya55@gmail.com', '0000-00-00', ' dsf', 'dfsf', 'CR', 'fdsf', 'fdsf', '', '', 0, 0, '2018-10-04 04:33:14');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (131, 301, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'sadsaf', '4234234', '', '', 0, 0, '2018-10-04 04:33:30');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (132, 302, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'dsad', '4234234', '', '', 0, 0, '2018-10-04 04:34:21');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (133, 303, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'fsdf', '4234234', '', '', 0, 0, '2018-10-04 04:35:24');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (134, 304, 'test', 'modhavadiya55@gmail.coma', '0000-00-00', 'tst', 'rtt', 'CR', 'fsdf', '4234234', '', '', 0, 0, '2018-10-04 04:36:28');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (135, 305, 'test', 'modhavadiya55@gmail.comaa', '0000-00-00', 'tst', 'rtt', 'CR', '123', '4234234', '', '', 0, 0, '2018-10-04 04:40:05');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (136, 306, 'test', 'modhavadiya55@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', 'gdfg', '4234234', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-04 04:44:17');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (137, 307, 'new', 'new@gmail.com', '0000-00-00', 'tst', 'rtt', 'CR', '2131', '4234234', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-06 23:11:10');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (138, 308, 'dsfg', 'jasminkanani07@gmail.com', '0000-00-00', 'This is a test address', 'Ahmedabad', 'National Id', '123', '9998', '', '96e79218965eb72c92a549dd5a330112', 0, 0, '2018-10-06 23:13:39');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (139, 309, 'omar alshareef', 'hstaits@gmail.com', '0000-00-00', ' ShjxzkL:XLm', 'jeedah', 'CR', '1031999137', '0595557384', '', '', 0, 0, '2018-10-07 06:30:34');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (140, 310, 'new', 'testemp@gmail.com', '0000-00-00', '12313 ', '12313', 'CR', '12345', '12365', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-07 23:34:51');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (141, 311, '???', 'bashayer.alshanbari@gmail.com', '0000-00-00', '????? ', '???', 'National Id', '1212--', '789', '', '81dc9bdb52d04dc20036dbd8313ed055', 0, 0, '2018-10-08 02:31:38');
INSERT INTO `user_temp` (`id`, `user_id`, `name`, `email`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `image`, `password`, `emp_id`, `add_edit`, `created`) VALUES (142, 312, 'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq', 'omar69alshareef@gmail.com', '0000-00-00', ' ', 'jeedah', 'CR', '1031999137', '0595557384', '', 'd0970714757783e6cf17b26fb8e2298f', 0, 0, '2018-10-08 05:27:08');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `id_type` varchar(255) NOT NULL,
  `id_numbers` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `key_token` varchar(255) NOT NULL COMMENT 'Forgot password in used ',
  `device_type` int(11) NOT NULL COMMENT '1- android, 2- iphone',
  `device_token` varchar(255) NOT NULL,
  `verification_token` varchar(255) NOT NULL,
  `otp` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0- in active , 1- active',
  `is_delete` int(11) NOT NULL DEFAULT '0' COMMENT '0- not delete, 1 - delete',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=354 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (142, 'admin', '1998-05-09', 'bhojrajpara', '', '', '', '9724081113', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 1, '', 0, '', '', '', 1, 0, '2018-06-22 20:16:52', '2018-08-03 01:19:53');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (259, 'omar alshareef', '0000-00-00', ' ', 'jeedah', 'CR', '1031999137', '0595557384', 'alshareefof@gmail.com', '02c180067bc66a5ddf52a9f59fd87c91', 'yiCQ3.jpg', 3, '', 0, '', '', '', 2, 0, '2018-10-03 22:14:57', '2018-10-07 23:30:33');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (260, 'omar alshareef', '0000-00-00', ' ', 'jeedah', 'CR', '1031999137', '0595557384', 'alshareefof@gmail.com', '02c180067bc66a5ddf52a9f59fd87c91', 'uWQYe.jpg', 3, '', 0, '', '', '', 0, 0, '2018-10-03 23:02:47', '2018-10-07 23:30:33');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (262, 'Toxcore', '0000-00-00', 'This is my full address ', 'My City', 'National Id', '1234567890', '1234567890', 'toxcoresolutions@gmail.com', '96e79218965eb72c92a549dd5a330112', 'Gos4W.png', 3, '', 0, '', '', '0', 0, 0, '2018-10-03 23:14:54', '2018-10-04 06:14:25');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (306, 'test', '0000-00-00', 'tst', 'rtt', 'CR', '123456', '+918866278873', 'modhavadiya55@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-04 04:44:11', '2018-10-19 03:30:13');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (307, 'new', '0000-00-00', 'tst', 'rtt', 'CR', '2131', '4234234', 'new@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 3, '', 0, '', '', '', 0, 0, '2018-10-06 23:10:41', '2018-10-06 23:11:10');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (308, 'dsfg', '0000-00-00', 'This is a test address', 'Ahmedabad', 'National Id', '123', '9998', 'jasminkanani07@gmail.com', '502e2e3e18c4ad6adcb35032402b0251', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-06 23:12:23', '2018-10-07 23:30:15');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (309, 'omar alshareef', '0000-00-00', ' ShjxzkL:XLm', 'jeedah', 'CR', '1031999137', '0595557384', 'hstaits@gmail.com', '280325056684a1ef58759d7813db8a79', '', 3, '', 0, '', '', '', 0, 0, '2018-10-07 06:30:34', '2018-10-07 23:57:56');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (310, 'new', '0000-00-00', '12313 ', '12313', 'CR', '12345', '12365', 'testemp@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-07 23:34:44', '2018-10-07 23:37:09');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (311, '???', '0000-00-00', '????? ', '???', 'National Id', '1212--', '789', 'bashayer.alshanbari@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 3, '', 0, '', '', '', 0, 0, '2018-10-08 02:31:22', '2018-10-08 02:31:38');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (312, 'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq', '0000-00-00', ' ', 'jeedah', 'CR', '1031999137', '0595557384', 'omar69alshareef@gmail.com', 'd0970714757783e6cf17b26fb8e2298f', '', 3, '', 0, '', '', '', 0, 0, '2018-10-08 05:26:50', '2018-10-08 05:27:08');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (313, 'emp', '2018-10-10', 'Ahmdb', '', '', '', '3123123131', 'emp@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 2, '', 0, '', '', '', 1, 1, '2018-10-08 23:21:27', '2018-10-13 10:24:26');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (314, 'omar', '0000-00-00', '', '', '', '', '0595557384', 'alshareefof@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '', 1, 0, '2018-10-09 08:13:59', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (315, 'Mohammed Abdul Latif Sari', '2009-08-01', 'Mohammed Abdul Latif Sari', '', '', '', '0542610320', 'sery@albarakatilaw.com', 'dc483e80a7a0bd9ef71d8cf973673924', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 09:45:24', '2018-10-13 09:50:28');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (316, 'Nasr Mubarak Al Barakati', '2000-01-01', 'Azizia Mecca', '', '', '', '0580006664', 'nassr@albarakatilaw.com', '25f9e794323b453885f5181f1b624d0b', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 09:54:00', '2018-10-13 10:05:43');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (317, 'mohammed hamed abdulialil ghareeb', '1988-01-01', 'Rawda area', '', '', '', '0544845533', 'hamed@albarakatilaw.com', 'dc483e80a7a0bd9ef71d8cf973673924', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 10:03:54', '2018-10-13 10:05:38');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (318, 'Naem Mubarak Al Barakati', '1989-10-11', 'Awali Mecca', '', '', '', '0546060030', 'n.albarakati@albarakatilaw.com ', '25d55ad283aa400af464c76d713c07ad', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 10:10:46', '2018-10-13 10:10:55');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (319, 'Mohammed Al - Subaie', '1979-08-08', 'Azizia Riyadh', '', '', '', '0590009998', 'Central@albarakatilaw.com ', 'fcea920f7412b5da7be0cf42b8c93759', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 10:16:26', '2018-10-13 10:20:38');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (320, 'mohamed daoud', '1984-08-17', 'Azizia Mecca', '', '', '', '0546060860', 'daoud@albarakatilaw.com', 'e10adc3949ba59abbe56e057f20f883e', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 10:22:37', '2018-10-13 10:22:45');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (321, 'mohammed haj omer', '1988-04-23', 'King Fahed street', '', '', '', '0537230898', 'central@albarakatilaw.com', 'dc483e80a7a0bd9ef71d8cf973673924', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 10:38:31', '2018-10-13 10:38:38');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (322, 'Sara Ahmed Elnagar', '2012-09-17', 'Batha Quraish Mecca', '', '', '', '0570868420', 'daoud@albarakatilaw.com', '827ccb0eea8a706c4c34a16891f84e7b', '', 2, '', 0, '', '', '', 1, 0, '2018-10-13 10:42:27', '2018-10-13 10:42:38');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (323, 'raya alharbi', '2018-10-17', 'makkah', '', '', '', '0564314596', 'raya20al@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 2, '', 0, '', '', '', 1, 0, '2018-10-14 03:58:50', '2018-10-14 03:59:14');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (324, 'ali abdullah', '2018-10-26', 'makkah', '', '', '', '7278278257', 'hsthtstrh@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 2, '', 0, '', '', '', 1, 0, '2018-10-14 04:03:14', '2018-10-14 04:03:24');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (325, 'sharaf abdullah', '2018-10-04', 'makkah', '', '', '', '0555555555', 'afcsfcaf@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 2, '', 0, '', '', '', 1, 0, '2018-10-14 04:06:10', '2018-10-14 04:06:15');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (326, 'hamzah abdullah', '2018-10-20', 'makkah', '', '', '', '0548963217', 'bashayer.alshanbari@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 2, '', 0, '', '', '', 1, 0, '2018-10-14 04:14:24', '2018-10-14 04:17:10');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (327, 'ahmad abdullah', '2018-10-04', 'Cairo', '', '', '', '0563112797', 'bashayer.alshanbari@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 2, '', 0, '', '', '', 1, 0, '2018-10-14 04:16:53', '2018-10-14 04:17:08');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (328, 'bashayer', '0000-00-00', '', '', 'CR', '545275', '0563112797', 'sddscdc@gmail.com', '123', '5KBV1.png', 3, '', 0, '', '', '', 0, 0, '2018-10-15 03:10:45', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (329, 'bashayer', '0000-00-00', '', '', 'CR', '1221212', '0555075223', 'bashayer-a-sh@gmail.com', '1234', 'GkshO.png', 3, '', 0, '', '', '', 0, 0, '2018-10-16 04:08:03', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (330, 'bbb', '0000-00-00', '', '', 'CR', '5678', '87', 'bbbbb@gjbs.com', '1234', 'iVHOj.png', 3, '', 0, '', '', '', 0, 0, '2018-10-16 04:22:32', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (331, 'omar alshareef', '0000-00-00', '', '', 'National Id', '1031999137', '0595557384', 'alsharifak2@gmail.com', '123456', '', 3, '', 0, '', '', '', 0, 0, '2018-10-16 23:54:54', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (332, 'newtest', '0000-00-00', '', '', 'CR', '23456', '1232312', 'test@gmail.com', '123', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-18 05:58:31', '2018-10-18 05:58:42');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (333, 'qwer', '0000-00-00', '', '', 'CR', '12454', '4234234', 'eqweq@gmail.com', '1', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-18 06:00:09', '2018-10-18 06:00:25');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (334, '12121', '0000-00-00', '', '', 'CR', 'ASDAD4324', '123123', 'sadasd@sdsa.ff', '1', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-18 06:06:28', '2018-10-18 06:06:42');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (335, 'sp', '0000-00-00', '', '', 'Aqama', '1212', '1234567890', 'demo@gmail.com', '123456', '', 3, '', 0, '', '', '9640', 0, 0, '2018-10-18 08:22:21', '2018-10-18 08:22:21');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (336, 'Jasmin Kanani', '0000-00-00', '', '', 'CR', '123456', '1234567890', 'jasminkanani07@gmail.com', '96e79218965eb72c92a549dd5a330112', '', 3, '', 0, '', '', '1453', 0, 0, '2018-10-19 00:17:25', '2018-10-19 00:17:25');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (337, '123456', '0000-00-00', '', '', 'CR', '123', '21212', 'pulp11ysofat@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 3, '', 0, '', '', '4375', 0, 0, '2018-10-19 00:18:47', '2018-10-19 00:18:47');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (338, 'Jasmin Kanani', '0000-00-00', '', '', 'CR', '111111', '9998', 'jasminkanani07@gmail.com', '96e79218965eb72c92a549dd5a330112', '', 3, '', 0, '', '', '7104', 0, 0, '2018-10-19 00:19:23', '2018-10-19 00:23:20');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (339, 'test', '0000-00-00', '', '', 'CR', '2112', '4234234', 'pulpy11sofat@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-19 00:19:51', '2018-10-19 00:20:00');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (340, 'Jasmin Kanani', '0000-00-00', '', '', 'CR', '111111', '9998', 'jasminkanani07@gmail.com', '96e79218965eb72c92a549dd5a330112', '', 3, '', 0, '', '', '9638', 0, 0, '2018-10-19 00:20:31', '2018-10-19 00:20:31');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (341, 'Jasmin', '0000-00-00', '', '', 'CR', '111111', '9998', 'jasminkanani07@gmail.com', '96e79218965eb72c92a549dd5a330112', '', 3, '', 0, '', '', '2871', 0, 0, '2018-10-19 00:21:25', '2018-10-19 00:21:25');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (342, 'Jasmin', '0000-00-00', '', '', 'CR', '111111', '9998', 'jasminkanani07@gmail.com', '96e79218965eb72c92a549dd5a330112', '', 3, '', 0, '', '', '6161', 0, 0, '2018-10-19 00:21:40', '2018-10-19 00:21:40');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (343, 'Jasmin', '0000-00-00', '', '', 'CR', '123123123', '9998', 'jasminasdfskanani07@gmail.com', '93279e3308bdbbeed946fc965017f67a', '', 3, '', 0, '', '', '5864', 0, 0, '2018-10-19 00:22:10', '2018-10-19 00:22:10');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (344, 'test', '0000-00-00', '', '', 'CR', 'ASDAD4324', '4234234', 'pulpysofat@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 3, '', 0, '', '', '7587', 0, 0, '2018-10-19 00:23:01', '2018-10-19 00:23:01');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (345, '12', '0000-00-00', '', '', 'CR', '123456', '4234234', 'pulpysofat@gma1il.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 3, '', 0, '', '', '9464', 0, 0, '2018-10-19 02:25:26', '2018-10-19 02:25:26');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (346, '123456', '0000-00-00', '', '', 'CR', '123456', '4234234', 'pul1pysofat@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 3, '', 0, '', '', '2344', 0, 0, '2018-10-19 02:26:29', '2018-10-19 02:26:29');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (347, '1', '0000-00-00', '', '', 'CR', 'ASDAD4324', '4234234', 'pulpysofa1t@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 3, '', 0, '', '', '9254', 0, 0, '2018-10-19 02:27:44', '2018-10-19 02:27:44');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (348, 'test', '0000-00-00', '', '', 'CR', '1234156', '4234234', 'pulpyso1fat@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 3, '', 0, '', '', '0', 0, 0, '2018-10-19 02:39:13', '2018-10-19 02:39:18');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (349, 'omar alshareef', '0000-00-00', '', '', 'CR', '1031999137', '9665955573', 'alsharifak2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '4487', 0, 0, '2018-10-19 07:50:26', '2018-10-19 07:50:26');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (350, 'omar alshareef', '0000-00-00', '', '', 'CR', '1031999137', '9665955573', 'alsharifak2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '1065', 0, 0, '2018-10-19 07:50:59', '2018-10-19 07:50:59');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (351, 'omar alshareef', '0000-00-00', '', '', 'CR', '1031999137', '9665955573', 'alsharifak2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '9872', 0, 0, '2018-10-19 07:51:01', '2018-10-19 07:51:01');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (352, 'omar alshareef', '0000-00-00', '', '', 'CR', '1031999137', '9665955573', 'alsharifak2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '5244', 0, 0, '2018-10-19 07:51:55', '2018-10-19 07:51:55');
INSERT INTO `users` (`id`, `name`, `dob`, `address`, `city`, `id_type`, `id_numbers`, `phone`, `email`, `password`, `image`, `role_id`, `key_token`, `device_type`, `device_token`, `verification_token`, `otp`, `status`, `is_delete`, `created`, `modified`) VALUES (353, 'omar alshareef', '0000-00-00', '', '', 'CR', '1031999137', '9665955573', 'alsharifak2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', 3, '', 0, '', '', '5357', 0, 0, '2018-10-19 07:52:42', '2018-10-19 07:52:42');


#
# TABLE STRUCTURE FOR: visiting_appoinment
#

DROP TABLE IF EXISTS `visiting_appoinment`;

CREATE TABLE `visiting_appoinment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `total_of_visiting_number` varchar(255) NOT NULL,
  `visiting_number` varchar(255) NOT NULL,
  `visiting_date` date NOT NULL,
  `visiting_time` varchar(255) NOT NULL,
  `visiting_code` varchar(255) NOT NULL,
  `next_visiting_date` varchar(255) NOT NULL,
  `next_visiting_time` varchar(255) NOT NULL,
  `next_visiting_note` text NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `case_title` varchar(255) NOT NULL,
  `case_date` date NOT NULL,
  `case_start_date` date NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `opponent_full_name` varchar(255) NOT NULL,
  `opponent_note` text NOT NULL,
  `opponent_phone` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `court_number` varchar(255) NOT NULL,
  `court_address` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `opponent_lawyer_name` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `visiting_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_visiting_number`, `visiting_number`, `visiting_date`, `visiting_time`, `visiting_code`, `next_visiting_date`, `next_visiting_time`, `next_visiting_note`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, 'huh', 'National_id', '', '22', '             ewdwd', 'jhg', 'ww', 'q', '2018-10-22', '05:25 am', 'q', '2018-10-22', '05:25 pm', 'wdwq', 'wqswq', 'sd', 'dew', 'wd', '2018-10-22', '2018-10-22', 'wsd', 'ftybn', 'bhjnkm', 'kjnkjn', 'njmkl,', 'nmkl,', 'bnjkml,;&#039;', 'nmk,l.;', 'nmkl,;.', '324', '325', 'wq', '', '2018-10-16 06:16:22', '2018-10-15 07:26:16');
INSERT INTO `visiting_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_visiting_number`, `visiting_number`, `visiting_date`, `visiting_time`, `visiting_code`, `next_visiting_date`, `next_visiting_time`, `next_visiting_note`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 142, '213213', 'CR', '', '22', '6514', '64', '64', '65', '2018-10-26', '10:30 am', '46', '2018-10-18', '03:30 pm', '465654', '465', '465465', '465', '465', '2018-10-17', '2018-10-18', '465', '46', '46', '46', 'test', '46', 'tst', '46', '4', '316', '324', '2', '', '2018-10-16 06:16:25', '2018-10-16 06:11:11');
INSERT INTO `visiting_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_visiting_number`, `visiting_number`, `visiting_date`, `visiting_time`, `visiting_code`, `next_visiting_date`, `next_visiting_time`, `next_visiting_note`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (3, 142, 'huh', 'National_id', '', '22', '             ewdwd', 'jhg', 'ww', 'q', '2018-10-22', '05:25 am', 'q', '2018-10-22', '05:25 pm', 'wdwq', 'wqswq', 'sd', 'dew', 'wd', '2018-10-22', '2018-10-22', 'wsd', 'ftybn', 'bhjnkm', 'kjnkjn', 'njmkl,', 'nmkl,', 'bnjkml,;&#039;', 'nmk,l.;', 'nmkl,;.', '324', '325', 'wq', '', '2018-10-16 06:17:45', '2018-10-16 06:17:45');
INSERT INTO `visiting_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_visiting_number`, `visiting_number`, `visiting_date`, `visiting_time`, `visiting_code`, `next_visiting_date`, `next_visiting_time`, `next_visiting_note`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (4, 142, '3214', 'CR', '', '22', 'test', '3213', '213', '123', '2018-10-19', '09:30 am', '123', '2018-10-18', '10:30 am', '13', '213', '123', '123', '1', '2018-10-24', '2018-10-26', '123', '12', '123', '123', '123', '1', '12', '132', '1231', '325', '325', '23423', '', '2018-10-16 06:19:32', '2018-10-16 06:19:32');


#
# TABLE STRUCTURE FOR: writings_appoinment
#

DROP TABLE IF EXISTS `writings_appoinment`;

CREATE TABLE `writings_appoinment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `identification_number` varchar(255) NOT NULL,
  `identification_types` varchar(255) NOT NULL,
  `other_identification_types` varchar(255) NOT NULL,
  `client_file_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `total_of_writings_number` varchar(255) NOT NULL,
  `writings_number` varchar(255) NOT NULL,
  `writings_date` date NOT NULL,
  `writings_time` varchar(255) NOT NULL,
  `writings_code` varchar(255) NOT NULL,
  `case_code` varchar(255) NOT NULL,
  `case_type` varchar(255) NOT NULL,
  `case_number` varchar(255) NOT NULL,
  `case_title` varchar(255) NOT NULL,
  `case_date` date NOT NULL,
  `case_start_date` date NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `opponent_full_name` varchar(255) NOT NULL,
  `opponent_note` text NOT NULL,
  `opponent_phone` varchar(255) NOT NULL,
  `court_name` varchar(255) NOT NULL,
  `court_number` varchar(255) NOT NULL,
  `court_address` varchar(255) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `opponent_lawyer_name` varchar(255) NOT NULL,
  `responsible_employee` varchar(255) NOT NULL,
  `follow_up_employee` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `updatedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `writings_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_writings_number`, `writings_number`, `writings_date`, `writings_time`, `writings_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (1, 142, '1031999137', 'CR', '', '3123', 'omar alshareef', '3213', '13123', '3123', '2018-10-11', '09:15 am', '123', '312', '2', '4', '123123', '2018-10-11', '2018-10-16', '3123', '3123', 'test', '3123', '13123', '3123', '312', '3123', '13', '144', '144', '3123', '', '2018-10-07 01:53:26', '2018-10-07 01:53:26');
INSERT INTO `writings_appoinment` (`id`, `user_id`, `identification_number`, `identification_types`, `other_identification_types`, `client_file_number`, `client_name`, `branch`, `total_of_writings_number`, `writings_number`, `writings_date`, `writings_time`, `writings_code`, `case_code`, `case_type`, `case_number`, `case_title`, `case_date`, `case_start_date`, `contact_number`, `opponent_full_name`, `opponent_note`, `opponent_phone`, `court_name`, `court_number`, `court_address`, `judge_name`, `opponent_lawyer_name`, `responsible_employee`, `follow_up_employee`, `note`, `upload_file`, `updatedate`, `createdate`) VALUES (2, 142, 'ewqr', 'CR', '', '22', 'rwer', 'rwer', 'wrwe', 'rwerw', '2018-10-18', '08:15 am', '22', 'rwer', 'wrw', 'wrwer', 'rwe', '2018-10-18', '2018-10-23', 'rwe', 'rwerewr', 'rwrwe', 'rwer', 'werwe', 'rwer', 'wer', 'werwer', 'rwer', '316', '318', 'rwerwr', '', '2018-10-16 03:24:34', '2018-10-16 03:24:34');


